import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { RefundLayoutComponent } from "./page/refund-layout/refund-layout.component";

@NgModule({
	imports: [
		RouterModule.forChild([
			{
				path: "",
				component: RefundLayoutComponent,
			},
			{
				path: ":id",
				component: RefundLayoutComponent,
			},
		]),
	],
	exports: [RouterModule],
})
export class RefundRoutingModule {}
