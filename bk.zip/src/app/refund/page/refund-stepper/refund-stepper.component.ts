import {
	Component,
	EventEmitter,
	OnDestroy,
	OnInit,
	Output,
} from "@angular/core";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { OrderDetailsService } from "services/order-details.service";
import { ConfirmationScreenComponent } from "refund/template/confirmation-screen/confirmation-screen.component";
import { RefundDetailsFormComponent } from "refund/template/refund-details-form/refund-details-form.component";
import { RefundResultsComponent } from "refund/template/refund-results/refund-results.component";
import { StepInfo } from "model/common.model";

@Component({
	selector: "app-refund-stepper",
	templateUrl: "./refund-stepper.component.html",
})
export class RefundStepperComponent implements OnInit, OnDestroy {
	@Output() destroy = new EventEmitter();
	public steps: StepInfo[] = [
		{
			title: this.translate.instantSafe("shared.find_order"),
			component: RefundDetailsFormComponent,
		},
		{
			title: this.translate.instantSafe("general.confirmation"),
			component: ConfirmationScreenComponent,
			back: true,
		},
		{
			title: this.translate.instantSafe("general.confirmation"),
			component: RefundResultsComponent,
			hide: true,
			closeLabel: this.translate.instantSafe("general.close"),
		},
	];
	constructor(
		private orderDetailsService: OrderDetailsService,
		private titleService: TitleService,
		private translate: TranslateService
	) {}

	ngOnInit(): void {
		// Reset the order details when entering the new transaction
		this.orderDetailsService.setOrderId("");
	}

	ngOnDestroy(): void {
		// Reset the order details when leaving the new transaction
		this.orderDetailsService.setOrderId("");
		this.titleService.setTitle(
			this.translate.instantSafe("app.title_transaction")
		);
		this.destroy.emit();
	}

	updateBrowserTitle(title: string): void {
		this.titleService.setTitle(
			this.translate.instantSafe("app.title_refund") + " | " + title
		);
	}
}
