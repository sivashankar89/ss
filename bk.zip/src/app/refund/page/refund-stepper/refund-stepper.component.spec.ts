import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RefundStepperComponent } from "./refund-stepper.component";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { OrderDetailsService } from "../../../services/order-details.service";
import { TitleService } from "@international-payment-platform/portal-core";
import { DefaultTranspiler, TRANSLOCO_TRANSPILER } from "@ngneat/transloco";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

const TitleServiceStub: Partial<TitleService> = {
	setTitle: (titleLabel: string) => {},
};

describe("RefundStepperComponent", () => {
	let component: RefundStepperComponent;
	let fixture: ComponentFixture<RefundStepperComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [RefundStepperComponent],
			providers: [
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			imports: [HttpClientTestingModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(RefundStepperComponent);
		component = fixture.componentInstance;
		jest.spyOn(TitleServiceStub, "setTitle");
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should render the stepper component", () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-stepper-full-screen"
		);
	});

	it("unset order Id when destroy component", () => {
		const searchOrderSpy = jest.spyOn(
			TestBed.inject(OrderDetailsService),
			"setOrderId"
		);
		component.ngOnDestroy();
		expect(searchOrderSpy).toHaveBeenCalled();
	});

	it("THEN should set title", () => {
		component.updateBrowserTitle("Refund");
		expect(TitleServiceStub.setTitle).toHaveBeenCalled();
	});
});
