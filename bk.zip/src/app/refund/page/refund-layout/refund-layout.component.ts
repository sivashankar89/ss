import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { ReplaySubject, takeUntil } from "rxjs";
import { OrderDetailsService } from "../../../services/order-details.service";
import { RedirectCallbackService } from "../../../services/redirect/redirect-callback.service";
import { RefundStepperComponent } from "../refund-stepper/refund-stepper.component";

@Component({
	selector: "app-refund-layout",
	template: "",
})
export class RefundLayoutComponent implements OnInit, OnDestroy {
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private modalService: CdsModalService,
		private redirectService: RedirectCallbackService,
		private activateRoute: ActivatedRoute,
		private orderDetailsService: OrderDetailsService
	) {}

	ngOnInit(): void {
		this.redirectService.init();

		this.activateRoute.params
			.pipe(takeUntil(this.destroyed$))
			.subscribe((params) => {
				this.openRefund();
				if (params.id) {
					this.orderDetailsService.setOrderId(params.id);
				}
			});
	}

	openRefund(): void {
		const modalRef = this.modalService.openModal(RefundStepperComponent);
		if (!!modalRef) {
			modalRef.instance.destroy
				.pipe(takeUntil(this.destroyed$))
				.subscribe(() => this.redirectService.return());
		}
	}

	ngOnDestroy(): void {
		this.redirectService.destroy();
		this.destroyed$.next();
		this.destroyed$.complete();
		this.modalService.closeModal();
	}
}
