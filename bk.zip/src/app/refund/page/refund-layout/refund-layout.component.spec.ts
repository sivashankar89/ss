import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { ActivatedRoute } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { TitleService } from "@international-payment-platform/portal-core";
import { DefaultTranspiler, TRANSLOCO_TRANSPILER } from "@ngneat/transloco";
import { OrderDetailsService } from "../../../services/order-details.service";
import { RefundStepperComponent } from "../refund-stepper/refund-stepper.component";
import { RefundLayoutComponent } from "./refund-layout.component";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

const TitleServiceStub: Partial<TitleService> = {
	setTitle: (titleLabel: string) => {},
};

describe("RefundLayoutComponent", () => {
	let component: RefundLayoutComponent;
	let fixture: ComponentFixture<RefundLayoutComponent>;
	let modalService: CdsModalService;
	let route: ActivatedRoute;
	let orderDetailsService: OrderDetailsService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [RefundLayoutComponent, RefundStepperComponent],
			imports: [
				RouterTestingModule,
				HttpClientTestingModule,
				CdsModalModule,
				CdsModalFullscreenModule,
			],
			providers: [
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TRANSLOCO_TRANSPILER, useClass: DefaultTranspiler },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		})
			.overrideModule(BrowserDynamicTestingModule, {
				set: {
					entryComponents: [RefundStepperComponent],
				},
			})
			.compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(RefundLayoutComponent);
		modalService = TestBed.inject(CdsModalService);
		route = TestBed.inject(ActivatedRoute);
		orderDetailsService = TestBed.inject(OrderDetailsService);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
