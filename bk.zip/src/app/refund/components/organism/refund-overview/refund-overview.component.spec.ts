import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { TRANSACTION_MOCK } from "mocks/refund/refund.mock";
import { RefundOverviewComponent } from "./refund-overview.component";

const refundMock = {
	transaction: TRANSACTION_MOCK,
	balance: 5,
};

describe("RefundOverviewComponent", () => {
	let component: RefundOverviewComponent;
	let fixture: ComponentFixture<RefundOverviewComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [RefundOverviewComponent],
			imports: [HttpClientTestingModule, PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(RefundOverviewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should correctly render the passed @Input value", () => {
		component.refund = refundMock;
		fixture.detectChanges();
		const compiled = fixture.debugElement.nativeElement;
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-label-value"
		);
	});
});
