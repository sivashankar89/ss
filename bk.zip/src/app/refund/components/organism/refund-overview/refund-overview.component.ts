import { Component, Input } from "@angular/core";
import { RefundTransaction } from "../../../model/refund.model";

@Component({
	selector: "app-refund-overview",
	templateUrl: "./refund-overview.component.html",
})
export class RefundOverviewComponent {
	@Input() refund!: RefundTransaction;
}
