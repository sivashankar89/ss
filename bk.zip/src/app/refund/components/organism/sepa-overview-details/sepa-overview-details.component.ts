import { Component, Input } from "@angular/core";
import { RefundTransaction } from "refund/model/refund.model";

@Component({
	selector: "app-sepa-overview-details",
	templateUrl: "./sepa-overview-details.component.html",
})
export class SepaOverviewDetailsComponent {
	@Input() refund!: RefundTransaction;
}
