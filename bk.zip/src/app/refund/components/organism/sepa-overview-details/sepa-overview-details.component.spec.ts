import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { SepaOverviewDetailsComponent } from "./sepa-overview-details.component";

describe("SepaOverviewDetailsComponent", () => {
	let component: SepaOverviewDetailsComponent;
	let fixture: ComponentFixture<SepaOverviewDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SepaOverviewDetailsComponent],
			imports: [HttpClientTestingModule, PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SepaOverviewDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
