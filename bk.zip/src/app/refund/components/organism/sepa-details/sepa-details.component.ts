import { Input } from "@angular/core";
import { Component } from "@angular/core";
import { TransactionAmount } from "bff-client";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { RefundTransaction } from "refund/model/refund.model";
import { OrderDetailsService } from "services/order-details.service";

@Component({
	selector: "app-sepa-details",
	templateUrl: "./sepa-details.component.html",
	styleUrls: ["./sepa-details.component.scss"],
})
export class SepaDetailsComponent {
	@Input() refund!: RefundTransaction;
	@Input() amount!: TransactionAmount | undefined | null;
	paymentPermissions = VTPaymentPermissions;

	orderId!: string;
	constructor(private orderDetailsService: OrderDetailsService) {}

	ngOnInit(): void {
		this.orderId = this.orderDetailsService.getOrderId();
	}
}
