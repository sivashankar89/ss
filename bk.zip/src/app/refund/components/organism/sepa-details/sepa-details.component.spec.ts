import { ComponentFixture, TestBed } from "@angular/core/testing";
import { SepaDetailsComponent } from "./sepa-details.component";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { TRANSACTION_MOCK } from "mocks/refund/refund.mock";
import { TransactionAmountCurrencyEnum } from "bff-client";
import { TelemetryService } from "services/telemetry.service";

describe("SepaDetailsComponent", () => {
	let component: SepaDetailsComponent;
	let fixture: ComponentFixture<SepaDetailsComponent>;
	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SepaDetailsComponent],
			imports: [HttpClientModule, PipesMockModule],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SepaDetailsComponent);
		component = fixture.componentInstance;
		component.refund = {
			balance: 10,
			transaction: TRANSACTION_MOCK,
		};
		component.amount = {
			total: 10,
			currency: TransactionAmountCurrencyEnum.Usd,
		};
		fixture.detectChanges();
	});

	it("It should be exists label text", () => {
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"shared.total_amt"
		);
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
