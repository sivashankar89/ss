import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ComponentFixture, TestBed } from "@angular/core/testing";

import { AmountRefundInputComponent } from "./amount-refund-input.component";
import { TRANSACTION_MOCK } from "mocks/refund/refund.mock";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TelemetryService } from "services/telemetry.service";

describe("AmountRefundInputComponent", () => {
	let component: AmountRefundInputComponent;
	let fixture: ComponentFixture<AmountRefundInputComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [AmountRefundInputComponent],
			schemas: [NO_ERRORS_SCHEMA],
			imports: [FormsModule, HttpClientTestingModule, PipesMockModule],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(AmountRefundInputComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("it should render the amount input", () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-amount-input-box"
		);
	});

	it("it should render the amount input", () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-display-total-amount"
		);
	});

	it("it should call the method updateAmount ", () => {
		jest.spyOn(component, "updateAmount");
		component.updateAmount("subtotal", "10");
		fixture.detectChanges();
		expect(component.updateAmount).toHaveBeenCalled();
	});

	it("it should call the method ngOnChanges ", () => {
		jest.spyOn(component, "ngOnChanges");
		component.refund = {
			transaction: TRANSACTION_MOCK,
			balance: 10,
		};
		component.ngOnChanges({
			refund: {
				previousValue: undefined,
				currentValue: {
					balance: "10",
					transaction: TRANSACTION_MOCK,
				},
				firstChange: false,
				isFirstChange: () => false,
			},
		});
		fixture.detectChanges();
		expect(component.ngOnChanges).toHaveBeenCalled();
		expect(component.maxAmount).toBeTruthy();
		expect(component.currency).toBe("USD");
	});
});
