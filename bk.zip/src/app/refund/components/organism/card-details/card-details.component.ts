import { Component, Input, OnInit } from "@angular/core";
import { PaymentResponse, TransactionAmount } from "bff-client";
import { OrderDetailsService } from "../../../../services/order-details.service";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { RefundTransaction } from "refund/model/refund.model";
@Component({
	selector: "app-card-details",
	templateUrl: "./card-details.component.html",
})
export class CardDetailsComponent implements OnInit {
	@Input() refund!: RefundTransaction | undefined;
	@Input() amount!: TransactionAmount | undefined | null;
	orderId!: string;
	paymentPermissions = VTPaymentPermissions;
	constructor(private orderDetailsService: OrderDetailsService) {}

	ngOnInit(): void {
		this.orderId = this.orderDetailsService.getOrderId();
	}
}
