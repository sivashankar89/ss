import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, throwError } from "rxjs";
import {
	PaymentBffService,
	PaymentResponse,
	PaymentRequest,
	TransactionAmount,
	RequestType,
	TransactionAmountCurrencyEnum,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";

/**
 * Supported service for refund transaction and amount value changes
 */
@Injectable({
	providedIn: "root",
})
export class RefundService {
	private readonly initAmount = {
		total: 0,
		currency: TransactionAmountCurrencyEnum.Aed,
		components: {
			subtotal: 0,
		},
	};
	private amount = new BehaviorSubject<TransactionAmount>(this.initAmount);
	public amount$ = this.amount.asObservable();

	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService
	) {}

	/**
	 * Reset the refund transaction amount
	 * @returns void
	 */
	resetAmount(): void {
		this.amount.next(this.initAmount);
	}

	/**
	 * Set the refund transaction amount
	 *
	 * @param TransactionAmount amount Amount object for set to the subject
	 * @returns void
	 */
	setAmount(amount: TransactionAmount): void {
		this.amount.next(amount);
	}

	/**
   * Get the refund transaction amount from the subject
   * @returns TransactionAmount,k
0   */
	getAmount(): TransactionAmount {
		return this.amount.getValue();
	}

	/**
	 * Get the API payload for refund transaction request
	 * @returns PaymentRequest
	 */
	public getApiPayload(): PaymentRequest {
		const amount = this.checkTransactionAmount(this.getAmount());
		return {
			requestType: RequestType.ReturnTransaction,
			transactionAmount: amount,
		};
	}

	checkTransactionAmount(
		transactionAmount?: TransactionAmount
	): TransactionAmount {
		const amount = transactionAmount
			? JSON.parse(JSON.stringify(transactionAmount))
			: {};
		const returnZeroIfEmpty = (num: number | string): string => {
			if (typeof num === "number") {
				num = num.toString();
			}
			if (!num || num.trim() === "" || parseFloat(num) === 0) {
				return "0";
			}
			return num;
		};

		amount.total = returnZeroIfEmpty(amount.total);
		amount.currency = amount.currency || "";

		if (amount.components) {
			for (const key in amount.components) {
				amount.components[key] = returnZeroIfEmpty(amount.components[key]);
			}

			if (!amount.components["subtotal"]) {
				amount.components["subtotal"] = "0";
			}
		}

		return amount;
	}

	/**
	 * Peform the refund transaction using the paymentBff service
	 *
	 * @param string ipgTransactionId Transaction Id from the IPG for performing the refund
	 * @returns Observable<PaymentResponse> Payment BFF will send the success or error message for the refund transaction
	 */
	public refundTransaction(
		ipgTransactionId: string | undefined
	): Observable<PaymentResponse> {
		if (!ipgTransactionId) {
			return throwError(
				() => new Error(`ipgTransactionId not found for this transaction`)
			);
		}
		const paymentRequest = this.getApiPayload();
		return this.paymentBff.doSecondaryTransaction({
			ipgTransactionId: ipgTransactionId,
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
			paymentRequestV2: paymentRequest,
		});
	}
}
