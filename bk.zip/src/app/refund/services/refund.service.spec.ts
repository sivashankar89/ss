import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE } from "mocks/payment_api/transactions.mock";
import { TRANSACTION_MOCK } from "mocks/refund/refund.mock";
import { RefundService } from "./refund.service";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("RefundService", () => {
	let service: RefundService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});
		service = TestBed.inject(RefundService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it("it should call the method setAmount ", () => {
		const mockAmount = PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE.approvedAmount;
		const apiSpy = jest.spyOn(service, "setAmount");
		if (mockAmount) {
			service.setAmount(mockAmount);
			expect(apiSpy).toHaveBeenCalledWith(mockAmount);
		}
	});

	it("it should call the method APIPayload ", () => {
		const apiSpy = jest.spyOn(service, "getApiPayload");
		service.getApiPayload();
		expect(apiSpy).toHaveBeenCalled();
	});

	it("it should call the method refundTransaction ", () => {
		const apiSpy = jest.spyOn(service, "refundTransaction");
		service.refundTransaction(TRANSACTION_MOCK.ipgTransactionId);
		expect(apiSpy).toHaveBeenCalled();
	});
});
