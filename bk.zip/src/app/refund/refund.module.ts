import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { CardDetailsComponent } from "./components/organism/card-details/card-details.component";
import { SharedModule } from "../shared/shared.module";
import { RefundStepperComponent } from "./page/refund-stepper/refund-stepper.component";
import { ConfirmationScreenComponent } from "./template/confirmation-screen/confirmation-screen.component";
import { SepaDetailsComponent } from "./components/organism/sepa-details/sepa-details.component";
import { RefundDetailsFormComponent } from "./template/refund-details-form/refund-details-form.component";
import { RefundOverviewComponent } from "./components/organism/refund-overview/refund-overview.component";
import { RefundService } from "./services/refund.service";
import { AmountRefundInputComponent } from "./components/organism/amount-refund-input/amount-refund-input.component";
import { RefundResultsComponent } from "./template/refund-results/refund-results.component";
import { RefundRoutingModule } from "./refund-routing.module";
import { RefundLayoutComponent } from "./page/refund-layout/refund-layout.component";
import { SepaOverviewDetailsComponent } from "./components/organism/sepa-overview-details/sepa-overview-details.component";
import { MandateTypePipeModule } from "pipes";

@NgModule({
	declarations: [
		CardDetailsComponent,
		RefundStepperComponent,
		ConfirmationScreenComponent,
		SepaDetailsComponent,
		RefundDetailsFormComponent,
		RefundOverviewComponent,
		RefundResultsComponent,
		AmountRefundInputComponent,
		RefundLayoutComponent,
		SepaOverviewDetailsComponent,
	],
	imports: [
		CommonModule,
		SharedModule,
		FormsModule,
		RefundRoutingModule,
		MandateTypePipeModule,
	],
	providers: [RefundService],
	exports: [
		CardDetailsComponent,
		SepaDetailsComponent,
		AmountRefundInputComponent,
	],
})
export class RefundModule {}
