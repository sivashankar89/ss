import {
	AfterViewInit,
	Component,
	EventEmitter,
	OnInit,
	Output,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { map, Observable, tap } from "rxjs";
import { WithLoadingError } from "../../../model/common.model";
import { OrderDetailsService } from "../../../services/order-details.service";
import { throwErrorMessage } from "../../../utils/common.utils";
import { getValidRefundTransaction } from "../../../utils/order-details.utils";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { RefundTransaction } from "../../model/refund.model";
import { ApiErrorMessage } from "../../../model/error.model";
import { TranslateService } from "@tolgee/ngx";
import { OrderDetailsResponse } from "bff-client";
import { RefundService } from "refund/services/refund.service";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";

@Component({
	selector: "app-refund-details-form",
	templateUrl: "./refund-details-form.component.html",
	styleUrls: ["./refund-details-form.component.scss"],
})
export class RefundDetailsFormComponent implements OnInit, AfterViewInit {
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	@Output() buttonRefs = new EventEmitter();

	public isValidTab = false;
	public orderDetails$!: Observable<WithLoadingError<OrderDetailsResponse>>;
	public refund?: RefundTransaction;
	public orderId = "";
	public isOrderValid = false;
	searchInputFocus = true;
	afterSearchFocus = false;

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private orderDetailsService: OrderDetailsService,
		public refundService: RefundService,
		private translate: TranslateService,
		private openOrderDetailsService: OpenOrderDetailsService
	) {}

	ngOnInit(): void {
		this.orderId = this.orderDetailsService.getOrderId();
		this.orderDetails$ = this.orderDetailsService.orderDetails$.pipe(
			tap(() => {
				this.isValidTab = false;
			}),
			map((order) => {
				try {
					if (order.error) {
						this.isOrderValid = false;
						throwErrorMessage(
							this.translate.instantSafe("refund.valid_order_error"),
							order.error.code
						);
					} else if (order.value) {
						this.isOrderValid = true;
						this.searchInputFocus = false;
						this.afterSearchFocus = true;
						this.refund = getValidRefundTransaction(order.value);
					} else {
						this.refund = undefined;
					}
				} catch (e: any) {
					delete order.value;
					if (e?.message) {
						e.message = this.translate.instantSafe(e.message);
					}
					order.error = e as ApiErrorMessage;
				}
				return order;
			})
		);
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	searchOrder(orderId: string): void {
		orderId = orderId.trim();
		this.orderId = orderId;
		this.refundService.resetAmount();
		this.orderDetailsService.setOrderId(orderId);
	}

	goNext(): void {
		this.stepperComponent.goNext();
	}

	validChange(valid: boolean): void {
		this.isValidTab = valid;
	}

	viewTransaction(): void {
		this.openOrderDetailsService.openOrderDetailsModal(this.orderId);
	}
}
