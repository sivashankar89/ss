import { OverlayModule } from "@angular/cdk/overlay";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { REFUND_MOCK_RESPONSE } from "mocks/refund/refund.mock";
import {
	OpenOrderDetailsServiceStub,
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";
import { of, throwError } from "rxjs";
import { OrderDetailsService } from "../../../services/order-details.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { RefundDetailsFormComponent } from "./refund-details-form.component";
import { TelemetryService } from "services/telemetry.service";

const orderDetailsMock = {
	loading: false,
	value: REFUND_MOCK_RESPONSE,
};

describe("RefundDetailsFormComponent", () => {
	let component: RefundDetailsFormComponent;
	let fixture: ComponentFixture<RefundDetailsFormComponent>;
	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [
				HttpClientModule,
				OverlayModule,
				RouterTestingModule,
				PipesMockModule,
			],
			providers: [
				StepperFullScreenComponent,
				OrderDetailsService,
				{
					provide: OpenOrderDetailsService,
					useValue: OpenOrderDetailsServiceStub,
				},
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			declarations: [RefundDetailsFormComponent],
			schemas: [NO_ERRORS_SCHEMA],
		});
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(RefundDetailsFormComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should render the input", () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-search-order-input"
		);
	});

	it("it should call the method searchOrder ", () => {
		const param = "12345";
		const searchOrderSpy = jest.spyOn(component, "searchOrder");
		component.searchOrder(param);
		expect(searchOrderSpy).toHaveBeenCalledWith(param);
	});

	it("it should throw error for invalid input from API", fakeAsync(() => {
		const appService = TestBed.inject(OrderDetailsService);
		appService.getOrderDetails = jest.fn().mockReturnValue(
			throwError(() => ({
				error: {
					error: {
						code: "INVALID",
						message:
							"The order Id entered is invalid. Please enter a valid Order ID.",
					},
				},
			}))
		);
		component.searchOrder("testinput");
		component.orderDetails$.subscribe();
		tick(1000);
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
	}));

	it("it should handle return not refundable case error order", fakeAsync(() => {
		const appService = fixture.debugElement.injector.get(OrderDetailsService);
		appService.getOrderDetails = jest.fn().mockReturnValue(
			throwError(() => ({
				error: {
					error: {
						code: "NOT_REFUNDED",
						message:
							"The orderID entered cannot be refunded. Please enter a valid Order ID.",
					},
				},
			}))
		);

		component.searchOrder("testinput");
		fixture.detectChanges();
		component.orderDetails$.subscribe();
		tick(1000);
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
	}));

	it("it should call the method goNext ", () => {
		jest.spyOn(component, "goNext");
		component.goNext();
		expect(component.goNext).toHaveBeenCalled();
	});
	it("it should call the method validChange ", () => {
		jest.spyOn(component, "validChange");
		component.validChange(true);
		expect(component.validChange).toHaveBeenCalledWith(true);
		expect(component.isValidTab).toBeTruthy();
	});

	it("it should call order details with valid response", () => {
		const appService = fixture.debugElement.injector.get(OrderDetailsService);
		appService.orderDetails$ = of(orderDetailsMock).pipe();
		component.ngOnInit();
		fixture.detectChanges();
		component.orderDetails$.subscribe();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-refund-overview"
		);
	});
});
