import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { RefundResultsComponent } from "./refund-results.component";
import { RefundService } from "../../services/refund.service";
import { of, throwError } from "rxjs";
import { OpenOrderDetailsService } from "../../../order-details/services/open-order-details.service";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { OrderDetailsService } from "services/order-details.service";
import { REFUND_MOCK_RESPONSE } from "mocks/refund/refund.mock";
import { TitleService } from "@international-payment-platform/portal-core";
import { RouterTestingModule } from "@angular/router/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { TelemetryService } from "services/telemetry.service";

const TitleServiceStub: Partial<TitleService> = {
	setTitle: (titleLabel: string) => {},
};

const orderDetailsMock = {
	loading: false,
	value: REFUND_MOCK_RESPONSE,
};
describe("RefundResultsComponent", () => {
	let component: RefundResultsComponent;
	let fixture: ComponentFixture<RefundResultsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [
				RouterTestingModule,
				HttpClientTestingModule,
				PipesMockModule,
				CdsModalModule,
				CdsModalFullscreenModule,
			],
			providers: [
				StepperFullScreenComponent,
				OpenOrderDetailsService,
				OrderDetailsService,
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			declarations: [RefundResultsComponent],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(RefundResultsComponent);
		component = fixture.componentInstance;
		jest.spyOn(TitleServiceStub, "setTitle");
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should throw error for invalid response from API", () => {
		const appService = TestBed.inject(OrderDetailsService);
		appService.orderDetails$ = of(orderDetailsMock);
		const postAPI = TestBed.inject(RefundService);
		postAPI.refundTransaction = jest.fn().mockReturnValue(
			throwError(() => ({
				error: {
					error: {
						code: "Invalid",
						message: "Invalid Response from API",
					},
					orderId: "123eredfgd",
				},
			}))
		);
		component.refundPostTransaction();
		fixture.detectChanges();
		expect(component.isLoading).toBe(false);
		expect(component.refundTransaction).toBeUndefined();
		expect(component.error).toBeDefined();
		expect(component.transactionOrderId).toBeTruthy();
	});

	it("it should call http post with valid response", fakeAsync(() => {
		const appService = TestBed.inject(OrderDetailsService);
		appService.orderDetails$ = of(orderDetailsMock);
		const postAPI = fixture.debugElement.injector.get(RefundService);
		postAPI.refundTransaction = jest
			.fn()
			.mockReturnValue(of(orderDetailsMock.value));
		component.refundPostTransaction();
		tick();
		expect(component.isLoading).toBe(false);
		expect(component.refundTransaction).toBeDefined();
		expect(component.transactionOrderId).toBeTruthy();
	}));

	it("should run close modal method", () => {
		const service = TestBed.inject(CdsModalService);
		service.closeModal = jest.fn();
		component.closeModal();
		expect(service.closeModal).toHaveBeenCalled();
	});

	it("it should call the method newTransaction ", () => {
		const steppercomponent = TestBed.inject(StepperFullScreenComponent);
		steppercomponent.goBack = jest.fn();
		const transactionSpy = jest.spyOn(component, "anotherTransaction");
		component.anotherTransaction();
		expect(transactionSpy).toHaveBeenCalled();
	});

	it("should run viewTransaction method", () => {
		const service = TestBed.inject(OpenOrderDetailsService);
		service.openOrderDetailsModal = jest.fn();
		component.viewTransaction();
		expect(service.openOrderDetailsModal).toHaveBeenCalled();
	});
});
