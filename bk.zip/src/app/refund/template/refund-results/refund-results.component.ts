import {
	AfterViewInit,
	Component,
	Input,
	OnDestroy,
	OnInit,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { map, Subscription, switchMap } from "rxjs";
import { ApiErrorResponse } from "../../../model/error.model";
import { OrderDetailsService } from "../../../services/order-details.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { getValidRefundTransaction } from "../../../utils/order-details.utils";
import { RefundService } from "../../services/refund.service";
import { OpenOrderDetailsService } from "../../../order-details/services/open-order-details.service";
import {
	AuthenticationService,
	TitleService,
} from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { PaymentResponse } from "bff-client";
import { VTPaymentPermissions } from "enum/permissions.enum";

@Component({
	selector: "app-refund-results",
	templateUrl: "./refund-results.component.html",
	styleUrls: ["./refund-results.component.scss"],
})
export class RefundResultsComponent
	implements OnInit, OnDestroy, AfterViewInit
{
	@ViewChild("modalFooterOptionalPrimaryBtn", { read: TemplateRef })
	modalFooterOptionalPrimaryBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	@Input() transaction: any;

	public subscription!: Subscription;
	public isLoading = true;
	public refundTransaction!: PaymentResponse;
	public error!: PaymentResponse;
	transactionOrderId!: string;
	showViewTreansaction = true;

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private modalService: CdsModalService,
		private orderDetailsService: OrderDetailsService,
		private refundService: RefundService,
		private openOrderDetailsService: OpenOrderDetailsService,
		private titleService: TitleService,
		private translate: TranslateService,
		private authenticationService: AuthenticationService
	) {}

	ngOnInit(): void {
		this.refundPostTransaction();
		this.showViewTreansaction = this.authenticationService
			.getPermissions()
			.includes(VTPaymentPermissions.EcomVTOrderDetailsView);
	}

	refundPostTransaction(): void {
		this.subscription = this.orderDetailsService.orderDetails$
			.pipe(
				map((order) => {
					const refund = getValidRefundTransaction(order.value);
					this.transactionOrderId = order?.value?.orderId || "";
					return refund?.transaction;
				}),
				switchMap((transaction) => {
					return this.refundService.refundTransaction(
						transaction?.ipgTransactionId
					);
				})
			)
			.subscribe({
				next: (res) => {
					this.isLoading = false;
					if (res.error) {
						this.titleService.setTitle(
							`${this.translate.instantSafe(
								"app.title_refund"
							)} | ${this.translate.instantSafe("general.unsuccess_message")}`
						);
						this.error = res;
					} else {
						this.titleService.setTitle(
							`${this.translate.instantSafe(
								"app.title_refund"
							)} | ${this.translate.instantSafe("general.success_message")}`
						);
						this.refundTransaction = res;
					}
				},
				error: (err) => {
					this.titleService.setTitle(
						`${this.translate.instantSafe(
							"app.title_refund"
						)} | ${this.translate.instantSafe("general.unsuccess_message")}`
					);
					this.isLoading = false;
					this.error = err?.error;
				},
			});
	}
	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			OptPrimaryBtn: this.modalFooterOptionalPrimaryBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	ngOnDestroy(): void {
		this.subscription.unsubscribe();
		this.reset();
	}

	closeModal(): void {
		this.modalService.closeModal();
	}

	reset(): void {
		this.orderDetailsService.setOrderId("");
		this.refundService.resetAmount();
	}

	anotherTransaction(): void {
		this.reset();
		this.stepperComponent.goStep(0);
	}

	viewTransaction(): void {
		this.openOrderDetailsService.openOrderDetailsModal(this.transactionOrderId);
	}
}
