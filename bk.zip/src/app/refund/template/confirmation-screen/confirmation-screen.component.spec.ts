import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ConfirmationScreenComponent } from "./confirmation-screen.component";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { OrderDetailsService } from "../../../services/order-details.service";
import { of } from "rxjs";
import { ORDER_DETAILS_AND_TRANSACTIONS_MOCK_RESPONE } from "../../../../mocks/refund/transaction.mock";
import { ApiErrorMessage } from "../../../model/error.model";
import { REFUND_MOCK_RESPONSE } from "mocks/refund/refund.mock";
import { RouterTestingModule } from "@angular/router/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
} from "@international-payment-platform/design-system-angular";
import { TelemetryService } from "services/telemetry.service";

describe("ConfirmationScreenComponent", () => {
	let component: ConfirmationScreenComponent;
	let fixture: ComponentFixture<ConfirmationScreenComponent>;
	const orderDetailsMock = {
		loading: false,
		value: REFUND_MOCK_RESPONSE,
	};
	const getValidRefundTransaction: any = jest
		.fn()
		.mockReturnValue(ORDER_DETAILS_AND_TRANSACTIONS_MOCK_RESPONE);

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [ConfirmationScreenComponent],
			imports: [
				RouterTestingModule,
				HttpClientTestingModule,
				PipesMockModule,
				CdsModalModule,
				CdsModalFullscreenModule,
			],
			providers: [
				StepperFullScreenComponent,
				{
					provide: OrderDetailsService,
					useValue: {
						orderDetails$: of(orderDetailsMock),
					},
				},
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(ConfirmationScreenComponent);
		component = fixture.componentInstance;
	});

	it("should initialize without issues", () => {
		expect(component).toBeDefined();
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
	});

	it("The function was called exactly once", () => {
		expect(component.confirmPayment.call.length).toBe(1);
		expect(component.goBack.call.length).toBe(1);
		expect(component.ngAfterViewInit.call.length).toBe(1);
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should call the method goBack ", () => {
		const closeSpy = jest.spyOn(component, "goBack");
		component.goBack();
		expect(closeSpy).toHaveBeenCalled();
	});

	it("it should call the method confirmPayment ", () => {
		const closeSpy = jest.spyOn(component, "confirmPayment");
		component.confirmPayment();
		expect(closeSpy).toHaveBeenCalled();
	});

	describe("rufund transactioln", () => {
		it("it should call order details with valid response", () => {
			const appService = fixture.debugElement.injector.get(OrderDetailsService);
			appService.orderDetails$ = of(orderDetailsMock).pipe();
			component.ngOnInit();
			fixture.detectChanges();
			component.orderDetails$.subscribe({
				next: (res) => {
					if (res) {
						component.refund = getValidRefundTransaction;
					}
				},
				error: (e) => {
					console.error(e.error as ApiErrorMessage);
				},
			});
			expect(component.refund).toEqual(getValidRefundTransaction);
			expect(fixture).toMatchSnapshot();
		});
	});
});
