import {
	Component,
	OnInit,
	ViewChild,
	TemplateRef,
	AfterViewInit,
} from "@angular/core";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { OrderDetailsService } from "../../../services/order-details.service";
import { map, Observable } from "rxjs";
import { WithLoadingError } from "../../../model/common.model";
import { getValidRefundTransaction } from "../../../utils/order-details.utils";
import { RefundTransaction } from "../../model/refund.model";
import { ApiErrorMessage } from "../../../model/error.model";
import { RefundService } from "../../services/refund.service";
import { TranslateService } from "@tolgee/ngx";
import { OrderDetailsResponse, TransactionAmount } from "bff-client";

@Component({
	selector: "app-confirmation-screen",
	templateUrl: "./confirmation-screen.component.html",
	styleUrls: ["./confirmation-screen.component.scss"],
})
export class ConfirmationScreenComponent implements OnInit, AfterViewInit {
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	public amount$!: Observable<TransactionAmount>;
	public orderDetails$!: Observable<WithLoadingError<OrderDetailsResponse>>;
	public refund!: RefundTransaction;

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private orderDetailsService: OrderDetailsService,
		private rf: RefundService,
		private translate: TranslateService
	) {}

	ngOnInit(): void {
		this.amount$ = this.rf.amount$;
		this.orderDetails$ = this.orderDetailsService.orderDetails$.pipe(
			map((order) => {
				try {
					if (order.value) {
						const t = getValidRefundTransaction(order.value);
						if (t) {
							this.refund = t;
						}
					}
				} catch (e: any) {
					if (e?.message) {
						e.message = this.translate.instantSafe(e.message);
					}
					order.error = e as ApiErrorMessage;
				}
				return order;
			})
		);
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	goBack(): void {
		this.stepperComponent.goBack();
	}

	confirmPayment(): void {
		this.stepperComponent.goNext();
	}
}
