import { PaymentResponse, OrderDetailsResponse } from "bff-client";

export interface RefundTransaction {
	transaction?: PaymentResponse;
	balance: number;
	order?: OrderDetailsResponse;
}
