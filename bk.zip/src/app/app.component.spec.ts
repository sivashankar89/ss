import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	InstanceService,
	ThemeService,
	TitleService,
} from "@international-payment-platform/portal-core";
import { TranslocoTestingModule } from "@ngneat/transloco";
import { AppComponent } from "./app.component";
import { TranslateService } from "@tolgee/ngx";
import {
	MerchantDatasServiceStub,
	RedirectServiceStub,
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { MerchantDatasService } from "./services/merchant-datas.service";
import { NgxLoggerLevel, NGXLogger, TOKEN_LOGGER_CONFIG } from "ngx-logger";
import { NGXLoggerMock } from "ngx-logger/testing/ngx-logger-testing";
import { TelemetryService } from "services/telemetry.service";
import { ɵm as RedirectService } from "@international-payment-platform/portal-core";

const themeServiceStub: Partial<ThemeService> = {
	loadTheme: (instance: string) => new Promise(jest.fn()),
};

const instanceServiceStub: Partial<InstanceService> = {
	discoverInstance: () => "gbs",
};

describe("GIVEN AppComponent", () => {
	let component: AppComponent;
	let fixture: ComponentFixture<AppComponent>;

	beforeEach(waitForAsync(() => {
		TestBed.configureTestingModule({
			imports: [
				TranslocoTestingModule,
				HttpClientTestingModule,
				PipesMockModule,
			],
			declarations: [AppComponent],
			providers: [
				{ provide: ThemeService, useValue: themeServiceStub },
				{ provide: InstanceService, useValue: instanceServiceStub },
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{ provide: MerchantDatasService, useValue: MerchantDatasServiceStub },
				{ provide: RedirectService, useValue: RedirectServiceStub },
				{ provide: NGXLogger, useClass: NGXLoggerMock },
				{
					provide: TOKEN_LOGGER_CONFIG,
					useValue: { level: NgxLoggerLevel.ERROR },
				},
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AppComponent);
		component = fixture.componentInstance;

		jest.spyOn(TitleServiceStub, "setTitle");
	});

	it("THEN should create the app", () => {
		expect(component).toBeTruthy();
	});

	it("THEN should set title", () => {
		expect(TitleServiceStub.setTitle).toHaveBeenCalled();
	});
});
