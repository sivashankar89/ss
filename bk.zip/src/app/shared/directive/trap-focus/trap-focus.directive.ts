import {
	Directive,
	ElementRef,
	AfterViewInit,
	HostListener,
	Input,
	OnChanges,
} from "@angular/core";
import { delay, of, take } from "rxjs";

@Directive({
	selector: "[appTrapFocus]",
})
export class TrapFocusDirective implements AfterViewInit, OnChanges {
	@Input() appTrapFocus!: string;
	private firstFocusEl!: HTMLElement;
	private lastFocusEl!: HTMLElement;

	constructor(private el: ElementRef) {}

	@HostListener("keydown.tab", ["$event"])
	onTab(e: Event): void {
		if (!this.firstFocusEl || document.activeElement !== this.lastFocusEl) {
			return;
		}
		// Get all focus elements again to check the condition
		this.findFocueEls();
		if (!this.firstFocusEl || document.activeElement !== this.lastFocusEl) {
			return;
		}
		this.firstFocusEl.focus();
		e.preventDefault();
	}

	@HostListener("keydown.shift.tab", ["$event"])
	onShiftTab(e: Event): void {
		if (!this.firstFocusEl || document.activeElement !== this.firstFocusEl) {
			return;
		}
		// Get all focus elements again to check the condition
		this.findFocueEls();
		if (!this.firstFocusEl || document.activeElement !== this.firstFocusEl) {
			return;
		}
		this.lastFocusEl.focus();
		e.preventDefault();
	}

	ngOnChanges(): void {
		this.findFocueEls();
	}

	ngAfterViewInit(): void {
		of(null)
			.pipe(delay(1000), take(1))
			.subscribe(() => {
				this.findFocueEls();
			});
	}

	findFocueEls(): void {
		const element = this.el.nativeElement;
		const focusableEls = [
			...element.querySelectorAll(
				'a[href], button, input, textarea, select, details,[tabindex]:not([tabindex="-1"])'
			),
		].filter(
			(el) => !el.hasAttribute("disabled") && !el.getAttribute("aria-hidden")
		);
		const len = focusableEls.length;
		if (len > 0) {
			this.firstFocusEl = focusableEls[0];
			this.lastFocusEl = focusableEls[len - 1];
		}
	}
}
