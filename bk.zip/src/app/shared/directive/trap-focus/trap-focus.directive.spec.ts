import { Component, ElementRef } from "@angular/core";
import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { TrapFocusDirective } from "./trap-focus.directive";

describe("TrapFocusDirective", () => {
	let fixture: ComponentFixture<TestComponent>;
	let directive: TrapFocusDirective;
	let component: TestComponent;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [TrapFocusDirective, TestComponent],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(TestComponent);
		directive = new TrapFocusDirective(fixture.elementRef);
		component = fixture.componentInstance;
		fixture.detectChanges();
		directive.findFocueEls();
	});

	it("should create an instance", () => {
		expect(directive).toBeTruthy();
	});

	it("should listen and return true  onTab event", () => {
		fixture.debugElement.nativeElement.querySelector("input").focus();
		const tabEvent = new KeyboardEvent("keydown", {
			key: "tab",
			cancelable: true,
		});
		directive.onTab(tabEvent);
		fixture.detectChanges();
		expect(tabEvent.defaultPrevented).toBeTruthy();
	});

	it("should listen and return true  Shift Tab event", () => {
		fixture.debugElement.nativeElement.querySelector("input").focus();
		const tabEvent = new KeyboardEvent("keydown", {
			key: "shift.tab",
			cancelable: true,
		});
		directive.onShiftTab(tabEvent);
		fixture.detectChanges();
		expect(tabEvent.defaultPrevented).toBeTruthy();
	});

	it("should listen and return false onTab event", () => {
		const tabEvent = new KeyboardEvent("keydown", {
			key: "tab",
			cancelable: true,
		});
		directive.onTab(tabEvent);
		fixture.detectChanges();
		expect(tabEvent.defaultPrevented).toBeFalsy();
	});

	it("should listen and return false Shift Tab event", () => {
		const tabEvent = new KeyboardEvent("keydown", {
			key: "shift.tab",
			cancelable: true,
		});
		directive.onShiftTab(tabEvent);
		fixture.detectChanges();
		expect(tabEvent.defaultPrevented).toBeFalsy();
	});
});

@Component({
	template: "<input />",
})
class TestComponent {}
