import { ElementRef } from "@angular/core";
import { AutofocusDirective } from "./autofocus.directive";

describe("AutofocusDirective", () => {
	let directive: AutofocusDirective;
	it("should focus input)", () => {
		const element = document.createElement("input");
		const div = document.createElement("div");
		div.append(element);
		directive = new AutofocusDirective(new ElementRef(div));
		directive.ngAfterViewInit();
		expect(directive).toMatchSnapshot();
	});

	it("should check input)", () => {
		const element = document.createElement("input");
		directive = new AutofocusDirective(new ElementRef(element));
		element.focus();
		directive.ngAfterViewInit();
		expect(directive).toMatchSnapshot();
	});

	it("should check afterviewInit)", () => {
		directive = new AutofocusDirective(new ElementRef(null));
		directive.ngAfterViewInit();
		expect(directive).toMatchSnapshot();
	});
});
