import { AfterViewInit, Directive, ElementRef, Input } from "@angular/core";

const focusableElements = ["input", "select", "button", "a"];

@Directive({
	selector: "[appAutofocus]",
})
export class AutofocusDirective implements AfterViewInit {
	@Input()
	public set appAutofocus(shouldFocus: boolean) {
		this.shouldFocus = shouldFocus;
		this.checkFocus();
	}

	private shouldFocus = true;

	constructor(private elementRef: ElementRef) {}

	public ngAfterViewInit(): void {
		this.checkFocus();
	}

	private checkFocus(): void {
		if (!this.shouldFocus) {
			return;
		}

		const hostElement: HTMLElement = this.elementRef.nativeElement;

		if (!hostElement) {
			return;
		}

		if (focusableElements.includes(hostElement.tagName.toLowerCase())) {
			hostElement.focus?.();
		} else if (hostElement?.querySelector) {
			for (const tagName of focusableElements) {
				const childElement: HTMLInputElement | null =
					hostElement.querySelector(tagName);
				if (childElement) {
					childElement?.focus?.();
					break;
				}
			}
		}
	}
}
