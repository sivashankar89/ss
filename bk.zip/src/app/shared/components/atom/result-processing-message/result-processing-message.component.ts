import { Component } from "@angular/core";

@Component({
	selector: "app-result-processing-message",
	templateUrl: "./result-processing-message.component.html",
	styleUrls: ["./result-processing-message.component.scss"],
})
export class ResultProcessingMessageComponent {}
