import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { CdsIconComponent } from "@international-payment-platform/design-system-angular";

@Component({
	selector: "app-scroll-to-element",
	templateUrl: "./scroll-to-element.component.html",
	styleUrls: ["./scroll-to-element.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ScrollToElementComponent {
	@Input() target!: HTMLElement;
	@Input() label!: string;
	@Input() icon!: CdsIconComponent["icon"];
	@Input() iconPlacementBefore!: boolean;

	scrollToElement(): void {
		if (!this.target || !this.target.scrollIntoView) {
			return;
		}

		this.target.scrollIntoView({
			block: "center",
			inline: "center",
			behavior: "smooth",
		});
	}
}
