import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ScrollToElementComponent } from "./scroll-to-element.component";

describe("ScrollToElementComponent", () => {
	let component: ScrollToElementComponent;
	let fixture: ComponentFixture<ScrollToElementComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [ScrollToElementComponent],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(ScrollToElementComponent);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
	});

	it(`should return from this 'scrollToElement' method if target is not provided`, () => {
		component.iconPlacementBefore = false;
		fixture.detectChanges();
		component.scrollToElement();
	});

	it(`should execute 'scrollToElement' method`, () => {
		component.iconPlacementBefore = true;
		component.target = document.createElement("div");
		const scrollIntoViewMock = jest.fn();
		window.HTMLElement.prototype.scrollIntoView = scrollIntoViewMock;
		component.scrollToElement();
		expect(scrollIntoViewMock).toHaveBeenCalled();
	});
});
