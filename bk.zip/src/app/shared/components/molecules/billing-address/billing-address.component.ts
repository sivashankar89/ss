import { Component, Input } from "@angular/core";

@Component({
	selector: "app-billing-address",
	templateUrl: "./billing-address.component.html",
	styleUrls: ["./billing-address.component.scss"],
})
export class BillingAddressComponent {
	@Input() address!: any | undefined | null; // Used in two modules which using 2 different model structure.
	@Input() companyName!: any;
}
