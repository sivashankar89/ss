import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { BillingAddressComponent } from "./billing-address.component";
import { transactionsObj } from "../../../../../mocks/constant";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

describe("BillingAddressComponent", () => {
	let component: BillingAddressComponent;
	let fixture: ComponentFixture<BillingAddressComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [BillingAddressComponent],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		});
		fixture = TestBed.createComponent(BillingAddressComponent);
		component = fixture.componentInstance;
	});

	it("should create component instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("Should render contact details", () => {
		component.address = transactionsObj.billing;

		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"shared.address"
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj.billing.company}`
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj.billing.addressLine1}`
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj.billing.addressLine2}`
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj.billing.city}`
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj.billing.region}`
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj.billing.zip}`
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj.billing.country}`
		);
	});

	it("Should pass data to billing and shipping address field", () => {
		component.address = transactionsObj.billing;
		expect(component.address?.company).toEqual(
			`${transactionsObj.billing.company}`
		);
		expect(component.address?.addressLine1).toEqual(
			`${transactionsObj.billing.addressLine1}`
		);
		expect(component.address?.addressLine2).toEqual(
			`${transactionsObj.billing.addressLine2}`
		);
		expect(component.address?.city).toEqual(`${transactionsObj.billing.city}`);
		expect(component.address?.region).toEqual(
			`${transactionsObj.billing.region}`
		);
		expect(component.address?.zip).toEqual(`${transactionsObj.billing.zip}`);
		expect(component.address?.country).toEqual(
			`${transactionsObj.billing.country}`
		);
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(BillingAddressComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
