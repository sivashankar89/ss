import { Component, Input, OnInit } from "@angular/core";

@Component({
	selector: "app-id-input",
	templateUrl: "./id-input.component.html",
	styleUrls: ["./id-input.component.scss"],
})
export class IdInputComponent implements OnInit {
	@Input() labelStr = "";
	@Input() valueVar: any;
	@Input() isOptional = false;
	@Input() name = "";
	constructor() {}

	ngOnInit(): void {}
}
