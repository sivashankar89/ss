import {
	Component,
	EventEmitter,
	Input,
	OnInit,
	Output,
	ViewChild,
} from "@angular/core";
import { BillingAddress, ContactInfo } from "bff-client";
import { initContactInfo } from "../../../../model/new-sale-order.model";
import { SaleInfoService } from "../../../../services/sale-info.service";
import { AddressDetailsComponent } from "../address-details/address-details.component";

@Component({
	selector: "app-primary-billing-details",
	templateUrl: "./primary-billing-details.component.html",
	styleUrls: ["./primary-billing-details.component.scss"],
})
export class PrimaryBillingDetailsComponent implements OnInit {
	@Input() billing!: BillingAddress;
	@Input() contact: ContactInfo = { ...initContactInfo };
	@Input() expandedAddress = {
		billing: false,
		delivery: false,
	};
	@Output() openAddress = new EventEmitter<"billing" | "delivery">();
	isAddressAvailable = false;
	@Output() changeEvent = new EventEmitter();
	addressTab = false;
	contactTab = false;
	@Input() isAmend = false;
	@Output() onChangeFormEvent = new EventEmitter();
	@ViewChild(AddressDetailsComponent) addressDetails!: AddressDetailsComponent;

	constructor(private saleInfoService: SaleInfoService) {}

	ngOnInit(): void {
		this.isAddressAvailable = this.saleInfoService.isBillingAvailable;
		if (this.isAmend) {
			this.checkHeadersEmpty();
			this.isAddressAvailable = true;
		}
	}

	checkHeadersEmpty(): void {
		this.addressTab = false;
		this.contactTab = false;
		const billingConst = this.billing?.address;
		if (billingConst) {
			for (const [key, value] of Object.entries(billingConst)) {
				if (value && value.trim() !== "" && value.trim() !== undefined) {
					this.addressTab = true;
				}
			}
		}

		const contactConst = this.billing?.contact;
		if (contactConst) {
			for (const [key, value] of Object.entries(contactConst)) {
				if (value && value.trim() !== "" && value.trim() !== undefined) {
					this.contactTab = true;
				}
			}
		}

		const nameConst = this.billing?.name;
		if (
			nameConst &&
			nameConst.trim() !== "" &&
			nameConst.trim() !== undefined
		) {
			this.contactTab = true;
		}
	}

	addressUpdate(event: BillingAddress): void {
		this.formAutoUpdate(event);
		this.toggleAddress();
		this.changeEvent.emit(this.billing);
		if (this.saleInfoService.paymentLinkCreated) {
			this.saleInfoService.paymentLinkCreated = false;
			this.saleInfoService.paymentLinkResponse = null;
		}
	}

	formAutoUpdate(event: BillingAddress): void {
		if (!this.billing) {
			this.billing = {};
		}
		this.billing.address = event.address;
		this.billing.contact = event.contact;
		this.billing.name = event.name;
		this.isAddressAvailable = true;
		this.saleInfoService.isBillingAvailable = true;
		this.onChangeFormEvent.emit(this.billing);
	}

	toggleAddress(): void {
		if (this.isAmend) {
			this.checkHeadersEmpty();
			this.isAddressAvailable = true;
		}
		this.openAddress.emit("billing");
	}
}
