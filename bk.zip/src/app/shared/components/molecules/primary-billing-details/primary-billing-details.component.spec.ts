import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { initAddressValues } from "model/new-sale-order.model";
import { SaleInfoService } from "services/sale-info.service";
import { PrimaryBillingDetailsComponent } from "./primary-billing-details.component";

describe("BillingDetailsComponent", () => {
	let component: PrimaryBillingDetailsComponent;
	let fixture: ComponentFixture<PrimaryBillingDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PrimaryBillingDetailsComponent],
			imports: [PipesMockModule],
			providers: [SaleInfoService],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PrimaryBillingDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should update address", () => {
		component.addressUpdate({ ...initAddressValues });
		expect(component.isAddressAvailable).toBeTruthy();
	});
});
