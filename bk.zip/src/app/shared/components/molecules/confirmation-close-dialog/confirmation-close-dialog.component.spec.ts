import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { ConfirmationCloseDialogComponent } from "./confirmation-close-dialog.component";

describe("ConfirmationCloseDialogComponent", () => {
	let component: ConfirmationCloseDialogComponent;
	let fixture: ComponentFixture<ConfirmationCloseDialogComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [ConfirmationCloseDialogComponent],
			imports: [PipesMockModule, CdsModalModule, CdsModalFullscreenModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(ConfirmationCloseDialogComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should call close modal method", () => {
		const service = TestBed.inject(CdsModalService);
		service.closeModal = jest.fn();
		component.onCloseModal(true);
		expect(service.closeModal).toHaveBeenCalled();
	});
});
