import { Component, Output, EventEmitter } from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";

@Component({
	selector: "app-confirmation-close-dialog",
	templateUrl: "./confirmation-close-dialog.component.html",
	styles: [":host ::ng-deep .cds-modal-header__title { font-size: 1.8rem}"],
})
export class ConfirmationCloseDialogComponent {
	@Output() closeModal = new EventEmitter();

	constructor(private modalService: CdsModalService) {}

	onCloseModal(isClose: boolean): void {
		this.closeModal.emit(isClose);
		this.modalService.closeModal();
	}
}
