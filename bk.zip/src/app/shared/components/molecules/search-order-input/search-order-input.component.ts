import { Component, EventEmitter, Input, Output } from "@angular/core";
import { CdsSearchCategory } from "@international-payment-platform/design-system-angular/lib/search/search.model";

@Component({
	selector: "app-search-order-input",
	templateUrl: "./search-order-input.component.html",
})
export class SearchOrderInputComponent {
	@Input() value!: string | undefined | null;
	@Output() valueSubmit = new EventEmitter();
	readonly categories: CdsSearchCategory[] = [
		{
			label: "Order ID",
			value: "orderId",
		},
	];

	onValueChange(value: string): void {
		if (value === "") {
			// if the value is empty it should emit the empty value
			this.valueSubmit.emit(value);
		}
	}

	onSearchSubmitted(value: string): void {
		this.valueSubmit.emit(value || "");
	}
}
