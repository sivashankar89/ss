import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";

import { SearchOrderInputComponent } from "./search-order-input.component";

describe("SearchOrderInputComponent", () => {
	let component: SearchOrderInputComponent;
	let fixture: ComponentFixture<SearchOrderInputComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SearchOrderInputComponent],
			imports: [HttpClientModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SearchOrderInputComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
		expect(fixture).toMatchSnapshot();
	});

	it("it should render the search", () => {
		fixture.detectChanges();

		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"cds-search"
		);
	});

	it("should correctly render the passed @Input value", () => {
		component.value = "search input";
		fixture.detectChanges();
		const compiled = fixture.debugElement.nativeElement;
		expect(compiled.querySelector("cds-search").value).toBe(component.value);
	});

	it("it should call the method onValueChange ", () => {
		const param = "value";
		jest.spyOn(component, "onValueChange");
		component.onValueChange(param);
		expect(component.onValueChange).toHaveBeenCalledWith(param);
	});

	it("it should call the method onSearchSubmitted ", () => {
		const param = "value";
		jest.spyOn(component, "onSearchSubmitted");
		component.onSearchSubmitted(param);
		expect(component.onSearchSubmitted).toHaveBeenCalledWith(param);
	});
});
