import {
	Component,
	EventEmitter,
	Input,
	Optional,
	Output,
	SkipSelf,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { SelectOption } from "shared/models/select-options";

@Component({
	selector: "app-select-box",
	templateUrl: "./select-box.component.html",
	viewProviders: [
		{
			provide: ControlContainer,
			useFactory: (form: any) => form || NgForm,
			deps: [[new SkipSelf(), new Optional(), NgForm]],
		},
	],
})
export class SelectBoxComponent {
	@Input() labelStr = "";
	@Input() value: any = "";
	@Input() isOptional = false;
	@Input() isDisabled = false;
	@Input() hasAutocomplete = false;
	@Input() options: Array<SelectOption<any>> = [];
	@Input() name: any = "select";
	@Input() placeHolder = "";
	@Output() valueChange = new EventEmitter();
	@Output() changeEvent = new EventEmitter();

	constructor(@Optional() public form: NgForm) {}

	selectionChange(event: any): void {
		this.valueChange.emit(event);
		this.changeEvent.emit(event);
	}
}
