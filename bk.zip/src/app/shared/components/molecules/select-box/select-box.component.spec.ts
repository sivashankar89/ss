import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import {
	CdsFormModule,
	CdsSelectModule,
} from "@international-payment-platform/design-system-angular";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { SelectBoxComponent } from "./select-box.component";

describe("SelectBoxComponent", () => {
	let component: SelectBoxComponent;
	let fixture: ComponentFixture<SelectBoxComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SelectBoxComponent],
			imports: [FormsModule, CdsFormModule, CdsSelectModule, PipesMockModule],
			providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SelectBoxComponent);
		component = fixture.componentInstance;
		// fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should render label", () => {
		component.labelStr = "TestFormLabel";
		// fixture.detectChanges();
		const label =
			fixture.debugElement.nativeElement.querySelector("cds-form-label");
		expect(label).toBeTruthy();
	});

	it("should emit value on selection", () => {
		jest.spyOn(component.changeEvent, "emit");
		component.selectionChange("test");
		// fixture.detectChanges();
		expect(component.changeEvent.emit).toHaveBeenCalledWith("test");
	});
});
