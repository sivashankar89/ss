import {
	Component,
	EventEmitter,
	Input,
	Optional,
	Output,
	SkipSelf,
	ViewChild,
} from "@angular/core";
import { ControlContainer, NgForm, NgModel } from "@angular/forms";

@Component({
	selector: "app-input-box",
	templateUrl: "./input-box.component.html",
	viewProviders: [
		{
			provide: ControlContainer,
			useFactory: (form: any) => form || NgForm,
			deps: [[new SkipSelf(), new Optional(), NgForm]],
		},
	],
})
export class InputBoxComponent {
	@Input() inputType = "text";
	@Input() labelStr = "Input";
	@Input() value: any;
	@Input() isOptional = false;
	@Input() name: any = "input";
	@Input() validations: any;
	@Input() customError: any;
	@Output() valueChange = new EventEmitter();
	@Output() changeEvent = new EventEmitter();
	@ViewChild("inputRef") inputRef!: NgModel;

	constructor(@Optional() public form: NgForm) {}

	OnChange(event: any): void {
		this.valueChange.emit(event);
		this.changeEvent.emit(event);
		if (this.isOptional === false && event.trim() === "") {
			this.inputRef.control.setErrors({ required: true });
		}
	}
}
