import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { InputBoxComponent } from "./input-box.component";

describe("InputBoxComponent", () => {
	let component: InputBoxComponent;
	let fixture: ComponentFixture<InputBoxComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [InputBoxComponent],
			imports: [FormsModule, PipesMockModule],
			providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(InputBoxComponent);
		component = fixture.componentInstance;
		// fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should render label", () => {
		component.labelStr = "label-string";
		// fixture.detectChanges();
		const label =
			fixture.debugElement.nativeElement.querySelector("cds-form-label");
		expect(label).toBeTruthy();
	});
});
