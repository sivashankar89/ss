import {
	Component,
	EventEmitter,
	Input,
	Optional,
	Output,
	SkipSelf,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
	selector: "app-email-input",
	templateUrl: "./email-input.component.html",
	styleUrls: ["./email-input.component.scss"],
	viewProviders: [
		{
			provide: ControlContainer,
			useFactory: (form: any) => form || NgForm,
			deps: [[new SkipSelf(), new Optional(), NgForm]],
		},
	],
})
export class EmailInputComponent {
	@Input() labelStr = "Input";
	@Input() value: any;
	@Input() isOptional = false;
	@Input() name: any;
	@Input() isSubmitted = false;
	@Input() validations: any;
	@Output() valueChange = new EventEmitter();

	valueEmit(event: any): void {
		this.valueChange.emit(event);
	}
}
