import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { EventEmitter } from "stream";

import { EmailInputComponent } from "./email-input.component";

describe("EmailInputComponent", () => {
	let component: EmailInputComponent;
	let fixture: ComponentFixture<EmailInputComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [EmailInputComponent],
			imports: [PipesMockModule, FormsModule],
			providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(EmailInputComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
	it("should update address", () => {
		component.valueEmit(new EventEmitter());
		expect(component.valueChange).toBeTruthy();
	});
});
