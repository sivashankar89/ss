import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";

import { SegmentsComponent } from "./segments.component";

describe("SegmentsComponent", () => {
	let component: SegmentsComponent;
	let fixture: ComponentFixture<SegmentsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SegmentsComponent],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SegmentsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
