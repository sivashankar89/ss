import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({
	selector: "app-segments",
	templateUrl: "./segments.component.html",
	styleUrls: ["./segments.component.scss"],
})
export class SegmentsComponent {
	@Input() selectedOption: any;
	@Output() selectedOptionChange = new EventEmitter();
	@Output() segmentChange = new EventEmitter();
	@Input() options: any = [];

	changeEvent(event: any): void {
		this.selectedOptionChange.emit(event);
		this.segmentChange.emit(event);
	}
}
