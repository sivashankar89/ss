import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ContactDetailsComponent } from "./contact-details.component";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { transactionsObj } from "../../../../../mocks/constant";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

describe("ContactDetailsComponent", () => {
	let component: ContactDetailsComponent;
	let fixture: ComponentFixture<ContactDetailsComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [ContactDetailsComponent],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		});
		fixture = TestBed.createComponent(ContactDetailsComponent);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("Should render contact details", () => {
		component.contact = transactionsObj?.contact;
		component.address = transactionsObj?.shipping;

		fixture.detectChanges();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"shared.contact_details"
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj?.shipping?.name}`
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj?.contact?.phone}`
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			`${transactionsObj?.contact?.email}`
		);
	});

	it("should pass values to contact fields", () => {
		component.contact = transactionsObj?.contact;
		component.address = transactionsObj?.shipping;
		expect(component.address.name).toEqual(
			`${transactionsObj?.shipping?.name}`
		);
		expect(component.contact.email).toEqual(
			`${transactionsObj?.contact?.email}`
		);
		expect(component.contact.phone).toEqual(
			`${transactionsObj?.contact?.phone}`
		);
		expect(component.contact.fax).toEqual(`${transactionsObj?.contact?.fax}`);
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(ContactDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
