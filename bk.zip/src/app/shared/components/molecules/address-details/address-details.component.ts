import {
	Component,
	EventEmitter,
	Input,
	OnInit,
	Output,
	OnChanges,
	SimpleChanges,
	ViewChild,
} from "@angular/core";
import {
	Address,
	BillingAddress,
	ContactInfo,
	ShippingAddress,
	Country,
} from "bff-client";
import { CountriesService } from "services/countries.service";
import {
	initAddressValues,
	initContactInfo,
} from "../../../../model/new-sale-order.model";
import { combineLatest, Subject, takeUntil } from "rxjs";
import { TranslateService } from "@tolgee/ngx";
import { CountryArr } from "../../../../model/common.model";

@Component({
	selector: "app-address-details",
	templateUrl: "./address-details.component.html",
	styleUrls: ["./address-details.component.scss"],
})
export class AddressDetailsComponent implements OnInit, OnChanges {
	@Input() value: BillingAddress | ShippingAddress | undefined;
	addressVar: Address = { ...initAddressValues };
	contactVar: ContactInfo = { ...initContactInfo };
	contactName = "";
	@Input() addressName: any = "";
	@Output() changeEvent: any = new EventEmitter();
	@Output() cancelEvent: any = new EventEmitter();
	@Output() onChangeFormEvent: any = new EventEmitter();
	@ViewChild("addressForm") addressForm: any;
	emailLabel = "";
	private unsubsribe = new Subject();
	countryList: CountryArr[] = [];
	defaultCountryName!: string | undefined;
	@Input() isAmend = false;

	constructor(
		private countryservice: CountriesService,
		private translateService: TranslateService
	) {}

	ngOnInit(): void {
		this.emailLabel =
			this.addressName === "Billing" ? "billing_email" : "delivery_email";
		combineLatest([this.countryservice.getDefaultCountry()])
			.pipe(takeUntil(this.unsubsribe))
			.subscribe({
				next: ([defaultCountry]) => {
					if (defaultCountry) {
						if (!this.addressVar.country) {
							this.addressVar.country = defaultCountry.iso31661Alpha3;
							this.autoUpdate();
						}
					}
				},
				error: (error) => {
					return error;
				},
			});

		this.countryservice
			.getCountries()
			.pipe(takeUntil(this.unsubsribe))
			.subscribe({
				next: (country: any) => {
					this.countryList = country
						.sort((a: any, b: any) => {
							const fa = this.translateService
								.instantSafe("countryISO." + a.iso31661Alpha3)
								.toLowerCase();
							const fb = this.translateService
								.instantSafe("countryISO." + b.iso31661Alpha3)
								.toLowerCase();
							if (fa < fb) {
								return -1;
							}
							if (fa > fb) {
								return 1;
							}
							return 0;
						})
						.map((val: any) => {
							return {
								name: this.translateService.instantSafe(
									"countryISO." + val.iso31661Alpha3
								),
								value: val.iso31661Alpha3,
							};
						});
					this.countryList.unshift({
						name: this.translateService.instantSafe("shared.select_country"),
						value: " ",
					});
				},
				error: (error) => {
					return error;
				},
			});
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (!!changes.value?.currentValue) {
			const value = JSON.parse(JSON.stringify(changes.value.currentValue));
			this.addressVar = value?.address || { ...initAddressValues };
			this.contactVar = value?.contact || { ...initContactInfo };
			this.contactName = value.name;
		}
	}

	accept(form: any): void {
		this.changeEvent.emit({
			address: this.addressVar,
			contact: this.contactVar,
			name: this.contactName,
		});
	}

	updateCountry(event: any): void {
		this.addressVar.country = event;
		this.autoUpdate();
	}

	autoUpdate(): void {
		if (this.isAmend) {
			this.onChangeFormEvent.emit({
				address: this.addressVar,
				contact: this.contactVar,
				name: this.contactName,
			});
		}
	}
}
