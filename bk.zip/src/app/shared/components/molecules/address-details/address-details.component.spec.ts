import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA, SimpleChange } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule } from "@angular/forms";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { initAddressValues, initContactInfo } from "model/new-sale-order.model";

import { AddressDetailsComponent } from "./address-details.component";
import { TelemetryService } from "services/telemetry.service";

describe("AddressDetailsComponent", () => {
	let component: AddressDetailsComponent;
	let fixture: ComponentFixture<AddressDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [AddressDetailsComponent],
			imports: [PipesMockModule, HttpClientTestingModule, FormsModule],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(AddressDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should assign value for address", () => {
		const value = { ...initAddressValues };
		const change = { value: new SimpleChange({}, { address: value }, false) };
		component.ngOnChanges(change);
		expect(component.addressVar).toMatchObject(value);
	});

	it("should assign value for contact", () => {
		const value = { ...initContactInfo };
		const change = { value: new SimpleChange({}, { contact: value }, false) };
		component.ngOnChanges(change);
		expect(component.contactVar).toMatchObject(value);
	});

	it("should emit details on accept", () => {
		jest.spyOn(component.changeEvent, "emit");
		const address = {
			address1: "Street address",
			address2: "Landmark",
			city: "city name",
			region: "region name",
			postalCode: "908090",
			country: "country name",
			name: "Demo",
			company: "Unit Testing",
		};
		component.addressVar = address;
		const contact = {
			email: "test@unit.com",
			fax: "9080908090",
			phone: "9080908090",
			mobilePhone: "9080908090",
		};
		component.contactVar = contact;
		fixture.detectChanges();
		expect(component.addressForm.valid).toBeTruthy();
		component.accept(component.addressForm);
		fixture.detectChanges();
		const emitValue = { address, contact };
		expect(component.changeEvent.emit).toHaveBeenCalled();
	});
});
