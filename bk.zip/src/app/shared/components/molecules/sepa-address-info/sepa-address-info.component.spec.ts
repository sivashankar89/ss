import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { TranslateService } from "@tolgee/ngx";
import { SepaAddressInfoComponent } from "./sepa-address-info.component";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { SaleInfoService } from "services/sale-info.service";
import { TelemetryService } from "services/telemetry.service";

describe("SepaAddressInfoComponent", () => {
	let component: SepaAddressInfoComponent;
	let fixture: ComponentFixture<SepaAddressInfoComponent>;
	let saleInfoService: SaleInfoService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SepaAddressInfoComponent],
			imports: [PipesMockModule, HttpClientTestingModule],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [
				SaleInfoService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SepaAddressInfoComponent);
		component = fixture.componentInstance;
		saleInfoService = TestBed.get(SaleInfoService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("Check billing available", () => {
		component.addressVar.address1 = "Test address";
		component.isBillingAvailable();
		expect(saleInfoService.isBillingAvailable).toEqual(true);
	});
});
