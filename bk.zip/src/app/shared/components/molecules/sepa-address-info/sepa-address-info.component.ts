import { Component, Input, OnInit } from "@angular/core";
import { Address, BillingAddress, PaymentRequest } from "bff-client";
import { CountryArr } from "model/common.model";
import { initAddressValues } from "../../../../model/new-sale-order.model";
import { CountriesService } from "services/countries.service";
import { Subject, takeUntil } from "rxjs";
import { TranslateService } from "@tolgee/ngx";
import { SaleInfoService } from "services/sale-info.service";

@Component({
	selector: "app-sepa-address-info",
	templateUrl: "./sepa-address-info.component.html",
	styleUrls: ["./sepa-address-info.component.scss"],
})
export class SepaAddressInfoComponent implements OnInit {
	addressVar: Address = { ...initAddressValues };
	countryList: CountryArr[] = [];
	private unsubsribe = new Subject();
	orderDetails!: PaymentRequest;
	@Input() billing: BillingAddress | undefined;
	constructor(
		private countryservice: CountriesService,
		private translateService: TranslateService,
		private saleinfoService: SaleInfoService
	) {}

	ngOnInit(): void {
		this.addressVar = this.billing?.address || { ...initAddressValues };
		this.countryservice
			.getCountries()
			.pipe(takeUntil(this.unsubsribe))
			.subscribe({
				next: (country: any) => {
					this.countryList = country
						.sort((a: any, b: any) => {
							const fa = this.translateService
								.instantSafe("countryISO." + a.iso31661Alpha3)
								.toLowerCase();
							const fb = this.translateService
								.instantSafe("countryISO." + b.iso31661Alpha3)
								.toLowerCase();
							if (fa < fb) {
								return -1;
							}
							if (fa > fb) {
								return 1;
							}
							return 0;
						})
						.map((val: any) => {
							return {
								name: this.translateService.instantSafe(
									"countryISO." + val.iso31661Alpha3
								),
								value: val.iso31661Alpha3,
							};
						});
				},
				error: (error) => {
					return error;
				},
			});
	}

	isBillingAvailable(): void {
		if (
			this.addressVar.address1?.trim()! == "" ||
			this.addressVar.city?.trim()! == "" ||
			this.addressVar.country?.trim()! == "" ||
			this.addressVar.postalCode?.trim()! == ""
		) {
			this.saleinfoService.isBillingAvailable = true;
		}
	}
}
