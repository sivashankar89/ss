import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { TotalAmountComponent } from "./total-amount.component";

describe("TotalAmountComponent", () => {
	let component: TotalAmountComponent;
	let fixture: ComponentFixture<TotalAmountComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [TotalAmountComponent],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(TotalAmountComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("check total amount calculation", () => {
		component.amounts = ["10", "20"];
		jest.spyOn(component.totalAmountChange, "emit");
		component.ngOnChanges();
		fixture.detectChanges();
		expect(component.totalAmountChange.emit).toHaveBeenCalledWith("30");
	});
});
