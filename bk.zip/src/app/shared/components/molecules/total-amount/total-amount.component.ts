import {
	Component,
	Input,
	OnChanges,
	Output,
	EventEmitter,
} from "@angular/core";

@Component({
	selector: "app-total-amount",
	templateUrl: "./total-amount.component.html",
	styleUrls: ["./total-amount.component.scss"],
})
export class TotalAmountComponent implements OnChanges {
	@Input() amounts: any[] = [];
	@Input() currencyObj: any;
	@Output() changeEvent = new EventEmitter();
	totalAmount = 0.0;
	@Output() totalAmountChange = new EventEmitter();
	ngOnChanges(): void {
		this.totalAmount = this.amounts.reduce((a, c) => this.totalCal(a, c), 0);
		this.totalAmountChange.emit(this.totalAmount);
		this.changeEvent.emit(this.totalAmount);
	}

	totalCal(acc: any, amount: any): string {
		return (parseFloat(acc) + (parseFloat(amount) || 0)).toFixed(
			!!this.currencyObj?.decimalPlaces ? this.currencyObj.decimalPlaces : 0
		);
	}
}
