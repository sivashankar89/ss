import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { AddressComponent } from "./address.component";

describe("AddressComponent", () => {
	let component: AddressComponent;
	let fixture: ComponentFixture<AddressComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [AddressComponent],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(AddressComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
