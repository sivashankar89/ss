import { Component, Input } from "@angular/core";
import { BillingAddress, ShippingAddress } from "bff-client";

@Component({
	selector: "app-address",
	templateUrl: "./address.component.html",
	styleUrls: ["./address.component.scss"],
})
export class AddressComponent {
	@Input() address!: BillingAddress | ShippingAddress | undefined;
}
