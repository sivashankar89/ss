import { NO_ERRORS_SCHEMA } from "@angular/core";
import { FormsModule, NgForm } from "@angular/forms";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { CounterComponent } from "./counter.component";

describe("CounterComponent", () => {
	let component: CounterComponent;
	let fixture: ComponentFixture<CounterComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [CounterComponent],
			imports: [FormsModule, PipesMockModule],
			providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CounterComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
