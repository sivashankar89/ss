import {
	Component,
	EventEmitter,
	Input,
	Optional,
	Output,
	SkipSelf,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
	selector: "app-counter",
	templateUrl: "./counter.component.html",
	viewProviders: [
		{
			provide: ControlContainer,
			useFactory: (form: any) => form || NgForm,
			deps: [[new SkipSelf(), new Optional(), NgForm]],
		},
	],
})
export class CounterComponent {
	@Input() isOptional = false;
	@Input() name: any = "input";
	@Input() value: any;
	@Output() valueChange = new EventEmitter();

	constructor(@Optional() public form: NgForm) {}

	OnChange(event: any): void {
		this.valueChange.emit(event);
	}
}
