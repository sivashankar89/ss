import {
	Component,
	EventEmitter,
	Input,
	OnChanges,
	Output,
	SimpleChanges,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
	selector: "app-radio-button",
	templateUrl: "./radio-button.component.html",
	viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RadioButtonComponent implements OnChanges {
	@Input() value: any;
	@Input() isOptional = false;
	@Input() name = "InputRadio";
	@Input() options!: any;
	@Input() isSubmitted = false;
	@Output() valueChange = new EventEmitter();
	@Output() changeEvent = new EventEmitter();

	ngOnChanges(change: SimpleChanges): void {
		this.changeEvent.emit(this.value);
	}
}
