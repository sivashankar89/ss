import {
	Component,
	forwardRef,
	Inject,
	Injector,
	Input,
	OnChanges,
	OnInit,
	SimpleChanges,
	ViewChild,
} from "@angular/core";
import {
	ControlValueAccessor,
	FormControl,
	FormControlDirective,
	FormControlName,
	FormGroupDirective,
	NgControl,
	NgModel,
	NG_VALIDATORS,
	NG_VALUE_ACCESSOR,
	ValidationErrors,
	Validator,
} from "@angular/forms";
import { Currency } from "bff-client";
import { take } from "rxjs";
import { CurrenciesService } from "services/currencies.service";
import { countDecimals } from "utils/common.utils";

@Component({
	selector: "app-amount-input-box",
	templateUrl: "./amount-input-box.component.html",
	styleUrls: ["./amount-input-box.component.scss"],
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AmountInputBoxComponent),
			multi: true,
		},
		{
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => AmountInputBoxComponent),
			multi: true,
		},
	],
})
export class AmountInputBoxComponent
	implements ControlValueAccessor, Validator, OnChanges, OnInit
{
	@Input() label!: string;
	@Input() isOptional = true;
	@Input() currency!: string;
	@Input() hideError!: boolean;
	@ViewChild(NgModel) inputControl!: NgModel;
	public control!: FormControl;
	public valueDisplay = "";
	public currencyObject!: Currency;
	public placeholderValue = "0";
	private focused = false;
	private inputChanged = false;
	decimalSeparator = ".";

	onChange: any = () => {};
	onTouch: any = () => {};

	get canShowValidation(): boolean {
		if (!this.inputControl || this.inputControl?.valid) {
			return false;
		}
		if (
			this.hideError ||
			!(this.inputControl?.dirty || this.inputControl?.touched)
		) {
			return false;
		}
		return true;
	}

	constructor(
		private cs: CurrenciesService,
		@Inject(Injector) private injector: Injector
	) {}

	ngOnInit(): void {
		const injectedControl = this.injector.get(NgControl);

		switch (injectedControl.constructor) {
			case NgModel:
				const { control, update } = injectedControl as NgModel;
				this.control = control;
				this.control.valueChanges.subscribe((value: any) => update.emit(value));
				break;
			case FormControlName:
				this.control = this.injector
					.get(FormGroupDirective)
					.getControl(injectedControl as FormControlName);
				break;
			default:
				this.control = (injectedControl as FormControlDirective)
					.form as FormControl;
				break;
		}
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes.currency) {
			const currency = changes.currency.currentValue;
			this.cs
				.getCurrency(currency)
				.pipe(take(1))
				.subscribe((c) => {
					this.decimalSeparator = this.cs.getDecimalSepartor();
					this.currencyObject = c;
					this.placeholderValue = this.convertNumberDecimalPlaces("0");
					this.valueDisplay = this.convertNumberDecimalPlaces(
						this.valueDisplay
					);
					const splitNumbers = this.valueDisplay.split(".");
					const decimals = splitNumbers.length > 1 ? splitNumbers[1] : "";
					if (
						c?.decimalPlaces !== undefined &&
						decimals.split("").length < c.decimalPlaces
					) {
						this.valueDisplay = this.convertNumberDecimalPlaces(
							this.valueDisplay
						);
					}
					this.value = this.valueDisplay;
					if (this.inputControl) {
						this.inputControl.control.markAsTouched();
						this.inputControl.control.updateValueAndValidity();
					}
					if (this.control) {
						this.control.markAsTouched();
						this.control.updateValueAndValidity();
					}
				});
		}
	}

	validate(c: FormControl): ValidationErrors | null {
		const fieldValue: string = c.value
			? c.value.toString().replace(this.decimalSeparator, ".").trim()
			: "";

		this.inputControl?.control.setValidators(c.validator);

		if (
			this.isOptional === false &&
			(fieldValue === "" || parseFloat(fieldValue) === 0)
		) {
			return {
				required: true,
			};
		}

		if (fieldValue === "") {
			return null;
		}

		const splitNumbers = fieldValue.split(".");
		if (splitNumbers.every((x) => x === "" || x.match(/^\d*?$/)) === false) {
			return {
				nan: true,
			};
		}

		const decimalPlaces = this.currencyObject?.decimalPlaces;
		const decimals = splitNumbers.length > 1 ? splitNumbers[1] : "";
		if (
			decimalPlaces !== 0 &&
			decimalPlaces !== undefined &&
			decimals.split("").length > decimalPlaces
		) {
			return {
				highDecimals: { max: this.currencyObject.decimalPlaces },
			};
		}
		return null;
	}

	set value(val: string) {
		this.onChange(val);
		this.onTouch(val);
	}

	writeValue(value: string): void {
		if (!this.inputChanged) {
			this.valueDisplay = this.convertNumberDecimalPlaces(value);
			if (
				this.focused &&
				(!value || value.trim() === "" || parseFloat(value) === 0)
			) {
				this.valueDisplay = "";
			}
		}
		this.inputChanged = false;
	}

	onInputChange(e: any): void {
		this.inputChanged = true;
		this.valueDisplay = e.target?.value ?? "";
		this.value = this.valueDisplay
			.toString()
			.replace(this.decimalSeparator, ".");
	}

	onFocus(e: any): void {
		this.focused = true;
		const value = e.target?.value;
		if (!value || value.trim() === "" || parseFloat(value) === 0) {
			this.valueDisplay = "";
		}
	}

	onBlur(e: any): void {
		this.inputChanged = false;
		this.focused = false;
		this.valueDisplay = this.convertNumberDecimalPlaces(e.target?.value);
		this.value = this.valueDisplay
			.toString()
			.replace(this.decimalSeparator, ".");
	}

	registerOnChange(fn: any): void {
		this.onChange = fn;
	}

	registerOnTouched(fn: any): void {
		this.onTouch = fn;
	}

	convertNumberDecimalPlaces(value: string | number): string {
		value = value ? value.toString().replace(this.decimalSeparator, ".") : "";
		value = value
			.toString()
			.replace(/[^0-9\.]+/g, "")
			.trim();

		value = parseFloat(value);

		if (isNaN(value)) {
			value = 0;
		}

		const decimalPlaces = this.currencyObject?.decimalPlaces ?? 0;
		const decimalCount = countDecimals(value);

		if (decimalCount < decimalPlaces) {
			value = value.toFixed(decimalPlaces);
		}
		return value.toString().replace(".", this.decimalSeparator);
	}
}
