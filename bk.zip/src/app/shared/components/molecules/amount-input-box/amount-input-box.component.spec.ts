import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { FormControl, FormsModule, NgControl } from "@angular/forms";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { DecimalPlacesPipeModule } from "pipes";
import { of } from "rxjs";
import { CurrenciesService } from "services/currencies.service";

import { AmountInputBoxComponent } from "./amount-input-box.component";

const currencyDetailsMock = {
	loading: false,
	value: {
		decimalPlaces: 2,
		defaultCurrency: true,
		literalCurrencyCode: "EUR",
		numericCurrencyCode: "978",
	},
};

describe("AmountInputBoxComponent", () => {
	let component: AmountInputBoxComponent;
	let fixture: ComponentFixture<AmountInputBoxComponent>;
	let currencyService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [AmountInputBoxComponent],
			imports: [HttpClientModule, PipesMockModule, FormsModule],
			providers: [{ provide: NgControl, useValue: new FormControl() }],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(async () => {
		fixture = TestBed.createComponent(AmountInputBoxComponent);
		component = fixture.componentInstance;
		currencyService = TestBed.inject(CurrenciesService);
		currencyService.getCurrency = jest
			.fn()
			.mockReturnValue(of(currencyDetailsMock));
		currencyService.getDecimalSepartor = jest.fn().mockReturnValue(".");
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should call the method onFocus ", () => {
		const param = "0";
		const onFocusSpy = jest.spyOn(component, "onFocus");
		component.onFocus(param);
		expect(onFocusSpy).toHaveBeenCalledWith(param);
	});

	it("it should call the method onFocus with value", () => {
		const param = { value: "1" };
		const onFocusSpy = jest.spyOn(component, "onFocus");
		component.onFocus(param);
		expect(onFocusSpy).toHaveBeenCalledWith(param);
	});

	it("it should call the method onBlur with string param", () => {
		const param = { value: 0 };
		component.currencyObject = currencyDetailsMock.value;
		const onBlurSpy = jest.spyOn(component, "onBlur");
		component.onBlur(param);
		expect(onBlurSpy).toHaveBeenCalledWith(param);
	});

	it("it should call the method onBlur with number param", () => {
		const param = { value: 1 };
		component.currencyObject = currencyDetailsMock.value;
		const onBlurSpy = jest.spyOn(component, "onBlur");
		component.onBlur(param);
		expect(onBlurSpy).toHaveBeenCalledWith(param);
	});

	it("it should call the method set Value", () => {
		component.value = "test";
		component.valueDisplay = "1";
		expect(component.valueDisplay).toBe("1");
	});
});
