import { Component, OnInit } from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { CardService } from "../../../../services/card.service";

@Component({
	selector: "app-store-card-brands",
	templateUrl: "./store-card-brands.component.html",
	styleUrls: ["./store-card-brands.component.scss"],
})
export class StoreCardBrandsComponent implements OnInit {
	cardBrands = [];
	constructor(
		private modalService: CdsModalService,
		private cardService: CardService
	) {}

	ngOnInit(): void {
		this.cardService.getAvailableBrands().subscribe({
			next: (data) => {
				if (!!data.brands) {
					this.cardBrands = data.brands;
				}
			},
			error: (err) => {
				return err;
			},
		});
	}

	closeModal(): void {
		this.modalService.closeModal();
	}
}
