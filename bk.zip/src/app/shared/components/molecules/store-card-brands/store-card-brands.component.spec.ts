import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { Observable } from "rxjs";
import { CardService } from "services/card.service";

import { StoreCardBrandsComponent } from "./store-card-brands.component";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("StoreCardBrandsComponent", () => {
	let component: StoreCardBrandsComponent;
	let fixture: ComponentFixture<StoreCardBrandsComponent>;
	let modalService: CdsModalService;
	let cardService: CardService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [StoreCardBrandsComponent],
			imports: [
				HttpClientTestingModule,
				PipesMockModule,
				CdsModalModule,
				CdsModalFullscreenModule,
			],
			providers: [
				CardService,
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(StoreCardBrandsComponent);
		component = fixture.componentInstance;
		modalService = TestBed.get(CdsModalService);
		cardService = TestBed.get(CardService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
	it("get list of available card brands", fakeAsync(() => {
		const brands = cardService.getAvailableBrands();
		jest.spyOn(cardService, "getAvailableBrands").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(brands);
				return observer;
			})
		);
		component.ngOnInit();
		tick();
		expect(component.cardBrands).toBeTruthy();
	}));
	it("Should close modal", () => {
		jest.spyOn(modalService, "closeModal");
		component.closeModal();
		fixture.detectChanges();
		expect(modalService.closeModal).toHaveBeenCalled();
	});
});
