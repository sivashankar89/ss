import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
} from "@international-payment-platform/design-system-angular";
import { OrderEntrySummaryModule } from "../shared/modules/order-entry-summary/order-entry-summary.module";
import { SharedModule } from "../shared/shared.module";
import { NewSaleRoutingModule } from "./new-sale-routing.module";
import { NewsaleLayoutComponent } from "./page/newsale-layout/newsale-layout.component";
import { NewsaleStepperComponent } from "./page/newsale-stepper/newsale-stepper.component";

@NgModule({
	declarations: [NewsaleStepperComponent, NewsaleLayoutComponent],
	imports: [
		CommonModule,
		CdsModalModule,
		CdsModalFullscreenModule,
		FormsModule,
		SharedModule,
		OrderEntrySummaryModule,
		NewSaleRoutingModule,
	],
})
export class NewSaleModule {}
