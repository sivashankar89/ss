import {
	AfterViewInit,
	Component,
	OnDestroy,
	OnInit,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { SaleInfoService } from "../../../services/sale-info.service";
import { ApiErrorResponse } from "../../../model/error.model";
import { DatePipe } from "@angular/common";
import { OpenOrderDetailsService } from "../../../order-details/services/open-order-details.service";
import {
	PAGE_FROM,
	PAYMENT_TYPE,
} from "../../../enum/primary.transaction.enum";
import {
	AuthenticationService,
	TitleService,
} from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import {
	PaymentBffService,
	PaymentResponse,
	RequestType,
	TransactionStatus,
} from "bff-client";
import { ReplaySubject, takeUntil } from "rxjs";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { SessionStorageService } from "utils/session-storage.service";

@Component({
	selector: "app-payment-success-failure",
	templateUrl: "./payment-success-failure.component.html",
	styleUrls: ["./payment-success-failure.component.scss"],
})
export class PaymentSuccessFailureComponent
	implements OnInit, AfterViewInit, OnDestroy
{
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	@ViewChild("modalFooterOptionalPrimaryBtn", { read: TemplateRef })
	modalFooterOptionalPrimaryBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn2", { read: TemplateRef })
	modalFooterPrimaryBtn2!: TemplateRef<any>;
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);
	isLoadingRes = true;
	public completeTransaction!: PaymentResponse | undefined;
	public recurringT!: PaymentResponse | undefined;
	public error!: ApiErrorResponse | undefined;
	paymentResError!: PaymentResponse | undefined;
	transactionOrderId!: string;
	totamount: any;
	payLoadType: any;
	performAnother = "";
	translateTransType = "";
	isTokenGeneration = false;
	generatedToken: string | undefined = "";
	isCopied = false;
	toastOpen = true;
	showViewTreansaction = true;
	isTokenChecked = false;
	tokenConfirmed = false;
	tokenGerationChecked = this.saleinfoService.isTokenGenerateClicked;
	recurringFutureCurreny!: string | undefined;

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private modalService: CdsModalService,
		private saleinfoService: SaleInfoService,
		private datePipe: DatePipe,
		private openOrderDetailsService: OpenOrderDetailsService,
		private titleService: TitleService,
		private translateService: TranslateService,
		private paymentBff: PaymentBffService,
		private authenticationService: AuthenticationService,
		private storageService: SessionStorageService
	) {
		this.initiateTitle();
	}

	initiateTitle(): void {
		if (this.saleinfoService.pageToInitiate === PAGE_FROM.SALE) {
			this.payLoadType = RequestType.PaymentCardSaleTransaction;
			this.performAnother = this.translateService.instantSafe(
				"new_sale.perform_another"
			);
			this.translateTransType = "new_sale";
		} else if (this.saleinfoService.pageToInitiate === PAGE_FROM.PREAUTH) {
			this.payLoadType = RequestType.PaymentCardPreAuthTransaction;
			this.performAnother = this.translateService.instantSafe(
				"pre-auth.perform_another"
			);
			this.translateTransType = "pre-auth";
		} else if (this.saleinfoService.pageToInitiate === PAGE_FROM.CREDIT) {
			this.payLoadType = RequestType.PaymentCardCreditTransaction;
			this.performAnother = this.translateService.instantSafe(
				"credit.perform_another"
			);
			this.translateTransType = "credit";
		}

		this.showViewTreansaction = this.authenticationService
			.getPermissions()
			.includes(VTPaymentPermissions.EcomVTOrderDetailsView);
	}

	ngOnInit(): void {
		if (this.saleinfoService.paymentType === PAYMENT_TYPE.SEPA) {
			this.submitSingleSepaPayment();
		} else if (this.saleinfoService.paymentType === PAYMENT_TYPE.CARD) {
			this.submitSingleCardPayment();
		} else if (
			this.saleinfoService.paymentType === PAYMENT_TYPE.CARD_RECURRING
		) {
			this.submitRecurringPayment();
		} else if (this.saleinfoService.paymentType === PAYMENT_TYPE.TOKEN) {
			this.submitTokenPayment();
		}
	}

	submitRecurringPayment(): void {
		this.saleinfoService
			.getRecurringPayload$()
			.pipe(takeUntil(this.destroyed$))
			.subscribe((scheduledPaymentRequest) => {
				if (!!scheduledPaymentRequest?.startDate) {
					scheduledPaymentRequest.startDate = this.datePipe
						.transform(scheduledPaymentRequest.startDate, "yyyy-MM-dd")
						?.toString();
				}
				if (scheduledPaymentRequest) {
					this.paymentBff
						.schedulePayment({
							authorizerId: this.storageService.getStoreId(),
							selectedGatewayServiceEnvironment:
								this.storageService.getGatewayEnvironment(),
							scheduledPaymentRequest: scheduledPaymentRequest,
						})
						.subscribe({
							next: (res) => {
								if (res.error) {
									this.EcomErrorHandler(res);
									if (this.tokenGerationChecked) {
										this.isTokenChecked = true;
										this.processTokenConfirmation();
									}
								} else if (
									res?.requestStatus !== "SUCCESS" &&
									res?.transactionResponse?.transactionStatus !==
										TransactionStatus.Approved
								) {
									res.error = {
										message: res?.transactionResponse?.approvalCode,
									};
									this.EcomErrorHandler(res);
									if (this.tokenGerationChecked) {
										this.isTokenChecked = true;
										this.processTokenConfirmation();
									}
								} else {
									this.titleService.setTitle(
										this.translateService.instantSafe(
											this.translateTransType + ".success_message"
										)
									);
									this.isLoadingRes = false;
									this.recurringT = res;
									this.transactionOrderId = res.orderId || "";
									this.recurringFutureCurreny =
										scheduledPaymentRequest.transactionAmount?.currency;
									if (this.saleinfoService.tokenToGenerate) {
										this.isTokenGeneration = true;
										const cardRequest: object = {
											requestType:
												RequestType.PaymentCardPaymentTokenizationRequest,
											paymentCard:
												scheduledPaymentRequest?.paymentMethod?.paymentCard,
											createToken: {},
										};
										this.paymentBff
											.generatePaymentCardToken({
												authorizerId: this.storageService.getStoreId(),
												selectedGatewayServiceEnvironment:
													this.storageService.getGatewayEnvironment(),
												cardRequest: cardRequest,
											})
											.subscribe({
												next: (tokenReq) => {
													this.generatedToken = tokenReq.paymentToken?.value;
												},
											});
									}
								}
							},
							error: (err) => {
								this.titleService.setTitle(
									this.translateService.instantSafe(
										this.translateTransType + ".unsuccess_message"
									)
								);
								this.isLoadingRes = false;
								this.error = err.error;
								this.transactionOrderId = err?.error?.orderId;
								if (this.tokenGerationChecked) {
									this.isTokenChecked = true;
									this.processTokenConfirmation();
								}
							},
						});
				}
			});
	}

	submitSingleCardPayment(): void {
		this.saleinfoService
			.getSinglePaymentPayload$()
			.pipe(takeUntil(this.destroyed$))
			.subscribe((paymentRequest) => {
				this.totamount = paymentRequest.transactionAmount.total;
				paymentRequest.requestType = this.payLoadType;
				this.paymentBff
					.doPrimaryTransaction({
						authorizerId: this.storageService.getStoreId(),
						selectedGatewayServiceEnvironment:
							this.storageService.getGatewayEnvironment(),
						paymentRequestV2: paymentRequest,
					})
					.subscribe({
						next: (res) => {
							if (res.error) {
								this.EcomErrorHandler(res);
								if (this.tokenGerationChecked) {
									this.isTokenChecked = true;
									this.processTokenConfirmation();
								}
							} else if (
								res?.transactionStatus !== TransactionStatus.Approved
							) {
								res.error = {
									message: res?.approvalCode,
								};
								this.EcomErrorHandler(res);
								if (this.tokenGerationChecked) {
									this.isTokenChecked = true;
									this.processTokenConfirmation();
								}
							} else {
								this.titleService.setTitle(
									this.translateService.instantSafe(
										this.translateTransType + ".success_message"
									)
								);
								this.isLoadingRes = false;
								this.completeTransaction = res;
								this.transactionOrderId = res.orderId || "";
								if (this.completeTransaction.paymentToken?.value) {
									this.isTokenGeneration = true;
									this.generatedToken =
										this.completeTransaction.paymentToken.value;
								}
							}
						},
						error: (error) => {
							this.titleService.setTitle(
								this.translateService.instantSafe(
									this.translateTransType + ".unsuccess_message"
								)
							);
							this.isLoadingRes = false;
							this.error = error.error;
							this.transactionOrderId = error?.error?.orderId;
							if (this.tokenGerationChecked) {
								this.isTokenChecked = true;
								this.processTokenConfirmation();
							}
						},
					});
			});
	}

	EcomErrorHandler(res: PaymentResponse): void {
		this.titleService.setTitle(
			this.translateService.instantSafe(
				this.translateTransType + ".unsuccess_message"
			)
		);
		this.isLoadingRes = false;
		this.paymentResError = res;
		this.transactionOrderId = res.orderId || "";
	}

	submitSingleSepaPayment(): void {
		this.saleinfoService
			.getSinglePaymentPayload$()
			.pipe(takeUntil(this.destroyed$))
			.subscribe((paymentRequest) => {
				this.totamount = paymentRequest.transactionAmount.total;
				const myDate = this.datePipe.transform(new Date(), "yyyy-MM-dd");
				if (this.saleinfoService.pageToInitiate === PAGE_FROM.SALE) {
					paymentRequest.requestType = RequestType.SepaSaleTransaction;
					if (paymentRequest.paymentMethod.sepa.mandate.type === "SINGLE") {
						paymentRequest.paymentMethod.sepa.mandate.signatureDate = myDate;
					} else {
						paymentRequest.paymentMethod.sepa.mandate.signatureDate =
							this.datePipe
								.transform(
									paymentRequest.paymentMethod.sepa.mandate.signatureDate,
									"yyyy-MM-dd"
								)
								?.toString();
					}
				} else if (this.saleinfoService.pageToInitiate === PAGE_FROM.CREDIT) {
					delete paymentRequest.paymentMethod.sepa.mandate;
					paymentRequest.requestType = RequestType.SepaCreditTransaction;
				}
				this.paymentBff
					.doPrimaryTransaction({
						authorizerId: this.storageService.getStoreId(),
						paymentRequestV2: paymentRequest,
						selectedGatewayServiceEnvironment:
							this.storageService.getGatewayEnvironment(),
					})
					.pipe(takeUntil(this.destroyed$))
					.subscribe({
						next: (res) => {
							if (res.error) {
								this.EcomErrorHandler(res);
							} else if (
								res?.transactionStatus !== TransactionStatus.Approved
							) {
								res.error = {
									message: res?.approvalCode,
								};
								this.EcomErrorHandler(res);
							} else {
								this.isLoadingRes = false;
								this.completeTransaction = res;
								this.titleService.setTitle(
									this.translateService.instantSafe(
										this.translateTransType + ".success_message"
									)
								);
								this.transactionOrderId = res.orderId || "";
							}
						},
						error: (errors) => {
							this.titleService.setTitle(
								this.translateService.instantSafe(
									this.translateTransType + ".unsuccess_message"
								)
							);
							this.isLoadingRes = false;
							this.error = errors.error;
							this.transactionOrderId = errors?.error?.orderId;
						},
					});
			});
	}

	submitTokenPayment(): void {
		this.saleinfoService
			.getSinglePaymentPayload$()
			.pipe(takeUntil(this.destroyed$))
			.subscribe((paymentRequest) => {
				this.totamount = paymentRequest.transactionAmount.total;
				if (this.saleinfoService.pageToInitiate === PAGE_FROM.SALE) {
					paymentRequest.requestType = RequestType.PaymentTokenSaleTransaction;
				} else if (this.saleinfoService.pageToInitiate === PAGE_FROM.CREDIT) {
					paymentRequest.requestType =
						RequestType.PaymentTokenCreditTransaction;
				} else if (this.saleinfoService.pageToInitiate === PAGE_FROM.PREAUTH) {
					paymentRequest.requestType =
						RequestType.PaymentTokenPreAuthTransaction;
				}
				this.paymentBff
					.doPrimaryTransaction({
						authorizerId: this.storageService.getStoreId(),
						selectedGatewayServiceEnvironment:
							this.storageService.getGatewayEnvironment(),
						paymentRequestV2: paymentRequest,
					})
					.pipe(takeUntil(this.destroyed$))
					.subscribe({
						next: (res) => {
							if (res.error) {
								this.EcomErrorHandler(res);
							} else if (
								res?.transactionStatus !== TransactionStatus.Approved
							) {
								res.error = {
									message: res?.approvalCode,
								};
								this.EcomErrorHandler(res);
							} else {
								this.isLoadingRes = false;
								this.completeTransaction = res;
								this.titleService.setTitle(
									this.translateService.instantSafe(
										this.translateTransType + ".success_message"
									)
								);
								this.transactionOrderId = res.orderId || "";
							}
						},
						error: (errors) => {
							this.titleService.setTitle(
								this.translateService.instantSafe(
									this.translateTransType + ".unsuccess_message"
								)
							);
							this.isLoadingRes = false;
							this.error = errors.error;
							this.transactionOrderId = errors?.error?.orderId;
						},
					});
			});
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			OptPrimaryBtn: this.tokenGerationChecked
				? ""
				: this.modalFooterOptionalPrimaryBtn,
			primaryBtn: this.tokenGerationChecked
				? this.modalFooterPrimaryBtn2
				: this.modalFooterPrimaryBtn,
		});
	}

	newTransaction(): void {
		this.stepperComponent.goStep(0);
	}

	closeModal(): void {
		this.modalService.closeModal();
	}

	viewTransaction(): void {
		this.openOrderDetailsService.openOrderDetailsModal(this.transactionOrderId);
	}

	ngOnDestroy(): void {
		this.destroyed$.next();
		this.destroyed$.complete();
		this.saleinfoService.resetSaleInfo();
	}

	copyToken(generatedToken: any): void {
		navigator?.clipboard?.writeText(generatedToken).then(() => {
			this.isCopied = true;
			this.toastOpen = true;
		});
	}

	tokenConfirmation(): void {
		this.isTokenChecked = !this.isTokenChecked;
	}

	processTokenConfirmation(): void {
		if (this.isTokenChecked) {
			this.tokenConfirmed = true;
			this.stepperComponent.loadFooterTemplateRefs({
				OptPrimaryBtn: this.modalFooterOptionalPrimaryBtn,
				primaryBtn: this.modalFooterPrimaryBtn,
			});
		}
	}

	closeToast(): void {
		this.toastOpen = false;
	}
}
