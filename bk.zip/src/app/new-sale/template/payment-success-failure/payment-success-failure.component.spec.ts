import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { DatePipe } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { TitleService } from "@international-payment-platform/portal-core";
import { PAGE_FROM, PAYMENT_TYPE } from "enum/primary.transaction.enum";
import { paymentSuccessResponse } from "mocks/new-sale-order.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";
import { of, Observable, catchError, throwError } from "rxjs";
import { SaleInfoService } from "services/sale-info.service";
import { StepperFullScreenComponent } from "shared/template/stepper-full-screen/stepper-full-screen.component";
import { PaymentSuccessFailureComponent } from "./payment-success-failure.component";
import {
	initCardDetails,
	initOrderDetails,
	initRecurringOrderDetails,
	initSepaDetails,
} from "model/new-sale-order.model";
import { PaymentBffService } from "bff-client";
import { TranslateService } from "@tolgee/ngx";
import { TelemetryService } from "services/telemetry.service";

describe("PaymentSuccessFailureComponent", () => {
	let component: PaymentSuccessFailureComponent;
	let fixture: ComponentFixture<PaymentSuccessFailureComponent>;
	let modalService: CdsModalService;
	let saleInfoService: SaleInfoService;
	let payService: PaymentBffService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PaymentSuccessFailureComponent],
			imports: [
				FormsModule,
				HttpClientModule,
				RouterTestingModule,
				CdsModalModule,
				CdsModalFullscreenModule,
				PipesMockModule,
			],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [
				StepperFullScreenComponent,
				CdsModalService,
				PaymentBffService,
				DatePipe,
				OpenOrderDetailsService,
				SaleInfoService,
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PaymentSuccessFailureComponent);
		component = fixture.componentInstance;
		modalService = TestBed.get(CdsModalService);
		saleInfoService = TestBed.get(SaleInfoService);
		payService = TestBed.get(PaymentBffService);
		jest.spyOn(TitleServiceStub, "setTitle");
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should call submit sepa", () => {
		saleInfoService.paymentType = PAYMENT_TYPE.SEPA;
		jest.spyOn(component, "submitSingleSepaPayment");
		component.ngOnInit();
		expect(component.submitSingleSepaPayment).toHaveBeenCalled();
	});

	it("should call recurring card", () => {
		saleInfoService.paymentType = PAYMENT_TYPE.CARD_RECURRING;
		jest.spyOn(component, "submitRecurringPayment");
		component.ngOnInit();
		expect(component.submitRecurringPayment).toHaveBeenCalled();
	});

	it("should call submit card", () => {
		saleInfoService.paymentType = PAYMENT_TYPE.CARD;
		jest.spyOn(component, "submitSingleCardPayment");
		component.ngOnInit();
		expect(component.submitSingleCardPayment).toHaveBeenCalled();
	});

	it("should submit card", fakeAsync(() => {
		saleInfoService.updateCardPayment({ ...initCardDetails });
		saleInfoService.setSaleInfo({ ...initOrderDetails });
		jest
			.spyOn(payService, "doPrimaryTransaction")
			.mockReturnValue(of(paymentSuccessResponse as any));
		component.submitSingleCardPayment();
		tick();
		expect(payService.doPrimaryTransaction).toHaveBeenCalled();
	}));

	it("should submit card recurring", fakeAsync(() => {
		saleInfoService.updateCardPayment({ ...initCardDetails });
		saleInfoService.setSaleInfo({ ...initOrderDetails });
		// saleInfoService.setRecurringPayment({...initRecurringOrderDetails }, 'PHONE');
		jest
			.spyOn(payService, "schedulePayment")
			.mockReturnValue(of(paymentSuccessResponse as any));
		component.submitRecurringPayment();
		tick();
		expect(payService.schedulePayment).toHaveBeenCalled();
	}));

	it("should submit card recurring fail", fakeAsync(() => {
		saleInfoService.updateCardPayment({ ...initCardDetails });
		saleInfoService.setSaleInfo({ ...initOrderDetails });
		// saleInfoService.setRecurringPayment({...initRecurringOrderDetails}, 'PHONE');
		jest.spyOn(payService, "schedulePayment").mockReturnValue(
			Observable.create(
				catchError(() => {
					return throwError(() => ({ error: { orderId: "123ABC" } }));
				})
			)
		);
		component.submitRecurringPayment();
		tick();
		expect(payService.schedulePayment).toHaveBeenCalled();
	}));

	it("should submit sepa for sale", fakeAsync(() => {
		saleInfoService.pageToInitiate = PAGE_FROM.SALE;
		saleInfoService.setSaleInfo({ ...initOrderDetails });
		saleInfoService.updateSepaPayment({ ...initSepaDetails });
		jest
			.spyOn(payService, "doPrimaryTransaction")
			.mockReturnValue(of(paymentSuccessResponse as any));
		component.submitSingleSepaPayment();
		tick();
		expect(payService.doPrimaryTransaction).toHaveBeenCalled();
	}));

	it("should submit sepa for credit", fakeAsync(() => {
		saleInfoService.pageToInitiate = PAGE_FROM.CREDIT;
		saleInfoService.setSaleInfo({ ...initOrderDetails });
		saleInfoService.updateSepaPayment({ ...initSepaDetails });
		jest
			.spyOn(payService, "doPrimaryTransaction")
			.mockReturnValue(of(paymentSuccessResponse as any));
		component.submitSingleSepaPayment();
		tick();
		expect(payService.doPrimaryTransaction).toHaveBeenCalled();
	}));

	it("should submit sepa for credit fail", fakeAsync(() => {
		saleInfoService.pageToInitiate = PAGE_FROM.CREDIT;
		saleInfoService.setSaleInfo({ ...initOrderDetails });
		saleInfoService.updateSepaPayment({ ...initSepaDetails });
		const err = new Error("apiError");
		jest.spyOn(payService, "doPrimaryTransaction").mockReturnValue(
			Observable.create(
				catchError(() => {
					return throwError(() => ({ error: err }));
				})
			)
		);
		component.submitSingleSepaPayment();
		tick();
		expect(payService.doPrimaryTransaction).toHaveBeenCalled();
	}));

	it("Should close modal", () => {
		jest.spyOn(modalService, "closeModal");
		component.closeModal();
		fixture.detectChanges();
		expect(modalService.closeModal).toHaveBeenCalled();
	});

	it("Should set empty sale info", () => {
		jest.spyOn(saleInfoService, "setSaleInfo");
		component.newTransaction();
		fixture.detectChanges();
		expect(component).toBeTruthy();
	});

	it("Should submit the payment", fakeAsync(() => {
		const order = { ...initOrderDetails };
		saleInfoService.paymentType = "CARD";
		order.paymentMethod = {
			...order.paymentMethod,
			paymentCard: { ...initCardDetails, number: "4035874000424977" },
		};
		jest.spyOn(payService, "doPrimaryTransaction").mockReturnValue(
			new Observable((observer: any) => {
				observer.next(paymentSuccessResponse);
				return observer;
			})
		);
		component.submitSingleCardPayment();
		tick();
		expect(payService.doPrimaryTransaction).toHaveBeenCalled();
	}));

	it("Should submit the payment with error", fakeAsync(() => {
		const err = new Error("apiError");
		jest.spyOn(payService, "doPrimaryTransaction").mockReturnValue(
			Observable.create(
				catchError(() => {
					return throwError(() => ({ error: { orderId: "123ABC" } }));
				})
			)
		);
		component.submitSingleCardPayment();
		tick();
		fixture.detectChanges();
		// expect(payService.postData).toHaveBeenCalled();
		// expect(component.error).toBeTruthy();
	}));
	it("should call newTransaction function", () => {
		component.newTransaction();
		fixture.detectChanges();
		// expect(component).toHaveBeenCalled();
	});

	it("should run viewTransaction method", () => {
		const service = TestBed.inject(OpenOrderDetailsService);
		service.openOrderDetailsModal = jest.fn();
		component.viewTransaction();
		expect(service.openOrderDetailsModal).toHaveBeenCalled();
	});
});
