import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import {
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import {
	AuthenticationService,
	TitleService,
} from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	AuthenticationServiceStub,
	CdsModalServiceStub,
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";
import { SaleInfoService } from "services/sale-info.service";
import { StepperFullScreenComponent } from "shared/template/stepper-full-screen/stepper-full-screen.component";
import { PaymentLinkSuccessComponent } from "./payment-link-success.component";
import { TelemetryService } from "services/telemetry.service";

describe("PaymentSuccessFailureComponent", () => {
	let component: PaymentLinkSuccessComponent;
	let fixture: ComponentFixture<PaymentLinkSuccessComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PaymentLinkSuccessComponent],
			imports: [RouterTestingModule, CdsModalFullscreenModule, PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [
				StepperFullScreenComponent,
				OpenOrderDetailsService,
				SaleInfoService,
				{ provide: CdsModalService, useValue: CdsModalServiceStub },
				{ provide: AuthenticationService, useValue: AuthenticationServiceStub },
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PaymentLinkSuccessComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
