import {
	Component,
	OnDestroy,
	OnInit,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import {
	AuthenticationService,
	TitleService,
} from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { RequestType } from "bff-client";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { PAGE_FROM } from "enum/primary.transaction.enum";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";
import { SaleInfoService } from "services/sale-info.service";
import { StepperFullScreenComponent } from "shared/template/stepper-full-screen/stepper-full-screen.component";

@Component({
	selector: "app-payment-link-success",
	templateUrl: "./payment-link-success.component.html",
	styleUrls: ["./payment-link-success.component.scss"],
})
export class PaymentLinkSuccessComponent implements OnInit, OnDestroy {
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	@ViewChild("modalFooterOptionalPrimaryBtn", { read: TemplateRef })
	modalFooterOptionalPrimaryBtn!: TemplateRef<any>;

	showViewTreansaction = true;
	performAnother = "";

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private modalService: CdsModalService,
		private saleInfoService: SaleInfoService,
		private openOrderDetailsService: OpenOrderDetailsService,
		private authenticationService: AuthenticationService,
		private titleService: TitleService,
		private translateService: TranslateService
	) {}

	ngOnInit(): void {
		this.titleService.setTitle(
			this.translateService.instantSafe("paymentlink.success_message")
		);

		this.showViewTreansaction = this.authenticationService
			.getPermissions()
			.includes(VTPaymentPermissions.EcomVTOrderDetailsView);

		if (this.saleInfoService.pageToInitiate === PAGE_FROM.SALE) {
			this.performAnother = this.translateService.instantSafe(
				"new_sale.perform_another"
			);
		} else if (this.saleInfoService.pageToInitiate === PAGE_FROM.PREAUTH) {
			this.performAnother = this.translateService.instantSafe(
				"pre-auth.perform_another"
			);
		}
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			OptPrimaryBtn: this.modalFooterOptionalPrimaryBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	newTransaction(): void {
		this.stepperComponent.goStep(0);
	}

	closeModal(): void {
		this.modalService.closeModal();
	}

	viewTransaction(): void {
		this.openOrderDetailsService.openOrderDetailsModal(
			this.saleInfoService.paymentLinkResponse?.orderId || ""
		);
	}

	ngOnDestroy(): void {
		this.saleInfoService.resetSaleInfo();
	}
}
