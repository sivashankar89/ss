import {
	AfterViewInit,
	ChangeDetectorRef,
	Component,
	ElementRef,
	EventEmitter,
	OnDestroy,
	OnInit,
	Output,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { SaleInfoService } from "../../../services/sale-info.service";
import { CurrenciesService } from "../../../services/currencies.service";
import { PAGE_FROM } from "../../../enum/primary.transaction.enum";
import { PaymentRequest, Currency } from "bff-client";
import { combineLatest, Subject, takeUntil } from "rxjs";
import { TranslateService } from "@tolgee/ngx";
import { SelectOption } from "shared/models/select-options";
import { PaymentOptionService } from "services/payment-option.service";
import { initAddressValues } from "model/new-sale-order.model";

@Component({
	selector: "app-sale-information",
	templateUrl: "./sale-information.component.html",
	styleUrls: ["./sale-information.component.scss"],
	viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class SaleInformationComponent
	implements OnInit, AfterViewInit, OnDestroy
{
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	@Output() buttonRefs = new EventEmitter();

	isFormSubmitted = false;
	orderTitile = "";

	public stepInValid = false;
	currencyList: Array<SelectOption<Currency>> = [];
	defaultStoreCurrency = {};
	orderDetails!: PaymentRequest;
	billingAvalilableCheck = false;
	@ViewChild("subTotFocus", { read: ElementRef })
	subTotFocus!: ElementRef;
	private unsubsribe = new Subject();
	expandedAddress = {
		billing: false,
		delivery: false,
	};

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private saleInfo: SaleInfoService,
		private currencyService: CurrenciesService,
		private cd: ChangeDetectorRef,
		private translateService: TranslateService,
		private payOptService: PaymentOptionService
	) {}

	toggleOpenAddress(address: "billing" | "delivery"): void {
		this.expandedAddress[address] = !this.expandedAddress[address];
	}

	ngOnInit(): void {
		if (this.saleInfo.pageToInitiate === PAGE_FROM.SALE) {
			this.orderTitile = this.translateService.instantSafe(
				"new_sale.enter_sale_amt"
			);
		} else if (this.saleInfo.pageToInitiate === PAGE_FROM.PREAUTH) {
			this.orderTitile = this.translateService.instantSafe(
				"pre-auth.enter_preauth_amt"
			);
		} else if (this.saleInfo.pageToInitiate === PAGE_FROM.CREDIT) {
			this.orderTitile = this.translateService.instantSafe(
				"credit.enter_credit_amt"
			);
		}
		this.billingAvalilableCheck = this.saleInfo.isBillingAvailable;

		combineLatest([
			this.saleInfo.getOrderDetails$(),
			this.currencyService.getDefaultCurrency(),
		])
			.pipe(takeUntil(this.unsubsribe))
			.subscribe({
				next: ([order, defaultCurrency]) => {
					if (order) {
						this.orderDetails = { ...order };
						if (!this.orderDetails.order) {
							this.orderDetails.order = {};
						}
						if (!order.order?.billing) {
							this.orderDetails.order.billing = {};
							this.orderDetails.order.billing.address = {
								...initAddressValues,
							};
						}
						this.orderDetails.transactionType = this.saleInfo.pageToInitiate;
					}

					if (this.orderDetails && defaultCurrency) {
						if (!this.orderDetails.transactionAmount) {
							// @ts-ignore
							// TODO strong-typing fix
							this.orderDetails.transactionAmount = {};
						}
						// @ts-ignore
						// TODO strong-typing fix
						this.defaultStoreCurrency = defaultCurrency;
					}
				},
				error: (error) => {
					return error;
				},
			});

		this.currencyService
			.getCurrencies()
			.pipe(takeUntil(this.unsubsribe))
			.subscribe({
				next: (currency: any) => {
					if (currency.length > 0) {
						this.currencyList = currency
							.sort((a: any, b: any) => {
								const fa = a.literalCurrencyCode.toLowerCase();
								const fb = b.literalCurrencyCode.toLowerCase();
								if (fa < fb) {
									return -1;
								}
								if (fa > fb) {
									return 1;
								}
								return 0;
							})
							.map((val: any) => {
								return { name: val.literalCurrencyCode, value: val };
							});
					}
				},
				error: (error) => {
					console.log(error);
					return error;
				},
			});

		this.payOptService
			.getPamentOptions() /*.pipe()*/
			.subscribe({
				error: (error) => {
					console.log(error);
				},
			});
	}

	ngOnDestroy(): void {
		this.unsubsribe.next("");
		this.unsubsribe.complete();
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
		this.cd.detectChanges();
	}

	bilingAccept(): void {
		this.billingAvalilableCheck = this.saleInfo.isBillingAvailable;
	}

	save(saleAmountForm: NgForm): void {
		this.isFormSubmitted = true;
		let totAmount = this.orderDetails?.transactionAmount?.total ?? 0;
		totAmount = parseFloat(totAmount.toString());

		if (
			saleAmountForm.valid &&
			!this.saleInfo.isOrderAvailable &&
			totAmount > 0 &&
			!this.saleInfo.orderIdCheckProgress
		) {
			this.saleInfo.setSaleInfo(this.orderDetails);
			this.stepperComponent.goNext();
		}
	}
}
