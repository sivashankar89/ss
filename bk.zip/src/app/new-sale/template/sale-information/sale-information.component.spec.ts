import { HttpClientModule } from "@angular/common/http";
import { ChangeDetectorRef } from "@angular/core";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { RouterTestingModule } from "@angular/router/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
} from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";
import { PAGE_FROM } from "enum/primary.transaction.enum";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { Observable, of } from "rxjs";
import { initOrderDetails } from "../../../model/new-sale-order.model";
import { CurrenciesService } from "../../../services/currencies.service";
import { SaleInfoService } from "../../../services/sale-info.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";

import { SaleInformationComponent } from "./sale-information.component";
import { TelemetryService } from "services/telemetry.service";

describe("SaleInformationComponent", () => {
	let component: SaleInformationComponent;
	let fixture: ComponentFixture<SaleInformationComponent>;
	let saleInfoService: SaleInfoService;
	let currencyService: CurrenciesService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SaleInformationComponent],
			imports: [
				HttpClientModule,
				RouterTestingModule,
				FormsModule,
				CdsModalModule,
				CdsModalFullscreenModule,
				PipesMockModule,
			],
			providers: [
				StepperFullScreenComponent,
				SaleInfoService,
				CurrenciesService,
				ChangeDetectorRef,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SaleInformationComponent);
		saleInfoService = TestBed.get(SaleInfoService);
		currencyService = TestBed.get(CurrenciesService);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should render footer buttons", () => {
		component.ngAfterViewInit();
		expect(fixture).toBeTruthy();
	});

	it("Should get order details", fakeAsync(() => {
		const order = { ...initOrderDetails };
		jest.spyOn(saleInfoService, "getOrderDetails$").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(order);
				return observer;
			})
		);
		jest.spyOn(currencyService, "getCurrencies").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next([
					{
						literalCurrencyCode: "FJD",
						numericCurrencyCode: "242",
						decimalPlaces: 2,
						defaultCurrency: true,
					},
					{
						literalCurrencyCode: "CNY",
						numericCurrencyCode: "156",
						decimalPlaces: 2,
						defaultCurrency: false,
					},
					{
						literalCurrencyCode: "EUR",
						numericCurrencyCode: "978",
						decimalPlaces: 2,
						defaultCurrency: false,
					},
					{
						literalCurrencyCode: "EUR",
						numericCurrencyCode: "978",
						decimalPlaces: 2,
						defaultCurrency: false,
					},
				]);
				return observer;
			})
		);
		component.ngOnInit();
		tick();
		expect(fixture).toBeTruthy();
	}));

	it("Should not update currency list", fakeAsync(() => {
		const order = { ...initOrderDetails };
		jest.spyOn(saleInfoService, "getOrderDetails$").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(order);
				return observer;
			})
		);
		jest.spyOn(currencyService, "getCurrencies").mockReturnValue(of([]));
		component.ngOnInit();
		tick();
		expect(fixture).toBeTruthy();
		expect(component.currencyList.length).toBe(0);
	}));

	it("Should save order details", () => {
		component.orderDetails = { ...initOrderDetails };
		saleInfoService.isOrderAvailable = false;
		if (component.orderDetails.transactionAmount) {
			component.orderDetails.transactionAmount.total = 20;
		}
		jest.spyOn(saleInfoService, "setSaleInfo");
		component.save(new NgForm([], []));
		expect(saleInfoService.setSaleInfo).toHaveBeenCalled();
	});

	it("Should save order details on string total", () => {
		component.orderDetails = { ...initOrderDetails };
		saleInfoService.isOrderAvailable = false;
		if (component.orderDetails.transactionAmount) {
			component.orderDetails.transactionAmount.total = 20;
		}
		jest.spyOn(saleInfoService, "setSaleInfo");
		component.save(new NgForm([], []));
		expect(saleInfoService.setSaleInfo).toHaveBeenCalled();
	});

	it("Should not save order details on total less than 0", () => {
		component.orderDetails = { ...initOrderDetails };
		saleInfoService.isOrderAvailable = false;
		if (component.orderDetails.transactionAmount) {
			component.orderDetails.transactionAmount.total = 0;
		}
		jest.spyOn(saleInfoService, "setSaleInfo");
		component.save(new NgForm([], []));
		expect(saleInfoService.setSaleInfo).not.toHaveBeenCalled();
	});

	// it('should load Sale', fakeAsync(() => {
	//   saleInfoService.pageToInitiate = PAGE_FROM.SALE;
	//   const order = {...initOrderDetails};
	//   jest.spyOn(saleInfoService, 'getOrderDetails$').mockReturnValue(
	//     Observable.create((observer: any) => {
	//       observer.next(order);
	//       return observer;
	//     })
	//   );
	//   component.ngOnInit();
	//   tick();
	//   fixture.detectChanges();
	//   expect(component.orderDetails.transactionType).toBe('SALE');
	// }));

	// it('should load Pre-Auth', fakeAsync(() => {
	//   saleInfoService.pageToInitiate = PAGE_FROM.PREAUTH;
	//   const order = {...initOrderDetails};
	//   jest.spyOn(saleInfoService, 'getOrderDetails$').mockReturnValue(
	//     Observable.create((observer: any) => {
	//       observer.next(order);
	//       return observer;
	//     })
	//   );
	//   component.ngOnInit();
	//   tick();
	//   fixture.detectChanges();
	//   expect(component.orderDetails.transactionType).toBe('PREAUTH');
	// }));

	// it('should load Credit', fakeAsync(() => {
	//   saleInfoService.pageToInitiate = PAGE_FROM.CREDIT;
	//   const order = {...initOrderDetails};
	//   jest.spyOn(saleInfoService, 'getOrderDetails$').mockReturnValue(
	//     Observable.create((observer: any) => {
	//       observer.next(order);
	//       return observer;
	//     })
	//   );
	//   component.ngOnInit();
	//   tick();
	//   fixture.detectChanges();
	//   expect(component.orderDetails.transactionType).toBe('CREDIT');
	// }));
});
