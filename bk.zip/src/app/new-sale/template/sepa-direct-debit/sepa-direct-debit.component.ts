import {
	Component,
	OnInit,
	AfterViewInit,
	TemplateRef,
	ViewChild,
	Output,
	EventEmitter,
} from "@angular/core";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { SaleInfoService } from "../../../services/sale-info.service";
import { FormGroup, NgForm } from "@angular/forms";
import { PAYMENT_TYPE } from "../../../enum/primary.transaction.enum";
import { TranslateService } from "@tolgee/ngx";
import { MerchantDataResponse, PaymentRequest, PaymentSEPA } from "bff-client";
import { initSepaDetails, SeListCountries } from "model/new-sale-order.model";
import { MerchantDatasService } from "services/merchant-datas.service";
import { Subject, takeUntil } from "rxjs";

export interface MandateTypeInfo {
	name: string;
	value: string;
}
@Component({
	selector: "app-sepa-direct-debit",
	templateUrl: "./sepa-direct-debit.component.html",
	styleUrls: ["./sepa-direct-debit.component.scss"],
})
export class SepaDirectDebitComponent implements OnInit, AfterViewInit {
	accounHolder: any;
	order!: PaymentRequest;
	sepa: PaymentSEPA = JSON.parse(JSON.stringify(initSepaDetails));
	isSubmitted: any = false;
	mandateDate: any = "";
	@Output() changeEvent = new EventEmitter();
	mandateTypes!: MandateTypeInfo[];
	transType = "";
	todayDate = new Date();
	isSeListedCountry = false;
	private unsubsribe = new Subject();
	merchantDataRes!: MerchantDataResponse;

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private saleinfoService: SaleInfoService,
		private translateService: TranslateService,
		private merchantDataService: MerchantDatasService
	) {
		this.transType = this.saleinfoService.pageToInitiate;
	}
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;

	ngOnInit(): void {
		this.mandateTypes = [
			{
				name: this.translateService.instantSafe("shared.single"),
				value: "SINGLE",
			},
			{
				name: this.translateService.instantSafe("shared.recurring"),
				value: "RECURRING_COLLECTION",
			},
		];
		this.saleinfoService.getOrderDetails$().subscribe({
			next: (order: PaymentRequest) => {
				this.order = { ...order };
				if (this.order?.paymentMethod?.sepa) {
					this.sepa = this.order.paymentMethod.sepa;
				}
			},
			error: (error) => {
				return error;
			},
		});
		this.todayDate.setDate(this.todayDate.getDate());
		this.merchantDataService
			.getMerchantData()
			.pipe(takeUntil(this.unsubsribe))
			.subscribe({
				next: (merchantData: MerchantDataResponse) => {
					this.merchantDataRes = merchantData;
					if (this.merchantDataRes.merchantAddressDetails?.address1) {
						this.merchantDataRes.merchantAddressDetails.address1 =
							", " + this.merchantDataRes.merchantAddressDetails.address1;
					}
					if (this.merchantDataRes.merchantAddressDetails?.address2) {
						this.merchantDataRes.merchantAddressDetails.address2 =
							", " + this.merchantDataRes.merchantAddressDetails.address2;
					}
					if (this.merchantDataRes.merchantAddressDetails?.zip) {
						this.merchantDataRes.merchantAddressDetails.zip =
							", " + this.merchantDataRes.merchantAddressDetails.zip;
					}
					if (
						!this.merchantDataRes.merchantAddressDetails?.zip &&
						this.merchantDataRes.merchantAddressDetails?.city
					) {
						this.merchantDataRes.merchantAddressDetails.city =
							", " + this.merchantDataRes.merchantAddressDetails.city;
					}
				},
				error: (error) => {
					return error;
				},
			});
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	goBack(): void {
		this.stepperComponent.goBack();
	}

	Pay(sepaCardForm: NgForm | FormGroup): void {
		this.isSubmitted = true;
		if (sepaCardForm.valid) {
			this.saleinfoService.paymentType = PAYMENT_TYPE.SEPA;
			this.saleinfoService.updateSepaPayment(this.sepa);
			this.stepperComponent.goNext();
		} else {
			const ibanControl = sepaCardForm.controls.ibanNumber;
			if (ibanControl.value === "" || ibanControl.value === undefined) {
				ibanControl.setValue("@");
			}
		}
	}

	validateCards(event: any): void {
		this.changeEvent.emit();
	}

	checkSeCountry(sepaCardForm: NgForm | FormGroup) {
		this.isSeListedCountry = false;
		const ibanControl = sepaCardForm.controls.ibanNumber;
		let twoDigitCountry = "";
		if (
			ibanControl.valid &&
			ibanControl.value !== undefined &&
			ibanControl.value !== ""
		) {
			twoDigitCountry = ibanControl.value.substring(0, 2);
			if (twoDigitCountry !== "" && SeListCountries.includes(twoDigitCountry)) {
				this.isSeListedCountry = true;
			}
		}
	}

	ibanFormat(val: any): void {
		if (val !== "") {
			return val
				.replace(/[^\dA-Z]/g, "")
				.replace(/(.{4})/g, "$1 ")
				.trim();
		}
	}
}
