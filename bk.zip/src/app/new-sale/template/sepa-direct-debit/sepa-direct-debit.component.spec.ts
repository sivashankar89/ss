import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import {
	FormsModule,
	NgForm,
	FormGroup,
	FormControl,
	Validators,
} from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { SepaDirectDebitComponent } from "./sepa-direct-debit.component";
import { CdsDatepickerModule } from "@international-payment-platform/design-system-angular";
import { SaleInfoService } from "../../../services/sale-info.service";
import { Observable } from "rxjs";
import { RouterTestingModule } from "@angular/router/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { initOrderDetails, initSepaDetails } from "model/new-sale-order.model";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

describe("SepaDirectDebitComponent", () => {
	let component: SepaDirectDebitComponent;
	let fixture: ComponentFixture<SepaDirectDebitComponent>;
	let saleinfoService: SaleInfoService;
	let stepper: StepperFullScreenComponent;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SepaDirectDebitComponent],
			imports: [
				FormsModule,
				HttpClientModule,
				CdsDatepickerModule,
				RouterTestingModule,
				PipesMockModule,
			],
			providers: [
				StepperFullScreenComponent,
				SaleInfoService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SepaDirectDebitComponent);
		component = fixture.componentInstance;
		saleinfoService = TestBed.get(SaleInfoService);
		stepper = TestBed.get(StepperFullScreenComponent);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("get sepa from paymentmethod", fakeAsync(() => {
		const order = {
			...initOrderDetails,
			paymentMethod: {
				sepa: { ...initSepaDetails },
			},
		};
		jest.spyOn(saleinfoService, "getOrderDetails$").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(order);
				return observer;
			})
		);
		component.ngOnInit();
		tick();
		expect(component.order).toBeTruthy();
	}));

	it("should call for validateCards method", () => {
		const validate = event;
		component.validateCards(validate);
		fixture.detectChanges();
		expect(component.validateCards).toBeTruthy();
	});

	it("it should call ibanFormat method", () => {
		component.ibanFormat("12345");
		fixture.detectChanges();
		expect(component).toBeTruthy();
	});

	it("should update sepa payment", fakeAsync(() => {
		const sepaPay = component.sepa;
		jest.spyOn(saleinfoService, "updateSepaPayment").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(sepaPay);
				return observer;
			})
		);
		component.Pay(new NgForm([], []));
		tick();
		expect(component).toBeTruthy();
	}));

	it("Should call goBack method", () => {
		jest.spyOn(stepper, "goBack");
		component.goBack();
		fixture.detectChanges();
		expect(stepper.goBack).toHaveBeenCalled();
	});

	it("should call goNext method", () => {
		jest.spyOn(stepper, "goNext");
		stepper.goNext();
		fixture.detectChanges();
		expect(stepper.goNext).toHaveBeenCalled();
	});

	it("Should not pay Card on form fail", () => {
		const form = new FormGroup({
			ibanNumber: new FormControl("", Validators.required),
		});
		form.get("ibanNumber")?.markAsTouched();
		jest.spyOn(saleinfoService, "updateCardPayment");
		component.order = { ...initOrderDetails };
		component.Pay(form);
		expect(saleinfoService.updateCardPayment).not.toHaveBeenCalled();
	});
});
