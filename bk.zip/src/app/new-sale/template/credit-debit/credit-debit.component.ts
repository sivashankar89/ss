import {
	Component,
	AfterViewInit,
	TemplateRef,
	ViewChild,
	OnInit,
} from "@angular/core";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { FormGroup, NgForm } from "@angular/forms";
import { SaleInfoService } from "../../../services/sale-info.service";
import {
	PAGE_FROM,
	PAYMENT_TYPE,
} from "../../../enum/primary.transaction.enum";
import { TranslateService } from "@tolgee/ngx";
import { PaymentCard, CardRequest, Mcc6012 } from "bff-client";
import { initCardDetails, initMcc6012 } from "model/new-sale-order.model";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { PermissionGuardService } from "services/permission-guard.service";
import { CardService } from "../../../services/card.service";
@Component({
	selector: "app-credit-debit",
	templateUrl: "./credit-debit.component.html",
})
export class CreditDebitComponent implements OnInit, AfterViewInit {
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	@ViewChild("cardDetailForm", { static: true }) cardDetailForm!: NgForm;
	isFormSubmitted = false;
	CardSucced = false;
	tabToLoad = "";
	buttonPay = this.translateService.instantSafe("shared.pay");
	validationInProgress = false;
	canRecurring = false;
	paymentPermissions = VTPaymentPermissions;
	mccSupportedBrandAndMerchant = false;
	cardFunctionType = "UNDEFINED";

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private saleinfoService: SaleInfoService,
		private translateService: TranslateService,
		private permissionGuardService: PermissionGuardService,
		private cardService: CardService
	) {
		this.initiateTabToLoad();
	}

	ngOnInit(): void {
		this.canRecurring = this.permissionGuardService.hasPermission(
			VTPaymentPermissions.EcomVTTransactionSale
		);
	}

	initiateTabToLoad(): void {
		this.tabToLoad = this.saleinfoService.pageToInitiate;
		if (this.tabToLoad === PAGE_FROM.PREAUTH) {
			this.buttonPay = this.translateService.instantSafe("shared.authorise");
		}
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	goBack(): void {
		this.stepperComponent.goBack();
	}

	Pay(cardDetailForm: NgForm | FormGroup): void {
		this.isFormSubmitted = true;
		if (cardDetailForm.valid && this.CardSucced) {
			this.saleinfoService.updateCardPayment(
				this.getCardFromForm(),
				this.cardDetailForm.value.obtainCard
			);
			if (!cardDetailForm.value.isRecurring) {
				this.saleinfoService.paymentType = PAYMENT_TYPE.CARD;
			} else {
				this.saleinfoService.paymentType = PAYMENT_TYPE.CARD_RECURRING;
				this.saleinfoService.setRecurringPayment(
					cardDetailForm.value,
					this.cardDetailForm.value.obtainCard
				);
			}
			if (this.mccSupportedBrandAndMerchant) {
				this.saleinfoService.updateMccIndustryExtension(
					this.getMccFromForm(),
					cardDetailForm.value.isRecurring
				);
			}
			if (cardDetailForm.value.saveCard_withToken) {
				this.saleinfoService.isTokenGenerateClicked = true;
				if (this.saleinfoService.paymentType === PAYMENT_TYPE.CARD_RECURRING) {
					this.saleinfoService.tokenToGenerate = true;
				} else {
					this.saleinfoService.createToken();
				}
			}
			this.stepperComponent.goNext();
		} else {
			const cardNumberControl = cardDetailForm.controls.cardNumber;
			const expiryDateControl = cardDetailForm.controls.expiryDate;
			const cardCvvControl = cardDetailForm.controls.cardCvv;
			if (
				cardNumberControl.value === "" ||
				cardNumberControl.value === undefined
			) {
				cardNumberControl.setValue("@");
			}
			if (
				expiryDateControl.value === "" ||
				expiryDateControl.value === undefined
			) {
				expiryDateControl.setValue("@");
			}
			if (cardCvvControl.value === "" || cardCvvControl.value === undefined) {
				cardCvvControl.setValue("@");
			}
		}
	}

	getMccFromForm(): Mcc6012 {
		const mccDetail = this.cardDetailForm.value;
		const mcc: Mcc6012 = JSON.parse(JSON.stringify(initMcc6012));
		if (this.saleinfoService.mccActivatedTab === "accNumber") {
			mcc.accountNum = mccDetail.account_number;
			delete mcc.accountFirst6;
			delete mcc.accountLast4;
		} else if (this.saleinfoService.mccActivatedTab === "pan") {
			mcc.accountFirst6 = mccDetail.pan_six_digits;
			mcc.accountLast4 = mccDetail.pan_four_digits;
			delete mcc.accountNum;
		}
		const tempDob = mccDetail.dob.split("/");
		mcc.dateOfBirth = tempDob[2] + tempDob[1] + tempDob[0];
		mcc.postCode = mccDetail.postal;
		mcc.surname = mccDetail.surname;
		return mcc;
	}

	getCardFromForm(): PaymentCard {
		const cardDetail = this.cardDetailForm.value;
		const card: PaymentCard = JSON.parse(JSON.stringify(initCardDetails));
		card.securityCode = cardDetail.cardCvv;
		card.number = cardDetail.cardNumber?.replace(/\D/g, "");
		card.cardholderName = cardDetail.customerName;

		if (this.cardFunctionType !== "UNDEFINED") {
			card.cardFunction = this.cardFunctionType;
		}

		if (cardDetail.expiryDate) {
			card.expiryDate = {
				month: cardDetail.expiryDate.substr(0, 2),
				year: cardDetail.expiryDate.substr(2, 2),
			};
		}
		return card;
	}

	validateAPICards(form: NgForm | FormGroup): void {
		this.validationInProgress = true;
		if (
			(form.valid && form.value.cardNumber !== undefined) ||
			(form?.controls?.cardNumber?.status === "VALID" &&
				form?.controls?.expiryDate?.status === "VALID" &&
				form?.controls?.cardCvv?.status === "VALID")
		) {
			this.saleinfoService.tabPayType = true;
			const body: CardRequest = {
				paymentCard: {
					number: form.value.cardNumber,
				},
			};
			this.saleinfoService.cardResponse = [];
			this.saleinfoService.cardNumber = form.value.cardNumber;
			this.cardService.postData(body).subscribe({
				next: (res) => {
					if (res?.cardDetails) {
						this.saleinfoService.cardResponse =
							res["cardDetails"][res["cardDetails"].length - 1];
						this.cardFunctionType =
							res?.cardDetails[res["cardDetails"].length - 1]?.cardFunction;
					} else {
						this.saleinfoService.cardResponse = [];
						this.cardFunctionType = "UNDEFINED";
					}
				},
				error: (error) => {
					return error;
				},
			});
			this.CardSucced = true;
			this.validationInProgress = false;
			if (
				this.saleinfoService.mccSupportedMerchant &&
				this.saleinfoService.pageToInitiate !== PAGE_FROM.CREDIT &&
				(this.saleinfoService.payCardBrand === "visa" ||
					this.saleinfoService.payCardBrand === "mastercard" ||
					this.saleinfoService.payCardBrand === "maestro")
			) {
				this.mccSupportedBrandAndMerchant = true;
			} else {
				this.mccSupportedBrandAndMerchant = false;
			}
		} else {
			this.CardSucced = false;
			this.validationInProgress = false;
		}
	}
}
