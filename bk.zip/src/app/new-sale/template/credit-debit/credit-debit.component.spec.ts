import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import {
	FormControl,
	FormGroup,
	FormsModule,
	NgForm,
	Validators,
} from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { catchError, Observable, throwError } from "rxjs";
import {
	cardVerfifcationSuccessReponse,
	cardVerificationFailureResponse,
} from "mocks/new-sale-order.mock";
import { PAGE_FROM, PAYMENT_TYPE } from "enum/primary.transaction.enum";
import { RouterTestingModule } from "@angular/router/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { CreditDebitComponent } from "./credit-debit.component";
import { CardService } from "services/card.service";
import { SaleInfoService } from "services/sale-info.service";
import { PaymentRecurringComponent } from "new-sale/components/organism/payment-recurring/payment-recurring.component";
import { StepperFullScreenComponent } from "shared/template/stepper-full-screen/stepper-full-screen.component";
import { CdsDatepickerModule } from "@international-payment-platform/design-system-angular";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TranslateService } from "@tolgee/ngx";
import { TelemetryService } from "services/telemetry.service";

describe("CreditDebitComponent", () => {
	let component: CreditDebitComponent;
	let fixture: ComponentFixture<CreditDebitComponent>;
	let cardservice: CardService;
	let saleInfoService: SaleInfoService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [CreditDebitComponent, PaymentRecurringComponent],
			imports: [
				FormsModule,
				HttpClientModule,
				RouterTestingModule,
				PipesMockModule,
				CdsDatepickerModule,
			],
			providers: [
				StepperFullScreenComponent,
				SaleInfoService,
				CardService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{ provide: NgForm, useValue: new NgForm([], []) },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CreditDebitComponent);
		component = fixture.componentInstance;
		cardservice = TestBed.get(CardService);
		saleInfoService = TestBed.get(SaleInfoService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should chane button authorise for pre auth", () => {
		saleInfoService.pageToInitiate = PAGE_FROM.PREAUTH;
		component.initiateTabToLoad();
		expect(component.buttonPay).toBe("shared.authorise");
	});

	it("should render footer buttons", () => {
		component.ngAfterViewInit();
		expect(fixture).toBeTruthy();
	});

	it("should go back", () => {
		component.goBack();
		expect(fixture).toBeTruthy();
	});

	it("should validate card", fakeAsync(() => {
		component.cardDetailForm = new NgForm([], []);
		jest.spyOn(cardservice, "postData").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(cardVerfifcationSuccessReponse);
				return observer;
			})
		);
		component.cardDetailForm.value.expiryDate = "12/22";
		component.cardDetailForm.value.cardNumber = "123456781111";
		component.validateAPICards(component.cardDetailForm);
		tick();
		expect(cardservice.postData).toHaveBeenCalled();
	}));

	it("should not validate card if form is not valid", fakeAsync(() => {
		component.cardDetailForm = new NgForm([], []);
		jest.spyOn(cardservice, "postData").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(cardVerfifcationSuccessReponse);
				return observer;
			})
		);
		component.cardDetailForm.value.expiryDate = "12/22";
		component.cardDetailForm.value.cardNumber = undefined;
		fixture.detectChanges();
		fixture.whenStable().then(() => {
			component.validateAPICards(component.cardDetailForm);
			tick();
			expect(cardservice.postData).not.toHaveBeenCalled();
		});
	}));

	it("should not validate card if form is not valid", fakeAsync(() => {
		const form = new FormGroup({
			cardNumber: new FormControl("", Validators.required),
			expiryDate: new FormControl("", Validators.required),
			customerName: new FormControl("", Validators.required),
			cardCvv: new FormControl("", Validators.required),
		});
		form.get("cardNumber")?.setValue("123ABC");
		jest.spyOn(cardservice, "postData").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(cardVerfifcationSuccessReponse);
				return observer;
			})
		);
		fixture.detectChanges();
		component.validateAPICards(form);
		tick();
		expect(cardservice.postData).not.toHaveBeenCalled();
	}));

	it("should validate card even form is not valid if has card details ", fakeAsync(() => {
		const form = new FormGroup({
			cardNumber: new FormControl(""),
			expiryDate: new FormControl(""),
			customerName: new FormControl(""),
			cardCvv: new FormControl(""),
			obtainCard: new FormControl("", Validators.required),
		});
		form.get("obtainCard")?.markAsTouched();
		jest.spyOn(cardservice, "postData").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(cardVerfifcationSuccessReponse);
				return observer;
			})
		);
		fixture.detectChanges();
		component.validateAPICards(form);
		tick();
		expect(cardservice.postData).toHaveBeenCalled();
	}));

	it("should render on validate card fail", fakeAsync(() => {
		component.cardDetailForm = new NgForm([], []);
		jest.spyOn(cardservice, "postData").mockReturnValue(
			Observable.create(
				catchError((err) => {
					return throwError(cardVerificationFailureResponse);
				})
			)
		);
		component.cardDetailForm.value.cardNumber = "123456781111";
		fixture.detectChanges();
		component.validateAPICards(component.cardDetailForm);
		tick();
		expect(cardservice.postData).toHaveBeenCalled();
	}));

	it("Should pay", () => {
		component.cardDetailForm = new NgForm([], []);
		component.CardSucced = true;
		component.Pay(component.cardDetailForm);
		expect(saleInfoService.paymentType).toEqual(PAYMENT_TYPE.CARD);
	});

	it("Should pay fail", () => {
		const form = new FormGroup({
			cardNumber: new FormControl("test", Validators.required),
			expiryDate: new FormControl("test", Validators.required),
			cardCvv: new FormControl("test", Validators.required),
			cardholderName: new FormControl("", Validators.required),
		});
		component.Pay(form);
		expect(saleInfoService.paymentType).toEqual("");
	});

	it("Should pay Recurring", () => {
		component.cardDetailForm = new NgForm([], []);
		component.cardDetailForm.value.isRecurring = true;
		component.CardSucced = true;
		component.Pay(component.cardDetailForm);
		expect(saleInfoService.paymentType).toEqual(PAYMENT_TYPE.CARD_RECURRING);
	});

	it("Should not pay Card on form fail", () => {
		const form = new FormGroup({
			cardNumber: new FormControl("", Validators.required),
			expiryDate: new FormControl("", Validators.required),
			cardCvv: new FormControl("", Validators.required),
		});
		form.get("cardNumber")?.markAsTouched();
		form.get("expiryDate")?.markAsTouched();
		form.get("cardCvv")?.markAsTouched();
		jest.spyOn(saleInfoService, "updateCardPayment");
		component.cardDetailForm.value.isRecurring = true;
		component.Pay(form);
		expect(saleInfoService.updateCardPayment).not.toHaveBeenCalled();
	});
});
