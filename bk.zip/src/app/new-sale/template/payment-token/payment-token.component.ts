import {
	AfterViewInit,
	Component,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { NgForm } from "@angular/forms";
import { TranslateService } from "@tolgee/ngx";
import {
	PAGE_FROM,
	PAYMENT_TYPE,
} from "../../../enum/primary.transaction.enum";
import { SaleInfoService } from "../../../services/sale-info.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";

@Component({
	selector: "app-paymnt-token",
	templateUrl: "./payment-token.component.html",
})
export class PaymentTokenComponent implements AfterViewInit {
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	token = "";
	obtainCard: any = "";
	buttonPay = this.translateService.instantSafe("shared.pay");
	obtainCardType = [
		{
			name: this.translateService.instantSafe("shared.telephone_order"),
			value: "PHONE",
		},
		{
			name: this.translateService.instantSafe("shared.mail_order"),
			value: "MAIL",
		},
	];
	isSubmitted = false;

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private saleInfoService: SaleInfoService,
		private translateService: TranslateService
	) {
		if (this.saleInfoService.pageToInitiate === PAGE_FROM.PREAUTH) {
			this.buttonPay = this.translateService.instantSafe("shared.authorise");
		}
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	goBack(): void {
		this.stepperComponent.goBack();
	}

	Pay(payTokenForm: NgForm): void {
		this.isSubmitted = true;
		if (payTokenForm.valid) {
			this.saleInfoService.paymentType = PAYMENT_TYPE.TOKEN;
			this.saleInfoService.updateTokenPayment(
				this.token,
				payTokenForm.value.obtainCard
			);
			this.stepperComponent.goNext();
		}
	}
}
