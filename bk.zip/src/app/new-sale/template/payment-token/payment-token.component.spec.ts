import { OverlayModule } from "@angular/cdk/overlay";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { FormControl, FormsModule, NgForm } from "@angular/forms";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { SaleInfoService } from "services/sale-info.service";
import { StepperFullScreenComponent } from "shared/template/stepper-full-screen/stepper-full-screen.component";

import { PaymentTokenComponent } from "./payment-token.component";
import { TelemetryService } from "services/telemetry.service";

describe("PaymentTokenComponent", () => {
	let component: PaymentTokenComponent;
	let fixture: ComponentFixture<PaymentTokenComponent>;
	let saleInfoService: SaleInfoService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PaymentTokenComponent],
			imports: [FormsModule, OverlayModule, PipesMockModule],
			providers: [
				StepperFullScreenComponent,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PaymentTokenComponent);
		component = fixture.componentInstance;
		saleInfoService = TestBed.inject(SaleInfoService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should navigate back", () => {
		component.goBack();
		fixture.detectChanges();
	});

	it("check pay function", fakeAsync(() => {
		component.token = "testToken";
		const testForm = {
			valid: true,
			value: {
				obtainCard: true,
				token: "testToken",
			},
		} as NgForm;
		jest.spyOn(saleInfoService, "updateTokenPayment");
		tick();
		component.Pay(testForm);
		fixture.detectChanges();
		expect(saleInfoService.updateTokenPayment).toHaveBeenCalled();
	}));
});
