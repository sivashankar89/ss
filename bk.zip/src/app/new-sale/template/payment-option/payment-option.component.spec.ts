import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
} from "@international-payment-platform/design-system-angular";
import { AuthenticationService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { StoreBffService } from "bff-client";
import { PAGE_FROM } from "enum/primary.transaction.enum";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	AuthenticationServiceStub,
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { initOrderDetails } from "model/new-sale-order.model";
import { Observable, of } from "rxjs";
import { PaymentOptionService } from "services/payment-option.service";
import { SaleInfoService } from "../../../services/sale-info.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";

import { PaymentOptionComponent } from "./payment-option.component";
import { TelemetryService } from "services/telemetry.service";

describe("PaymentOptionComponent", () => {
	let component: PaymentOptionComponent;
	let fixture: ComponentFixture<PaymentOptionComponent>;
	let saleInfoService: SaleInfoService;
	let storeBff: StoreBffService;
	let payOptService: PaymentOptionService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PaymentOptionComponent],
			providers: [
				StepperFullScreenComponent,
				SaleInfoService,
				StoreBffService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: AuthenticationService, useValue: AuthenticationServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
			imports: [
				CdsModalModule,
				CdsModalFullscreenModule,
				RouterTestingModule,
				HttpClientTestingModule,
				PipesMockModule,
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PaymentOptionComponent);
		component = fixture.componentInstance;
		saleInfoService = TestBed.inject(SaleInfoService);
		storeBff = TestBed.inject(StoreBffService);
		payOptService = TestBed.inject(PaymentOptionService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("Should get order details", fakeAsync(() => {
		const order = { ...initOrderDetails };
		saleInfoService.retainedTab = "credit-debit";
		jest.spyOn(saleInfoService, "getOrderDetails$").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(order);
				return observer;
			})
		);
		jest.spyOn(component, "selection");
		component.paymentMethodsAssign();
		tick();
		fixture.detectChanges();
		expect(component.orderSummary).toBeTruthy();
	}));

	it("payment methods all present with payment token", fakeAsync(() => {
		saleInfoService.pageToInitiate = PAGE_FROM.SALE;
		jest.spyOn(payOptService, "getPamentOptions").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(["creditCard", "germanDirectDebit", "paymentUrl"]);
				return observer;
			})
		);
		component.canUseToken = true;
		component.paymentMethodsAssign();
		fixture.detectChanges();
		expect(component).toBeTruthy();
	}));

	it("payment methods all present without payment token", fakeAsync(() => {
		saleInfoService.pageToInitiate = PAGE_FROM.SALE;
		jest.spyOn(payOptService, "getPamentOptions").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(["creditCard", "germanDirectDebit", "paymentUrl"]);
				return observer;
			})
		);
		component.paymentMethodsAssign();
		tick();
		fixture.detectChanges();
		expect(component).toBeTruthy();
	}));

	it("payment methods all present with payment token on preAuth", fakeAsync(() => {
		saleInfoService.pageToInitiate = PAGE_FROM.PREAUTH;
		jest.spyOn(payOptService, "getPamentOptions").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(["creditCard", "germanDirectDebit", "paymentUrl"]);
				return observer;
			})
		);
		component.canUseToken = true;
		component.paymentMethodsAssign();
		tick();
		fixture.detectChanges();
		expect(component).toBeTruthy();
	}));

	it("Should change the retained tab", () => {
		component.orderSummary = {};
		component.selection("credit-debit");
		expect(saleInfoService.retainedTab).toBe("credit-debit");
	});

	it("Should select segment", () => {
		component.selectedSegment("credit-debit");
		expect(component.viewMode).toBe("credit-debit");
	});
});
