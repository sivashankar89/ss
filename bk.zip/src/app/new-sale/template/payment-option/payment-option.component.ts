import { Component, OnDestroy, OnInit } from "@angular/core";
import { SaleInfoService } from "services/sale-info.service";
import { PAGE_FROM } from "enum/primary.transaction.enum";
import { TranslateService } from "@tolgee/ngx";
import { PaymentRequest } from "bff-client";
import { ReplaySubject, Subject, takeUntil } from "rxjs";
import { AuthenticationService } from "@international-payment-platform/portal-core";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { PaymentOptionService } from "services/payment-option.service";
import { ApiErrorResponse } from "model/error.model";
import { MerchantDatasService } from "services/merchant-datas.service";
@Component({
	selector: "app-payment-option",
	templateUrl: "./payment-option.component.html",
	styleUrls: ["./payment-option.component.scss"],
})
export class PaymentOptionComponent implements OnInit, OnDestroy {
	private readonly destroyed$ = new ReplaySubject<void>(1);
	viewMode = "";
	paymentOptions: Array<any> = [];
	orderSummary!: PaymentRequest;
	public stepInValid = false;
	public loading = true;
	canAccessPaymentLink = false;
	canAccessOtherPayments = false;
	canUseToken = false;
	private unsubsribe = new Subject();
	public error!: ApiErrorResponse | undefined;

	constructor(
		private saleInfoService: SaleInfoService,
		private translateService: TranslateService,
		private authenticationService: AuthenticationService,
		private payOptService: PaymentOptionService,
		private merchantDataService: MerchantDatasService
	) {}

	ngOnInit(): void {
		const userPermissions: string[] =
			this.authenticationService.getPermissions();
		const pageFrom = this.saleInfoService.pageToInitiate;

		this.canAccessPaymentLink = userPermissions.includes(
			VTPaymentPermissions.EcomVTPaymentLink
		);

		if (pageFrom === PAGE_FROM.SALE) {
			this.canAccessOtherPayments = [
				VTPaymentPermissions.EcomVTTransactionSale,
				VTPaymentPermissions.EcomVTTransactionSaleNorecurring,
			].some((permission) => userPermissions.includes(permission));
		}

		if (pageFrom === PAGE_FROM.PREAUTH) {
			this.canAccessOtherPayments = userPermissions.includes(
				VTPaymentPermissions.EcomVTTransactionPreAuth
			);
		}

		if (pageFrom === PAGE_FROM.CREDIT) {
			this.canAccessOtherPayments = userPermissions.includes(
				VTPaymentPermissions.EcomVTTransactionCredit
			);
			this.canAccessPaymentLink = false;
		}

		this.canUseToken = userPermissions.includes(
			VTPaymentPermissions.EcomVTTransactionUseToken
		);

		if (this.canAccessOtherPayments) {
			this.paymentMethodsAssign();
		} else if (this.canAccessPaymentLink) {
			this.loading = false;
			this.paymentOptions.push({
				name: this.translateService.instantSafe("shared.payment_link"),
				value: "paymentLink",
			});
			this.viewMode = this.viewMode !== "" ? this.viewMode : "paymentLink";
		}

		this.saleInfoService
			.getOrderDetails$()
			.pipe(takeUntil(this.destroyed$))
			.subscribe({
				next: (order) => {
					if (order) {
						this.orderSummary = { ...order };
						if (this.saleInfoService.retainedTab) {
							this.viewMode = this.saleInfoService.retainedTab;
							this.selection(this.viewMode);
						}
					}
				},
				error: (error) => {
					return error;
				},
			});
	}

	paymentMethodsAssign(): void {
		this.payOptService
			.getPamentOptions()
			.pipe(takeUntil(this.unsubsribe))
			.subscribe({
				next: (paymentMethods: any) => {
					this.loading = false;
					this.viewMode = "";
					const pageFrom = this.saleInfoService.pageToInitiate;
					this.paymentOptions = [];
					if (this.canAccessOtherPayments) {
						if (paymentMethods.includes("mcc6012")) {
							this.saleInfoService.mccSupportedMerchant = true;
						}
						if (paymentMethods.includes("creditCard")) {
							this.paymentOptions.push({
								name: this.translateService.instantSafe(
									"shared.credit_debit_card"
								),
								value: "credit-debit",
							});
							this.viewMode =
								this.viewMode !== "" ? this.viewMode : "credit-debit";
						}
						if (
							paymentMethods.includes("germanDirectDebit") &&
							[PAGE_FROM.SALE, PAGE_FROM.CREDIT].includes(pageFrom)
						) {
							const langKeyword =
								pageFrom === PAGE_FROM.CREDIT
									? "shared.sepa_credit"
									: "shared.sepa_direct_debit";
							this.paymentOptions.push({
								name: this.translateService.instantSafe(langKeyword),
								value: "sepa",
							});
							this.viewMode = this.viewMode !== "" ? this.viewMode : "sepa";
							this.merchantDataService.getMerchantData().pipe().subscribe();
						}
					}

					if (this.canAccessPaymentLink) {
						this.paymentOptions.push({
							name: this.translateService.instantSafe("shared.payment_link"),
							value: "paymentLink",
						});
						this.viewMode =
							this.viewMode !== "" ? this.viewMode : "paymentLink";
					}

					if (this.canUseToken && this.canAccessOtherPayments) {
						this.paymentOptions.push({
							name: this.translateService.instantSafe("shared.token"),
							value: "paymentToken",
						});
						this.viewMode =
							this.viewMode !== "" ? this.viewMode : "paymentToken";
					}
				},
				error: (error) => {
					this.loading = false;
					this.error = error.error;
					return error;
				},
			});
	}

	ngOnDestroy(): void {
		this.destroyed$.next();
		this.destroyed$.complete();
	}

	selection(event: any): void {
		this.saleInfoService.retainedTab = event;
	}

	selectedSegment(event: any): void {
		this.viewMode = event;
	}
}
