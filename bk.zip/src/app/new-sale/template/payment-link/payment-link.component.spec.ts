import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { FormsModule } from "@angular/forms";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";
import { PaymentUrlService } from "../../../services/payment-url.service";
import { SaleInfoService } from "../../../services/sale-info.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { PaymentLinkComponent } from "./payment-link.component";
import { TitleService } from "@international-payment-platform/portal-core";
import { RouterTestingModule } from "@angular/router/testing";
import { NGXLoggerMock } from "ngx-logger/testing/ngx-logger-testing";
import { NgxLoggerLevel, NGXLogger, TOKEN_LOGGER_CONFIG } from "ngx-logger";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { CdsDatepickerModule } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";
import { PaymentLinkResponse } from "bff-client";
import { TelemetryService } from "services/telemetry.service";

describe("PaymentLinkComponent", () => {
	let component: PaymentLinkComponent;
	let fixture: ComponentFixture<PaymentLinkComponent>;
	let payService: PaymentUrlService;
	let saleInfoService: SaleInfoService;
	let modalService: CdsModalService;

	const paymentLinkRes: PaymentLinkResponse = {
		paymentLinkURL: "testPaymentLinkUrl",
		paymentLinkId: "12345",
	};

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PaymentLinkComponent],
			imports: [
				FormsModule,
				HttpClientModule,
				CdsModalModule,
				CdsModalFullscreenModule,
				CdsDatepickerModule,
				RouterTestingModule,
				PipesMockModule,
			],
			providers: [
				StepperFullScreenComponent,
				CdsModalService,
				PaymentUrlService,
				SaleInfoService,
				OpenOrderDetailsService,
				{ provide: NGXLogger, useClass: NGXLoggerMock },
				{
					provide: TOKEN_LOGGER_CONFIG,
					useValue: { level: NgxLoggerLevel.ERROR },
				},
				{
					provide: TitleService,
					useValue: TitleServiceStub,
				},
				{
					provide: TranslateService,
					useValue: TranslateServiceStub,
				},
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PaymentLinkComponent);
		component = fixture.componentInstance;
		payService = TestBed.get(PaymentUrlService);
		saleInfoService = TestBed.get(SaleInfoService);
		modalService = TestBed.get(CdsModalService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("check if payment link already created", () => {
		saleInfoService.paymentLinkCreated = true;
		saleInfoService.paymentLinkResponse = paymentLinkRes;
		const expiryDate = new Date();
		expiryDate.setHours(23, 59, 0, 0);
		saleInfoService.paymentLinkExpiryDate = expiryDate;
		component.ngOnInit();
		fixture.detectChanges();
		expect(component.payUrl).toEqual(paymentLinkRes.paymentLinkURL);
	});

	it("should copy payment url", fakeAsync(() => {
		Object.assign(navigator, {
			clipboard: {
				writeText: jest.fn().mockImplementation(() => Promise.resolve()),
			},
		});
		jest.spyOn(navigator.clipboard, "writeText");
		component.payUrl = "https://abc.com";
		component.isCopied = false;
		tick();
		component.copyLink(), fixture.detectChanges();
		expect(navigator.clipboard.writeText).toHaveBeenCalled();
	}));

	it("check clearDateTime", () => {
		component.clearDateTime();
		fixture.detectChanges();
		expect(component.linkExpiryDate).toBeUndefined();
		expect(component.timeInput).toEqual("23:59");
	});

	it("check onDateTimeChange if empty date value", () => {
		component.onDateTimeChange();
		const check = new Date();
		check.setHours(23, 59, 0, 0);
		expect(component.linkExpiryDate).toEqual(check);
	});

	it("check onDateTimeChange if date value", () => {
		const tomorrow = new Date();
		tomorrow.setDate(tomorrow.getDate() + 1);
		component.onDateTimeChange(tomorrow);
		const check = new Date(tomorrow.getTime());
		check.setHours(23, 59, 0, 0);
		expect(component.linkExpiryDate).toEqual(check);
	});

	it("check onDateTimeChange if date string value", () => {
		const stringT = "4/2/1988";
		const date = new Date(stringT);
		component.onDateTimeChange(stringT);
		const check = new Date(date.getTime());
		check.setHours(23, 59, 0, 0);
		expect(component.linkExpiryDate).toEqual(check);
	});

	it("check onDateTimeChange if date and time value", () => {
		const tomorrow = new Date();
		tomorrow.setDate(tomorrow.getDate() + 1);
		component.onDateTimeChange(tomorrow, "11:59");
		const check = new Date(tomorrow.getTime());
		check.setHours(11, 59, 0, 0);
		expect(component.linkExpiryDate).toEqual(check);
	});

	it("should navigate back", () => {
		component.goBack();
		fixture.detectChanges();
	});

	it("should check closeToast", () => {
		component.closeToast();
		fixture.detectChanges();
		expect(component.toastOpen).toBeFalsy();
	});

	it("should close modal", () => {
		jest.spyOn(modalService, "closeModal");
		component.closeModal();
		fixture.detectChanges();
		expect(modalService.closeModal).toHaveBeenCalled();
	});
});
