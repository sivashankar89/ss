import {
	AfterViewInit,
	Component,
	ElementRef,
	OnDestroy,
	OnInit,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { StepperFullScreenComponent } from "shared/template/stepper-full-screen/stepper-full-screen.component";
import { PaymentUrlService } from "services/payment-url.service";
import { SaleInfoService } from "services/sale-info.service";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { ReplaySubject, switchMap, take, takeUntil } from "rxjs";
import { PaymentLinkResponse } from "bff-client";
import { PaymentLinkCreationStateEnum } from "enum/payments.enum";
import { downloadBlob } from "utils/common.utils";
import { TelemetryService } from "services/telemetry.service";

@Component({
	selector: "app-payment-link",
	templateUrl: "./payment-link.component.html",
	styleUrls: ["./payment-link.component.scss"],
})
export class PaymentLinkComponent implements OnInit, AfterViewInit, OnDestroy {
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;

	@ViewChild("qrCodeContainer") qrCodeContainer!: ElementRef;

	stepInValid = false;
	isCopied = false;
	payUrl = "";
	toastOpen = false;
	toastCopyQROpen = false;
	toastDownloadJpgOpen = false;
	toastDownloadPngOpen = false;
	linkExpiryDate!: Date | undefined;
	yesterday = new Date();
	dateTimeFormat = "dd/MM/yyyy hh:mm a";
	dateInput!: string;
	timeInput = "23:59";
	errorMessage!: string;
	state = PaymentLinkCreationStateEnum.INIT;
	stateEnum = PaymentLinkCreationStateEnum;
	private destroyed$ = new ReplaySubject<void>(1);

	constructor(
		private payService: PaymentUrlService,
		private stepperComponent: StepperFullScreenComponent,
		private saleInfoService: SaleInfoService,
		private modalService: CdsModalService,
		private telemetryService: TelemetryService
	) {}

	ngOnInit(): void {
		this.yesterday.setDate(this.yesterday.getDate() - 1);
		if (this.saleInfoService.paymentLinkCreated === true) {
			this.updateLink(this.saleInfoService.paymentLinkResponse);
		}
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	ngOnDestroy(): void {
		this.destroyed$.next();
		this.destroyed$.complete();
	}

	clearDateTime(): void {
		if (this.state !== PaymentLinkCreationStateEnum.INIT) {
			return;
		}
		this.linkExpiryDate = undefined;
		this.timeInput = "23:59";
		this.stepInValid = false;
	}

	onDateTimeChange(dateVal?: string | Date, timeVal?: string): void {
		if (this.state !== PaymentLinkCreationStateEnum.INIT) {
			return;
		}

		if (typeof dateVal === "string") {
			dateVal = new Date(dateVal);
		}
		if (!dateVal) {
			dateVal = new Date();
		}
		if (!timeVal) {
			timeVal = "23:59";
		}
		const [h, m] = timeVal.split(":").map((n) => parseInt(n, 10));
		dateVal.setHours(h, m, 0, 0);
		this.linkExpiryDate = new Date(dateVal.getTime());

		if (dateVal.getTime() <= new Date().getTime()) {
			this.stepInValid = true;
		} else {
			this.stepInValid = false;
		}
	}

	goSuccessPage(): void {
		this.stepperComponent.goNext(2);
	}

	goBack(): void {
		this.stepperComponent.goBack();
	}

	closeModal(): void {
		this.modalService.closeModal();
	}

	copyLink(): void {
		navigator?.clipboard?.writeText(this.payUrl).then(() => {
			this.isCopied = true;
			this.toastOpen = true;
		});
	}

	downloadQrCode(type = "png") {
		const qrcNativeElement = this.qrCodeContainer?.nativeElement;
		if (!qrcNativeElement) {
			return;
		}
		const canvas: HTMLCanvasElement = qrcNativeElement.querySelector("canvas");
		canvas.toBlob((blob) => {
			if (blob) {
				const filename =
					this.saleInfoService.paymentLinkResponse?.orderId ?? "qr-code";
				downloadBlob(blob, filename + "." + type);
				this.isCopied = true;
				if (type === "png") {
					this.toastDownloadPngOpen = true;
				} else {
					this.toastDownloadJpgOpen = true;
				}
			}
		});
	}

	copyQrCode() {
		const qrcNativeElement = this.qrCodeContainer?.nativeElement;
		if (!qrcNativeElement) {
			return;
		}
		const canvas: HTMLCanvasElement = qrcNativeElement.querySelector("canvas");
		canvas.toBlob((blob) => {
			// @ts-ignore
			if (blob && window["ClipboardItem"]) {
				// @ts-ignore
				const item = new ClipboardItem({
					"image/png": new Promise((resolve) => resolve(blob)),
				});
				const clipboard = window.navigator["clipboard"] as any;
				if (clipboard) {
					clipboard.write([item]).then(() => {
						this.isCopied = true;
						this.toastCopyQROpen = true;
					});
				}
			}
		});
	}

	displayErrorMessage(errorMessage: string) {
		this.state = PaymentLinkCreationStateEnum.FAILED;
		this.errorMessage = errorMessage;
	}

	getPaymentUrl(): void {
		this.state = PaymentLinkCreationStateEnum.LOADING;
		this.telemetryService.withSpanName(this.getPaymentUrl.name, () =>
			this.saleInfoService
				.getPaymentLinkPayload$(this.linkExpiryDate)
				.pipe(
					take(1),
					switchMap((payload) => this.payService.postData(payload)),
					takeUntil(this.destroyed$)
				)
				.subscribe({
					next: (response) => {
						if (!response.paymentLinkId) {
							this.displayErrorMessage("");
						} else {
							this.saleInfoService.paymentLinkCreated = true;
							this.saleInfoService.paymentLinkResponse = response;
							this.updateLink(response);
						}
					},
					error: (e) => {
						this.displayErrorMessage(e.message);
					},
				})
		);
	}

	updateLink(response: PaymentLinkResponse | null): void {
		this.state = response?.paymentLinkURL
			? PaymentLinkCreationStateEnum.SUCCESS
			: PaymentLinkCreationStateEnum.INIT;
		this.payUrl = response?.paymentLinkURL || "";
		this.linkExpiryDate = response?.expiryDateTime
			? new Date(response?.expiryDateTime)
			: undefined;
	}

	closeToast(): void {
		this.toastOpen = false;
		this.toastCopyQROpen = false;
		this.toastDownloadJpgOpen = false;
		this.toastDownloadPngOpen = false;
	}
}
