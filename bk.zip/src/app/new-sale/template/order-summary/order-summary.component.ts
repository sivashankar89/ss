import {
	AfterViewInit,
	Component,
	OnInit,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { SaleInfoService } from "../../../services/sale-info.service";
import { PAGE_FROM } from "../../../enum/primary.transaction.enum";
import { PaymentRequest } from "bff-client";

@Component({
	selector: "app-order-summary",
	templateUrl: "./order-summary.component.html",
	styleUrls: ["./order-summary.component.scss"],
})
export class OrderSummaryComponent implements OnInit, AfterViewInit {
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	orderDetails!: PaymentRequest;
	transTypeText = "";

	public stepInValid = false;
	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private saleinfoService: SaleInfoService
	) {}

	ngOnInit(): void {
		this.saleinfoService.getOrderDetails$().subscribe({
			next: (orderDetails: PaymentRequest) => {
				if (orderDetails) {
					this.orderDetails = { ...orderDetails };
					if (this.orderDetails.transactionType === PAGE_FROM.PREAUTH) {
						this.transTypeText = "Pre-authorisation";
					} else if (this.orderDetails.transactionType === PAGE_FROM.SALE) {
						this.transTypeText = "Sale";
					} else if (this.orderDetails.transactionType === PAGE_FROM.CREDIT) {
						this.transTypeText = "Credit";
					}
				}
			},
			error: (error) => {
				return error;
			},
		});
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	goBack(): void {
		this.stepperComponent.goBack();
	}

	goNext(): void {
		this.stepperComponent.goNext();
	}
}
