import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";

import { OrderSummaryComponent } from "./order-summary.component";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { Observable } from "rxjs";
import { SaleInfoService } from "../../../services/sale-info.service";
import { RouterTestingModule } from "@angular/router/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { initOrderDetails } from "model/new-sale-order.model";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
} from "@international-payment-platform/design-system-angular";

describe("OrderSummaryComponent", () => {
	let component: OrderSummaryComponent;
	let fixture: ComponentFixture<OrderSummaryComponent>;
	let saleInfoService: SaleInfoService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [OrderSummaryComponent],
			imports: [
				RouterTestingModule,
				PipesMockModule,
				CdsModalModule,
				CdsModalFullscreenModule,
			],
			providers: [StepperFullScreenComponent, SaleInfoService],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderSummaryComponent);
		component = fixture.componentInstance;
		saleInfoService = TestBed.get(SaleInfoService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should go back", () => {
		component.goBack();
		fixture.detectChanges();
		expect(component).toBeTruthy();
	});

	it("should go next", () => {
		component.goNext();
		fixture.detectChanges();
		expect(component).toBeTruthy();
	});

	it("Should get order details for sale", fakeAsync(() => {
		const order = { ...initOrderDetails };
		order.transactionType = "SALE";
		jest.spyOn(saleInfoService, "getOrderDetails$").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(order);
				return observer;
			})
		);
		component.ngOnInit();
		tick();
		expect(component.orderDetails).toBeTruthy();
		expect(component.transTypeText).toBe("Sale");
	}));

	it("Should get order details for pre-auth", fakeAsync(() => {
		const order = { ...initOrderDetails };
		order.transactionType = "PREAUTH";
		jest.spyOn(saleInfoService, "getOrderDetails$").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(order);
				return observer;
			})
		);
		component.ngOnInit();
		tick();
		expect(component.orderDetails).toBeTruthy();
		expect(component.transTypeText).toBe("Pre-authorisation");
	}));

	it("Should get order details for credit", fakeAsync(() => {
		const order = { ...initOrderDetails };
		order.transactionType = "CREDIT";
		jest.spyOn(saleInfoService, "getOrderDetails$").mockReturnValue(
			Observable.create((observer: any) => {
				observer.next(order);
				return observer;
			})
		);
		component.ngOnInit();
		tick();
		expect(component.orderDetails).toBeTruthy();
		expect(component.transTypeText).toBe("Credit");
	}));
});
