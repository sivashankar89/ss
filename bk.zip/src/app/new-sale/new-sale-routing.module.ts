import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { NewsaleLayoutComponent } from "./page/newsale-layout/newsale-layout.component";

@NgModule({
	imports: [
		RouterModule.forChild([
			{
				path: "",
				component: NewsaleLayoutComponent,
			},
		]),
	],
	exports: [RouterModule],
})
export class NewSaleRoutingModule {}
