import { Component, EventEmitter, OnDestroy, Output } from "@angular/core";
import { SaleInformationComponent } from "../../template/sale-information/sale-information.component";
import { OrderSummaryComponent } from "../../template/order-summary/order-summary.component";
import { PaymentOptionComponent } from "../../template/payment-option/payment-option.component";
import { PaymentSuccessFailureComponent } from "../../template/payment-success-failure/payment-success-failure.component";
import { SaleInfoService } from "../../../services/sale-info.service";
import { PAGE_FROM } from "../../../enum/primary.transaction.enum";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { StepInfo } from "model/common.model";
import { PaymentLinkSuccessComponent } from "new-sale/template/payment-link-success/payment-link-success.component";

@Component({
	selector: "app-newsale-stepper",
	templateUrl: "./newsale-stepper.component.html",
	styles: [],
})
export class NewsaleStepperComponent implements OnDestroy {
	public steps: StepInfo[] = [
		{
			title: this.translateService.instantSafe("new_sale.sale_amt"),
			component: SaleInformationComponent,
		},
		{
			title: this.translateService.instantSafe("shared.orderSummary"),
			component: OrderSummaryComponent,
			back: true,
		},
		{
			title: this.translateService.instantSafe("shared.payment_options"),
			component: PaymentOptionComponent,
			back: true,
		},
		{
			title: this.translateService.instantSafe("shared.payment_options"),
			component: PaymentSuccessFailureComponent,
			hide: true,
			closeLabel: this.translateService.instantSafe("general.close"),
		},
		{
			title: this.translateService.instantSafe("shared.payment_options"),
			component: PaymentLinkSuccessComponent,
			hide: true,
			closeLabel: this.translateService.instantSafe("general.close"),
		},
	];
	@Output() destroy = new EventEmitter();

	constructor(
		private saleInfo: SaleInfoService,
		private titleService: TitleService,
		private translateService: TranslateService
	) {
		this.saleInfo.pageToInitiate = PAGE_FROM.SALE;
	}

	updateBrowserTitle(title: string): void {
		this.titleService.setTitle(
			this.translateService.instantSafe("app.title_newSale") + " | " + title
		);
	}

	ngOnDestroy(): void {
		this.saleInfo.resetSaleInfo();
		this.titleService.setTitle(
			this.translateService.instantSafe("app.title_transaction")
		);
		this.destroy.emit();
	}
}
