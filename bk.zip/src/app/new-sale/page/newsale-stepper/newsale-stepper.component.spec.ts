import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { TitleService } from "@international-payment-platform/portal-core";
import { NewsaleStepperComponent } from "./newsale-stepper.component";
import { SaleInfoService } from "../../../services/sale-info.service";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { TranslateService } from "@tolgee/ngx";
import { TelemetryService } from "services/telemetry.service";

describe("NewsaleStepperComponent", () => {
	let component: NewsaleStepperComponent;
	let fixture: ComponentFixture<NewsaleStepperComponent>;
	let saleInfoService: SaleInfoService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [NewsaleStepperComponent],
			providers: [
				SaleInfoService,
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(NewsaleStepperComponent);
		component = fixture.componentInstance;
		jest.spyOn(TitleServiceStub, "setTitle");
		saleInfoService = TestBed.get(SaleInfoService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("THEN should set title", () => {
		component.updateBrowserTitle("New sale");
		expect(TitleServiceStub.setTitle).toHaveBeenCalled();
	});

	it("title to reset when destroy component", () => {
		component.ngOnDestroy();
		expect(saleInfoService.tabPayType).toEqual(false);
	});
});
