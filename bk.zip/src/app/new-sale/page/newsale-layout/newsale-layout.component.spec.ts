import { OverlayModule } from "@angular/cdk/overlay";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, fakeAsync, TestBed } from "@angular/core/testing";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { TitleService } from "@international-payment-platform/portal-core";
import { DefaultTranspiler, TRANSLOCO_TRANSPILER } from "@ngneat/transloco";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { NewsaleStepperComponent } from "../newsale-stepper/newsale-stepper.component";
import { NewsaleLayoutComponent } from "./newsale-layout.component";
import { TelemetryService } from "services/telemetry.service";

describe("NewsaleLayoutComponent", () => {
	let component: NewsaleLayoutComponent;
	let fixture: ComponentFixture<NewsaleLayoutComponent>;
	let modalService: CdsModalService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [NewsaleLayoutComponent, NewsaleStepperComponent],
			imports: [RouterTestingModule, OverlayModule, PipesMockModule],
			providers: [
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		})
			.overrideModule(BrowserDynamicTestingModule, {
				set: {
					entryComponents: [NewsaleStepperComponent],
				},
			})
			.compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(NewsaleLayoutComponent);
		component = fixture.componentInstance;
		modalService = TestBed.inject(CdsModalService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should close modal on destroy", fakeAsync(() => {
		jest.spyOn(modalService, "closeModal").mockReturnValue();
		component.ngOnDestroy();
		expect(modalService.closeModal).toHaveBeenCalled();
	}));
});
