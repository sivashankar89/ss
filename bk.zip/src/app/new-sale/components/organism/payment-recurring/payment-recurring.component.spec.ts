import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { CdsDatepickerModule } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { SaleInfoService } from "services/sale-info.service";

import { PaymentRecurringComponent } from "./payment-recurring.component";
import { TelemetryService } from "services/telemetry.service";

describe("PaymentRecurringComponent", () => {
	let component: PaymentRecurringComponent;
	let fixture: ComponentFixture<PaymentRecurringComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PaymentRecurringComponent],
			imports: [FormsModule, CdsDatepickerModule, PipesMockModule],
			providers: [
				SaleInfoService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{ provide: NgForm, useValue: new NgForm([], []) },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PaymentRecurringComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
