import { Component, Optional, Input, OnInit } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { initRecurringOrderDetails } from "model/new-sale-order.model";
import { PaymentRequest } from "bff-client";
import { RecurringOrderService } from "services/recurring-order.service";

@Component({
	selector: "app-payment-recurring",
	templateUrl: "./payment-recurring.component.html",
	styleUrls: ["./payment-recurring.component.scss"],
	viewProviders: [
		{
			provide: ControlContainer,
			useExisting: NgForm,
		},
	],
})
export class PaymentRecurringComponent implements OnInit {
	orderDetails: PaymentRequest = JSON.parse(
		JSON.stringify(initRecurringOrderDetails)
	);
	isRecurringPayment = false;
	recurringOpions: Array<any> = [];
	delayOptions: Array<any> = [];
	repeatDelay = "Never";
	today = new Date();
	@Input() cardSuccess = false;
	constructor(
		@Optional() public form: NgForm,
		private recurringService: RecurringOrderService
	) {}

	ngOnInit(): void {
		if (this.orderDetails.frequency) {
			this.orderDetails.frequency.every = 1;
			this.orderDetails.frequency.unit = "";
		}
		this.today.setDate(this.today.getDate() - 1);
		this.recurringOpions = this.recurringService.getRecurringOptionLists();
		this.delayOptions = this.recurringService.getDelayOptionList();
	}
}
