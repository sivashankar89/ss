import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { COMPLETION_MOCK_RESPONSE } from "mocks/refund/refund.mock";
import { BehaviorSubject, of } from "rxjs";
import { OrderDetailsService } from "services/order-details.service";
import { SaleInfoService } from "services/sale-info.service";
import { OrderDetailsComponent } from "./order-details.component";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("OrderDetailsComponent", () => {
	let component: OrderDetailsComponent;
	let fixture: ComponentFixture<OrderDetailsComponent>;
	let orderService: OrderDetailsService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [OrderDetailsComponent],
			imports: [FormsModule, HttpClientModule, PipesMockModule],
			providers: [
				{ provide: NgForm, useValue: new NgForm([], []) },
				OrderDetailsService,
				SaleInfoService,
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsComponent);
		orderService = TestBed.get(OrderDetailsService);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should get order details be falsy", fakeAsync(() => {
		orderService.orderDetails$ = of({
			loading: false,
			error: { message: "Order not found" },
		});
		component.orderDetails = {
			order: {
				orderId: "123456",
			},
		};
		component.ngOnInit();
		component.orderIdChangeEvent$.next("123456");
		tick();
		expect(component.isOrderAvailable).toBeFalsy();
	}));

	it("should get order details be truthy", fakeAsync(() => {
		orderService.orderDetails$ = of({
			loading: false,
			value: COMPLETION_MOCK_RESPONSE,
		});
		component.orderDetails = {
			order: {
				orderId: "123456",
			},
		};
		component.orderIdChangeEvent$.next("123456");
		component.ngOnInit();
		tick();
		expect(component.isOrderAvailable).toBeTruthy();
	}));

	it("should emit order id", () => {
		component.orderIdChange("123456");
		component.orderIdChangeEvent$.subscribe((orderId) =>
			expect(orderId).toBe("123456")
		);
	});

	it("should change orderId", fakeAsync(() => {
		orderService.setOrderId = () => true;
		jest.spyOn(orderService, "setOrderId");
		component.orderIdChangeEvent$ = new BehaviorSubject("");
		component.initiateOrderIdChange();
		component.orderIdChangeEvent$.next("123456");
		tick(1000);
		expect(orderService.setOrderId).toHaveBeenCalledWith("123456");
	}));
});
