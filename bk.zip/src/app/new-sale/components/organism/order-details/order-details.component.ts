import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import {
	BehaviorSubject,
	debounceTime,
	distinctUntilChanged,
	ReplaySubject,
	takeUntil,
} from "rxjs";
import { PaymentRequest } from "bff-client";
import { OrderDetailsService } from "../../../../services/order-details.service";
import { SaleInfoService } from "../../../../services/sale-info.service";
import { VTPaymentPermissions } from "enum/permissions.enum";
@Component({
	selector: "app-order-details",
	templateUrl: "./order-details.component.html",
	styleUrls: ["./order-details.component.scss"],
	viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class OrderDetailsComponent implements OnInit, OnDestroy {
	@Input() orderDetails!: PaymentRequest;
	isOrderAvailable = false;
	notificationLanguage = "en";
	notificationLanguages = [{ name: "English", value: "en" }];
	orderIdChangeEvent$ = new BehaviorSubject<string>("");
	paymentPermissions = VTPaymentPermissions;
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);
	constructor(
		private orderService: OrderDetailsService,
		private saleInfoService: SaleInfoService
	) {
		this.initiateOrderIdChange();
	}

	ngOnInit(): void {
		this.isOrderAvailable = false;
		this.saleInfoService.isOrderAvailable = false;
		if (!this.orderDetails) {
			this.orderDetails = {};
		}
		if (!this.orderDetails?.order) {
			this.orderDetails.order = {};
		}
		if (!this.orderDetails?.order?.billing) {
			this.orderDetails.order = {
				...this.orderDetails.order,
				billing: { customerId: "" },
			};
		}
		if (!this.orderDetails?.order?.additionalDetails) {
			this.orderDetails.order = {
				...this.orderDetails.order,
				additionalDetails: { invoiceNumber: "" },
			};
		}
		this.orderService.orderDetails$.pipe(takeUntil(this.destroyed$)).subscribe({
			next: (res: any) => {
				if (
					!!res &&
					!!!res?.error &&
					!!res.value &&
					!!this.orderDetails?.order?.orderId
				) {
					this.isOrderAvailable = true;
					this.saleInfoService.isOrderAvailable = true;
				} else if (!!!res.value) {
					this.isOrderAvailable = false;
					this.saleInfoService.isOrderAvailable = false;
				}
			},
			error: (err) => {
				this.isOrderAvailable = false;
				this.saleInfoService.isOrderAvailable = false;
			},
		});
		if (this.orderDetails.order.orderId) {
			this.orderIdChange(this.orderDetails.order.orderId);
		}
	}

	initiateOrderIdChange(): void {
		this.orderIdChangeEvent$
			.pipe(debounceTime(1000), distinctUntilChanged())
			.subscribe((id) => this.orderService.setOrderId(id ? id : ""));
	}

	orderIdChange(id: string): void {
		if (id.trim()) {
			this.saleInfoService.orderIdCheckProgress = true;
		} else {
			this.saleInfoService.orderIdCheckProgress = false;
		}
		this.orderIdChangeEvent$.next(id.trim());
		this.changeOrderDetails();
	}

	changeOrderDetails(): void {
		if (this.saleInfoService.paymentLinkCreated) {
			this.saleInfoService.paymentLinkCreated = false;
			this.saleInfoService.paymentLinkResponse = null;
		}
	}

	ngOnDestroy(): void {
		this.orderService.setOrderId("");
		this.destroyed$.next();
		this.destroyed$.complete();
	}
}
