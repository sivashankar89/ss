import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { ShippingAddress, Order } from "bff-client";
import { SaleInfoService } from "../../../../services/sale-info.service";

@Component({
	selector: "app-delivery-details",
	templateUrl: "./delivery-details.component.html",
	styleUrls: ["./delivery-details.component.scss"],
})
export class DeliveryDetailsComponent implements OnInit {
	@Input() order!: Order;
	@Output() openAddress = new EventEmitter<"billing" | "delivery">();
	@Input() expandedAddress = {
		billing: false,
		delivery: false,
	};
	isAddressAvailable = false;
	@Input() billingAvail = false;
	constructor(private saleInfoService: SaleInfoService) {}

	ngOnInit(): void {
		this.isAddressAvailable = this.saleInfoService.isDeliveryAvailable;
	}

	addressUpdate(source: string, event: any): void {
		const shipping: ShippingAddress = {};
		shipping.address = event.address;
		shipping.contact = event.contact;
		shipping.name = event.name;
		this.order.shipping = shipping;
		this.isAddressAvailable = true;
		this.toggleAddress();
		this.saleInfoService.isDeliveryAvailable = true;
	}

	copyDeliverAddress(): void {
		const address = JSON.parse(JSON.stringify(this.order.billing));
		delete address.customerId;
		this.order.shipping = address;
		if (this.order.shipping?.contact) {
			delete this.order.shipping.contact.fax;
		}
		if (this.order.shipping?.address) {
			delete this.order.shipping.address.company;
		}
		this.isAddressAvailable = true;
		this.expandedAddress.delivery = true;
		this.toggleAddress();
		this.saleInfoService.isDeliveryAvailable = true;
	}

	toggleAddress(): void {
		this.openAddress.emit("delivery");
		if (this.saleInfoService.paymentLinkCreated) {
			this.saleInfoService.paymentLinkCreated = false;
			this.saleInfoService.paymentLinkResponse = null;
		}
	}
}
