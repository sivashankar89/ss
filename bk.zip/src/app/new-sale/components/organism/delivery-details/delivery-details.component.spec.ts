import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ShippingAddress } from "bff-client";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { initAddressValues, initContactInfo } from "model/new-sale-order.model";
import { SaleInfoService } from "services/sale-info.service";
import { DeliveryDetailsComponent } from "./delivery-details.component";

describe("DeliveryDetailsComponent", () => {
	let component: DeliveryDetailsComponent;
	let fixture: ComponentFixture<DeliveryDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [DeliveryDetailsComponent],
			imports: [PipesMockModule],
			providers: [SaleInfoService],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(DeliveryDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should update address", () => {
		component.order = {};
		component.order.shipping = {};
		component.order.shipping.address = { ...initAddressValues };
		component.order.shipping.contact = { ...initContactInfo };
		const event: ShippingAddress = {};
		event.name = "demo";
		event.address = {
			address1: "address1",
			address2: "address2",
			city: "city1",
			region: "region1",
			postalCode: "9080980",
			country: "Germany",
			company: "test",
		};
		event.contact = {
			phone: "9080908090",
			mobilePhone: "9900889900",
			fax: "",
			email: "deom@test.com",
		};
		const source = "delivery";
		component.addressUpdate(source, event);
		expect(component.order.shipping.address).toEqual(event.address);
		expect(component.order.shipping.contact).toEqual(event.contact);
		expect(component.isAddressAvailable).toBeTruthy();
	});

	it("should copy address", () => {
		component.order = {};
		component.order.billing = {};
		component.order.billing.address = { ...initAddressValues };
		component.order.billing.contact = { ...initContactInfo };
		component.copyDeliverAddress();
		expect(component.order?.shipping?.address?.address1).toEqual(
			component.order.billing.address.address1
		);
		expect(component.order?.shipping?.contact?.phone).toEqual(
			component.order.billing.contact.phone
		);
		expect(component.isAddressAvailable).toBeTruthy();
	});

	it("should copy without address", () => {
		component.order = {};
		component.order.billing = {};
		component.copyDeliverAddress();
		expect(component.order?.shipping?.address).toBeFalsy();
		expect(component.order?.shipping?.contact).toBeFalsy();
		expect(component.isAddressAvailable).toBeTruthy();
	});
});
