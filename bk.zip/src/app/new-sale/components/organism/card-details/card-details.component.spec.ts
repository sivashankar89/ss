import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule } from "@angular/forms";
import { NgForm } from "@angular/forms";
import { CdsDatepickerModule } from "@international-payment-platform/design-system-angular";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { SaleInfoService } from "services/sale-info.service";
import { StoreCardBrandsComponent } from "shared/components/molecules/store-card-brands/store-card-brands.component";
import { CardInfoComponent } from "../card-info/card-info.component";
import { CardDetailsComponent } from "./card-details.component";
import { TelemetryService } from "services/telemetry.service";

describe("CardDetailsComponent", () => {
	let component: CardDetailsComponent;
	let fixture: ComponentFixture<CardDetailsComponent>;
	let modalService: CdsModalService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [
				HttpClientModule,
				FormsModule,
				CdsDatepickerModule,
				PipesMockModule,
			],
			declarations: [CardDetailsComponent],
			providers: [
				SaleInfoService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{ provide: NgForm, useValue: new NgForm([], []) },
				{
					provide: CdsModalService,
					useValue: {
						openModal: jest.fn(),
						closeModal: jest.fn(),
					},
				},
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CardDetailsComponent);
		component = fixture.componentInstance;
		modalService = TestBed.get(CdsModalService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("check validateCards emits", () => {
		jest.spyOn(component.changeEvent, "emit");
		component.validateCards("card");
		expect(component.changeEvent.emit).toHaveBeenCalled();
	});

	it("check onDateTimeChange if date value", () => {
		const tomorrow = new Date();
		tomorrow.setDate(tomorrow.getDate() + 1);
		component.onDateTimeChange(tomorrow);
		expect(component.dobDate).toEqual(tomorrow);
	});

	it("check onDateTimeChange if date string value", () => {
		const stringT = "4/2/1988";
		const date = new Date(stringT);
		component.onDateTimeChange(stringT);
		expect(component.dobDate).toEqual(date);
	});

	it("check openBrands function", () => {
		jest.spyOn(modalService, "openModal");
		component.openBrands();
		expect(modalService.openModal).toHaveBeenCalledWith(
			StoreCardBrandsComponent
		);
	});

	it("check showcardInfo function", () => {
		jest.spyOn(modalService, "openModal");
		component.showcardInfo();
		expect(modalService.openModal).toHaveBeenCalledWith(CardInfoComponent);
	});
});
