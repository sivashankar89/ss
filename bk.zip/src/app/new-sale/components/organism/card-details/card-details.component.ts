import {
	Component,
	EventEmitter,
	Input,
	Output,
	ViewChild,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import {
	CdsCardInputNumberComponent,
	CdsModalService,
	CdsPaymentBrand,
} from "@international-payment-platform/design-system-angular";
import { StoreCardBrandsComponent } from "../../../../shared/components/molecules/store-card-brands/store-card-brands.component";
import { CardService } from "../../../../services/card.service";
import { CardInfoComponent } from "../card-info/card-info.component";
import { SaleInfoService } from "../../../../services/sale-info.service";
import { TranslateService } from "@tolgee/ngx";
import { IndustrySpecificExtensions, PaymentCard } from "bff-client";
import { initCardDetails, initMcc6012 } from "model/new-sale-order.model";
import { VTPaymentPermissions } from "enum/permissions.enum";

@Component({
	selector: "app-card-details",
	templateUrl: "./card-details.component.html",
	styleUrls: ["./card-details.component.scss"],
	viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class CardDetailsComponent {
	obtainCard = "";
	card: PaymentCard = JSON.parse(JSON.stringify(initCardDetails));
	mcc: IndustrySpecificExtensions = JSON.parse(JSON.stringify(initMcc6012));
	@Input() isSubmitted: any;
	@Output() changeEvent = new EventEmitter();
	obtainCardType = [
		{
			name: this.translateService.instantSafe("shared.telephone_order"),
			value: "PHONE",
		},
		{
			name: this.translateService.instantSafe("shared.mail_order"),
			value: "MAIL",
		},
	];
	@Input() cardSuccess: any;
	saveCardWithToken = false;
	@Input() cardValidating = false;
	mccTabs = [
		{
			name: this.translateService.instantSafe("shared.account_number"),
			value: "accNumber",
		},
		{ name: this.translateService.instantSafe("shared.pan"), value: "pan" },
	];
	activeMccTab = "accNumber";
	pageFrom = this.saleInfoService.pageToInitiate;
	mccAdditionRequired = this.saleInfoService.mccSupportedMerchant;
	dobDate!: Date | undefined;
	dateTimeFormat = "dd/MM/yyyy";
	today = new Date();
	paymentPermissions = VTPaymentPermissions;
	@ViewChild(CdsCardInputNumberComponent)
	cardBrandNumber!: CdsCardInputNumberComponent;
	@Input() mccSupportedBrandAndMerchant = false;
	brandType: CdsPaymentBrand | undefined = CdsPaymentBrand.Visa;
	constructor(
		private cardService: CardService,
		private saleInfoService: SaleInfoService,
		private modalService: CdsModalService,
		private translateService: TranslateService
	) {}

	validateCards(type: string): void {
		if (type === "card") {
			this.brandType = this.cardBrandNumber?.brand;
			this.saleInfoService.payCardBrand = this.cardBrandNumber?.brand;
		}
		this.changeEvent.emit();
	}

	onDateTimeChange(dateVal?: string | Date): void {
		if (typeof dateVal === "string") {
			dateVal = new Date(dateVal);
		}
		if (!dateVal) {
			dateVal = new Date();
		}
		this.dobDate = new Date(dateVal.getTime());
	}

	openBrands(): void {
		this.modalService.openModal(StoreCardBrandsComponent);
	}

	showcardInfo(): void {
		this.modalService.openModal(CardInfoComponent);
	}

	selection(event: any): void {
		this.activeMccTab = event;
		this.saleInfoService.mccActivatedTab = event;
	}
}
