import { Component, Input } from "@angular/core";
import { PaymentRequest } from "bff-client";
import { VTPaymentPermissions } from "enum/permissions.enum";

@Component({
	selector: "app-order-info",
	templateUrl: "./order-info.component.html",
	styleUrls: ["./order-info.component.scss"],
})
export class OrderInfoComponent {
	@Input() orderDetails!: PaymentRequest;
	@Input() transType = "";
	paymentPermissions = VTPaymentPermissions;
}
