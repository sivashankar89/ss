import { Component, Input, OnInit, Optional } from "@angular/core";
import { Currency, CurrencyEnum, TransactionAmount } from "bff-client";
import { SelectOption } from "shared/models/select-options";
import { SaleInfoService } from "services/sale-info.service";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
	selector: "app-sale-amount",
	templateUrl: "./sale-amount.component.html",
	styleUrls: ["./sale-amount.component.scss"],
	viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class SaleAmountComponent implements OnInit {
	@Input() currencyList!: Array<SelectOption<Currency>>;
	@Input() currencyObj!: Currency;
	@Input() title = "";
	@Input() transaction!: TransactionAmount;
	currencyOptions: Array<SelectOption<string>> = [];

	constructor(
		@Optional() public form: NgForm,
		private saleInfoService: SaleInfoService
	) {}

	ngOnInit(): void {
		if (!!this.saleInfoService.storeCurrency) {
			this.currencyObj = this.saleInfoService.storeCurrency;
		}

		this.currencyOptions =
			this.currencyList?.map((x) => ({
				...x,
				value: x.value?.literalCurrencyCode || "",
			})) || [];
	}

	updateCurrency(currency: string): void {
		this.currencyObj =
			this.currencyList.find((x) => x.name === currency)?.value || {};
		this.saleInfoService.storeCurrency = this.currencyObj;
		this.saleInfoService.paymentLinkCreated = false;
		this.saleInfoService.paymentLinkResponse = null;
	}

	totaAmt(amt: any): void {
		if (this.transaction) {
			if (
				this.saleInfoService.paymentLinkCreated === true &&
				this.transaction.total !== amt
			) {
				this.saleInfoService.paymentLinkCreated = false;
				this.saleInfoService.paymentLinkResponse = null;
			}
			this.transaction.total = amt;
			this.transaction.currency = this.currencyObj?.literalCurrencyCode as any;
		}
	}
}
