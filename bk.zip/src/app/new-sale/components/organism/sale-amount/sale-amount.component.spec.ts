import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { CURRENCIES_MOCK } from "mocks/currencies.mock";
import { PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE } from "mocks/payment_api/transactions.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { SaleInfoService } from "services/sale-info.service";
import { SaleAmountComponent } from "./sale-amount.component";

describe("SaleAmountComponent", () => {
	let component: SaleAmountComponent;
	let fixture: ComponentFixture<SaleAmountComponent>;
	let saleInfoService: SaleInfoService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SaleAmountComponent],
			imports: [FormsModule, PipesMockModule],
			providers: [
				SaleInfoService,
				{ provide: NgForm, useValue: new NgForm([], []) },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SaleAmountComponent);
		component = fixture.componentInstance;
		if (PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE.approvedAmount) {
			component.transaction =
				PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE.approvedAmount;
		}
		saleInfoService = TestBed.get(SaleInfoService);
		saleInfoService.storeCurrency = CURRENCIES_MOCK[0];
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should update currency", () => {
		const currency = {
			literalCurrencyCode: "EUR",
			numericCurrencyCode: "840",
			decimalPlaces: 2,
			defaultCurrency: true,
		};
		component.currencyList = [
			{
				name: "EUR",
				value: currency,
			},
		];
		component.updateCurrency("EUR");
		fixture.detectChanges();
		expect(component.currencyObj).toEqual(currency);
	});

	it("should display total amount", () => {
		const amt = 20;
		saleInfoService.paymentLinkCreated = true;
		component.totaAmt(amt);
		fixture.detectChanges();
		expect(component.transaction.total).toEqual(amt);
	});
});
