import { Component, Input, OnInit } from "@angular/core";

@Component({
	selector: "app-billing-info",
	templateUrl: "./billing-info.component.html",
	styleUrls: ["./billing-info.component.scss"],
})
export class BillingInfoComponent implements OnInit {
	@Input() billing: any;
	@Input() contact: any;
	@Input() addressType: any;
	addressTab = false;
	contactTab = false;

	ngOnInit(): void {
		const billingConst = this.billing?.address;
		for (const key in billingConst) {
			if (
				billingConst[key] &&
				billingConst[key].trim() !== "" &&
				billingConst[key].trim() !== undefined
			) {
				this.addressTab = true;
			}
		}
		const contactConst = this.billing?.contact;
		for (const key in contactConst) {
			if (
				contactConst[key] &&
				contactConst[key].trim() !== "" &&
				contactConst[key].trim() !== undefined
			) {
				this.contactTab = true;
			}
		}
		const nameConst = this.billing?.name;
		if (
			nameConst &&
			nameConst.trim() !== "" &&
			nameConst.trim() !== undefined
		) {
			this.contactTab = true;
		}
	}
}
