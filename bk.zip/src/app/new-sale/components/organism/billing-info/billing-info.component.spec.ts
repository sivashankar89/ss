import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { BillingInfoComponent } from "./billing-info.component";

describe("BillingInfoComponent", () => {
	let component: BillingInfoComponent;
	let fixture: ComponentFixture<BillingInfoComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [BillingInfoComponent],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(BillingInfoComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should call ngOnInit", () => {
		component.billing = {
			address: {
				address1: "address1",
				address2: "address2",
				city: "city1",
				region: "region1",
				postalCode: "9080980",
				country: "Germany",
				company: "test",
			},
			contact: {
				phone: "9080908090",
				mobilePhone: "9900889900",
				fax: "",
				email: "deom@test.com",
			},
			name: "test",
		};
		component.ngOnInit();
		expect(component.contactTab).toBeTruthy();
	});
});
