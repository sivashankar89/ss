import { OverlayModule } from "@angular/cdk/overlay";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { SaleInfoService } from "services/sale-info.service";

import { CardInfoComponent } from "./card-info.component";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("CardInfoComponent", () => {
	let component: CardInfoComponent;
	let fixture: ComponentFixture<CardInfoComponent>;
	let saleInfoService: SaleInfoService;
	let modalService: CdsModalService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [CardInfoComponent],
			imports: [HttpClientModule, OverlayModule, PipesMockModule],
			providers: [
				SaleInfoService,
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CardInfoComponent);
		component = fixture.componentInstance;
		saleInfoService = TestBed.get(SaleInfoService);
		modalService = TestBed.get(CdsModalService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("Should close modal", () => {
		jest.spyOn(modalService, "closeModal");
		component.closeModal();
		fixture.detectChanges();
		expect(modalService.closeModal).toHaveBeenCalled();
	});
});
