import { Component } from "@angular/core";
import { CardService } from "../../../../services/card.service";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { SaleInfoService } from "services/sale-info.service";
@Component({
	selector: "app-card-info",
	templateUrl: "./card-info.component.html",
	styleUrls: ["./card-info.component.scss"],
})
export class CardInfoComponent {
	cardDetails: any;
	brand = this.saleInfo.payCardBrand;
	tmpCardBrand: any;
	cardNumber = this.saleInfo.cardNumber;

	constructor(
		private modalService: CdsModalService,
		private saleInfo: SaleInfoService,
		private cardService: CardService
	) {
		this.cardDetails = this.saleInfo.cardResponse;
		this.tmpCardBrand = this.saleInfo.payCardBrand;
	}

	closeModal(): void {
		this.modalService.closeModal();
	}
}
