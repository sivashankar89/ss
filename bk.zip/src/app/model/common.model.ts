import { ApiErrorMessage } from "./error.model";
import { CdsIconComponent } from "@international-payment-platform/design-system-angular";
import { Type } from "@angular/core";
export interface DashboardTile {
	name: string;
	title: string;
	icon: CdsIconComponent["icon"];
	component?: Type<any>;
	url?: string;
}

export interface StepInfo {
	title: string;
	component?: Type<any>;
	hide?: boolean;
	back?: boolean;
	closeLabel?: string;
}

export type Optional<T> = T | undefined;

export interface WithLoadingError<T> {
	loading: boolean;
	value?: T;
	error?: ApiErrorMessage;
}

export interface CountryArr {
	name: string;
	value: string;
}
