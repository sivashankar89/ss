import { HttpErrorResponse } from "@angular/common/http";
import { ResponseType } from "bff-client";

// TODO: make reusable with model from error.model file
export type GenericHttpErrorResponse<T> = HttpErrorResponse & {
	error: T;
};

export interface BasicAPIResponseInterface {
	clientRequestId?: string;
	apiTraceId?: string;
	responseType?: ResponseType;
}

export interface ErrorAPIResponseInterface extends BasicAPIResponseInterface {
	error?: {
		code?: string;
		message?: string;
		details?: Array<{
			field?: string;
			message?: string;
		}>;
	};
}

export type BasicAPIResponse = Readonly<BasicAPIResponseInterface>;
export type ErrorAPIResponse = Readonly<ErrorAPIResponseInterface>;
