export interface ApiErrorMessageDetail {
	readonly field: string;
	readonly message: string;
}

export interface ApiErrorMessage {
	readonly code?: string;
	readonly details?: Array<ApiErrorMessageDetail>;
	readonly message: string;
}

export interface ApiErrorResponse {
	readonly code?: string;
	readonly loggingMessage?: string;
	readonly id: string;
	readonly title?: string;
	readonly detail_payer?: string;
	readonly detail?: string;
}
