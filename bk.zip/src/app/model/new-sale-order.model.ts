import {
	Address,
	ContactInfo,
	PaymentCard,
	PaymentRequest,
	PaymentSEPA,
	RequestType,
	TransactionAmount,
	TransactionAmountComponents,
	TransactionType,
	Mcc6012,
	ScheduledPaymentRequest,
	TransactionAmountCurrencyEnum,
} from "bff-client";
import { MandateType } from "../../bff-client/model/mandateType";

export const initAddressValues: Address = {
	address1: "",
	address2: "",
	city: "",
	region: "",
	postalCode: "",
	country: "",
	company: "",
};

export const initContactInfo: ContactInfo = {
	email: "",
	fax: "",
	phone: "",
	mobilePhone: "",
};

export const initTransactionComponents: TransactionAmountComponents = {
	subtotal: 0,
	vatAmount: 0,
	shipping: 0,
};

export const initTransactionAmount: TransactionAmount = {
	total: 0,
	currency: TransactionAmountCurrencyEnum.Aed,
	components: initTransactionComponents,
};

export const initRecurringOrderDetails: ScheduledPaymentRequest = {
	transactionAmount: initTransactionAmount,
	frequency: {
		every: 1,
		unit: "",
	},
	requestType: RequestType.PaymentMethodPaymentSchedulesRequest,
	startDate: "",
	numberOfPayments: 1,
};

export const initOrderDetails: PaymentRequest = {
	transactionAmount: initTransactionAmount,
	transactionType: TransactionType.Sale,
	requestType: RequestType.PaymentCardSaleTransaction,
};

export const initSepaDetails: PaymentSEPA = {
	iban: "",
	name: "",
	mandate: {
		reference: "",
		signatureDate: "",
		type: MandateType.Single,
	},
};

export const initCardDetails: PaymentCard = {
	number: "",
	expiryDate: {
		month: "",
		year: "",
	},
	cardholderName: "",
};

export const initMcc6012: Mcc6012 = {
	dateOfBirth: "",
	accountFirst6: "",
	accountLast4: "",
	postCode: "",
	surname: "",
	accountNum: "",
};

export const SeListCountries = [
	"AD",
	"CH",
	"GB",
	"GI",
	"IS",
	"LI",
	"MC",
	"NO",
	"SM",
	"VA",
];
