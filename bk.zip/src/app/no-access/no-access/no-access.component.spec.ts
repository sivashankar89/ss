import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";

import { NoAccessComponent } from "./no-access.component";
import { TelemetryService } from "services/telemetry.service";

describe("NoAccessComponent", () => {
	let component: NoAccessComponent;
	let fixture: ComponentFixture<NoAccessComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [NoAccessComponent],
			imports: [PipesMockModule, RouterTestingModule],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(NoAccessComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
