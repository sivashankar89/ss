import { Component, OnDestroy, OnInit } from "@angular/core";
import { Location } from "@angular/common";
import { ActivatedRoute, ParamMap } from "@angular/router";
import { map, ReplaySubject, takeUntil } from "rxjs";

@Component({
	selector: "app-no-access",
	template: `
		<cds-alert type="info" icon="info">
			{{ "shared.no_access" | translate }}
		</cds-alert>
	`,
	styles: [
		`
			:host {
				padding: 2em;
			}
		`,
	],
})
export class NoAccessComponent implements OnInit, OnDestroy {
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private activatedRoute: ActivatedRoute,
		private location: Location
	) {}

	ngOnInit(): void {
		this.activatedRoute.queryParamMap
			.pipe(
				map((params: ParamMap) => params.get("url")),
				takeUntil(this.destroyed$)
			)
			.subscribe((replaceUrl) => {
				if (replaceUrl) {
					this.location.replaceState(replaceUrl);
				}
			});
	}

	ngOnDestroy(): void {
		this.destroyed$.next();
		this.destroyed$.complete();
	}
}
