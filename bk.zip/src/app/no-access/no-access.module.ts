import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { NoAccessComponent } from "./no-access/no-access.component";
import { RouterModule, Routes } from "@angular/router";
import { CdsAlertModule } from "@international-payment-platform/design-system-angular";
import { NgxTolgeeModule } from "@tolgee/ngx";

export const routes: Routes = [
	{
		path: "",
		component: NoAccessComponent,
	},
];

@NgModule({
	declarations: [NoAccessComponent],
	imports: [
		CommonModule,
		CdsAlertModule,
		NgxTolgeeModule,
		RouterModule.forChild(routes),
	],
})
export class NoAccessModule {}
