import { Injectable } from "@angular/core";
import {
	AuthenticationInformation,
	AuthenticationInformationResponse,
	UserDetails,
	UserDetailsBffService,
} from "bff-client";
import {
	IAuthConfig,
	AuthWorker,
	IInstanceConfig,
	InstanceConfigService,
	ɵm as RedirectService,
} from "@international-payment-platform/portal-core";

import { SessionStorageService } from "utils/session-storage.service";
import { HttpClient } from "@angular/common/http";
import { LocalStorageService } from "utils/local-storage.service";

@Injectable({ providedIn: "root" })
export class SsoService {
	private worker: AuthWorker | undefined;
	public requiresAuthentication: boolean = false;

	constructor(
		private userDetailsService: UserDetailsBffService,
		private sessionStorageService: SessionStorageService,
		private localStorageService: LocalStorageService,
		private instanceConfigService: InstanceConfigService,
		private redirectService: RedirectService,
		private https: HttpClient
	) {
		this.userDetailsService = userDetailsService;
		this.sessionStorageService = sessionStorageService;
	}

	public logout(): void {
		this.worker?.logout().catch((err) => console.log(err));
		// .then((result) => ); // Add if required
	}

	public init(): Promise<any> {
		this.instanceConfigService.initialize();
		return new Promise((resolve, reject) => {
			this.instanceConfigService.onReady.subscribe({
				next: (instanceConfig: IInstanceConfig) => {
					// TODO maybe hard-code this for prod and move to main.ts
					if (
						typeof instanceConfig.realm !== "string" ||
						instanceConfig.realm.trim().length == 0
					) {
						return this.fallBackToMerchantPortalAuthentication(resolve);
					}
					return this.https
						.get<any>(
							"/ecom/payment/authentication-information/" + instanceConfig.realm
						)
						.subscribe({
							next: (value: AuthenticationInformationResponse) => {
								if (
									value.authenticationRequired &&
									value.authenticationInformation
								) {
									this.requiresAuthentication = true;
									if (
										(typeof instanceConfig.oauthClientId !== "string" ||
											instanceConfig.oauthClientId.trim().length == 0) &&
										(typeof instanceConfig.oauthScope !== "string" ||
											instanceConfig.oauthScope.trim().length == 0)
									) {
										return this.fallBackToMerchantPortalAuthentication(resolve);
									}
									let authWorker = new AuthWorker(
										this.getConfig(
											value.authenticationInformation,
											instanceConfig.oauthClientId,
											instanceConfig.oauthScope
										)
									);
									this.worker = authWorker;
									this.startAuthWorker(authWorker, resolve, reject);
								} else {
									this.requiresAuthentication = false;
									// TODO move to environment.preprod.ts, so permission names are not made public
									let accessibleStoreIdsFromSession: any =
										this.sessionStorageService.accessibleStoreIds.value();
									let accessibleStoreIds;
									if (
										typeof accessibleStoreIdsFromSession === "string" &&
										accessibleStoreIdsFromSession.trim().length > 0
									) {
										accessibleStoreIds = JSON.parse(
											accessibleStoreIdsFromSession
										);
									} else {
										accessibleStoreIds = ["120995000"];
									}
									let ssoPermissionsFromSession: any = sessionStorage.getItem(
										"PORTAL_CORE_SSO_PERMISSIONS"
									);
									let ssoPermissions;
									if (
										typeof ssoPermissionsFromSession === "string" &&
										ssoPermissionsFromSession.trim().length > 0
									) {
										ssoPermissions = JSON.parse(ssoPermissionsFromSession);
									} else {
										ssoPermissions = [
											"EcomVTTransactionSale",
											"EcomVTTransactionSaleNorecurring",
											"EcomVTPaymentLink",
											"EcomVTTransactionPreAuth",
											"EcomVTTransactionCompletion",
											"EcomVTTransactionVoid",
											"EcomVTTransactionRefund",
											"EcomVTTransactionCredit",
											"EcomVTOrderDetailsView",
											"EcomOrderDetailsManageSchedule",
											"EcomVTOrderDetailsActionRefund",
											"EcomVTOrderDetailsActionVoid",
											"EcomVTOrderDetailsActionCompletion",
											"EcomVTCreateCardToken",
											"EcomVTTransactionUseToken",
											"EcomVTNotificationLanguage",
											"EcomStoreMgmtFraudPreventView",
											"EcomStoreMgmtPaypalAction",
											"EcomPaymentPageConfiguratorAction",
											"EcomStoreMgmtFraudPreventView",
											"EcomStoreMgmtFraudPreventAction",
											"EcomStoreMgmtPaypalAction",
											"EcomStoreMgmtFraudProfiles",
										];
									}
									this.addSessionData({
										firstName: "Max",
										lastName: "Mustermann",
										permissions: ssoPermissions,
										accessibleStoreIds: accessibleStoreIds,
										locale: "en",
									});
									this.setSelectedStore();
									resolve(true);
								}
							},
							error: (err) => this.onErrorLogin(err, reject),
						});
				},
				error: (err) => this.onErrorLogin(err, reject),
			});
		});
	}

	public startAuthWorker(
		authWorker: AuthWorker,
		resolve: (value: PromiseLike<unknown> | unknown) => void,
		reject: (reason?: any) => void
	): void {
		AuthWorker.register()
			.then(() =>
				authWorker
					.isUserLoggedIn()
					.then((value) => {
						if (value) {
							this.onSuccess(resolve, reject);
						} else {
							authWorker
								.tryLoginFlow()
								.then((res) => {
									if (res === null) {
										authWorker.initLoginFlow();
										resolve(true);
									} else {
										this.onSuccess(resolve, reject);
									}
								})
								.catch((err) => {
									this.onErrorLogin(err, reject);
								});
						}
					})
					.catch((err) => {
						this.onErrorLogin(err, reject);
					})
			)
			.catch((err) => {
				console.log(err);
				return this.fallBackToMerchantPortalAuthentication(resolve);
			});
	}

	private getConfig(
		value: AuthenticationInformation,
		clientId: string | undefined,
		scope: string | undefined
	): IAuthConfig {
		return {
			/** URL of endpoint to which the user will be redirected if session has not been initiated */
			loginEndpoint: value.loginUrl,

			/** URL of endpoint to which the user will be redirected after calling logout() */
			logoutEndpoint: value.logoutUrl,

			/** URL of endpoint to call for access_token and refresh-token */
			tokenEndpoint: value.tokenUrl,

			/** URL of endpoint to call for access_token and refresh-token */
			refreshTokenEndpoint: value.refreshUrl,

			/** URL of SPA to redirect after login */
			redirectUri: window.location.origin + location.pathname,

			/** SPA's id that was registered on auth server */
			clientId: clientId ? clientId : "UNDEFINED_CLIENT_ID",

			/** Set the scope for the permissions the client should request */
			scope: scope ? scope : "UNDEFINED_SCOPE_ID",

			/** List of API endpoints prefixes, that require Authorization token in a request header */
			allowedUrls: [
				/\/ecom\/store-management\/api\//,
				/\/ecom\/payment\/api\//,
			],
		};
	}

	private onSuccess(
		resolve: (value: PromiseLike<unknown> | unknown) => void,
		reject: (reason?: any) => void
	) {
		this.userDetailsService.getUserDetails().subscribe({
			next: (value: UserDetails) => {
				this.addSessionData(value);
				this.setSelectedStore();
				resolve(true);
			},
			error: (error: any) => {
				this.onErrorLogin(error, reject);
			},
		});
	}

	// TODO refactor session storage - move information to angular services instead
	private addSessionData(userDetails: UserDetails) {
		const loggedUser: object = {
			// status: null,
			firstName: userDetails?.firstName,
			lastName: userDetails?.lastName,
			allianceCode: "FDMS", // TODO
			userName: "ecom-testuser-1", // TODO
			emailId: "joh***********@fiserv.com", // TODO
			mobileNumber: "*********572",
			phoneNumber: "",
			languageCode: "EN", // TODO
			sendNewsletter: 0,
			sendEmailNotification: 0,
			sendEInvoicePermission: 1,
			invoiceEmailFlag: 0,
			tradeName: "FDMS POGO Test 1",
			invoiceNotifFlag: 1,
			lastLoginDate: 1639488358000,
			nextPassChangeNotifDate: 1644239834000,
			preAuthWidgetFlag: 0,
			userType: "MERCHANT",
			tourFlag: 1,
			boUserManagementFlag: 1,
			pinChangedFlag: 0,
			viewPayUrlFlag: 0,
			createPayUrlFlag: 0,
			defaultCurrency: "826",
			subAccountFlag: 0,
			merchantId: 418824938, // TODO
			emailAddress: "joh***********@fiserv.com", // TODO
			profiles: ["BUSINESSOWNER"],
			languagePreference: "EN", // TODO
			beneficiaryFlag: null,
			sendEinvoice: null,
			merchantIds: [418824938],
			extmerchantIds: null,
			sourceFlag: null,
			accountExpirationDate: null,
			passwordExpirationDate: 1645100643000,
			partnerCode: null,
			acceptedTC: 1805559,
			latestTC: 1805559,
			demoFlag: 0,
			sessionExpTime: 15,
			permissions: [
				// needed on authenticationService.getPermissions()
				// "FAAView",
				"DAWidget",
				"ACCESSPORTAL",
				"FDLTUSR",
				"ROLE_DASHBOARD_WIDGET_PREAUTH",
				"ROLE_USER_MNG_USER_DETAILS",
				"DEFINVOICEACCESSFLAG",
				"GENERICX",
				"BOFLAG",
				// "MHDATA",
				"MHDATAPOS",
				"ROLE_DASHBOARD_WIDGET_PAYMENT_TYPE",
				"ROLE_MARKETING_BANNER",
				"ROLE_HELP",
				"ROLE_CONTACT",
				"ROLE_TRANSACTIONS_REFUND_DETAILS",
				"ROLE_TERMS_AND_CONDITIONS",
				// "ROLE_USER_MNG_LIST_VIEW",
				// "FAPREAUTHLIST",
				// "VATINVOICEACCESS",
				"DFWidget",
				"DSWidget",
				"ROLE_DASHBOARD_WIDGET_FUNDING",
				"FAPREAUTHHIST",
				"FBLKUSR",
				"SUBACCDET",
				// "MHDATATER",
				"FCREUSER",
				"TANDC",
				"ROLE_USR_MNG_CHANGE_SETTINGS_OPTIONS",
				"FAPREAUTHEX",
				"FAEXF",
				"DPWidget",
				"DYNMWIDGET",
				"CRTUSRID",
				"ROLE_COOKIE",
				"ROLE_USER_MNG_EDIT",
				"ROLE_SETTINGS",
				// "DOCUMENTACCESS",
				// 'MESSAGEACCESS',
				"ROLE_USER_MNG_CREATE",
				"ROLE_USER_MNG_FILTER_AND_COLUMNS",
				"FAPREAUTHSUM",
				"FAEXT",
				// "FAFView",
				"FAREFUND",
				"ROLE_DASHBOARD_WIDGET_SALES",
				"ROLE_PASSWORD_CHANGE",
				"ROLE_ADDITIONAL_LINKS",
				"FAEXA",
				// "FATView",
				"ROLE_USER_MNG_DELETE",
				// "ROLE_DASHBOARD_MENU_ITEM",
			],
			expirePasswordFlag: 0,
			markedToExpire: 0,
			pinToChange: 0,
			userViewPermissions: {
				hasUserManagement: true,
				hasInvoiceView: true,
			},
			accountStatus: "ACTIVE",
			authorities: [
				{
					authority: "1000063",
				},
			],
			partnerIndicator: "0",
		};
		if (!sessionStorage.getItem("LOGGED_USER")) {
			sessionStorage.setItem("LOGGED_USER", JSON.stringify(loggedUser));
		}
		if (!sessionStorage.getItem("LOGGED_USER_DETAILS")) {
			sessionStorage.setItem("LOGGED_USER_DETAILS", JSON.stringify(loggedUser));
		}
		if (userDetails) {
			sessionStorage.setItem(
				"PORTAL_CORE_SSO_PERMISSIONS",
				JSON.stringify(userDetails.permissions)
			);
			this.sessionStorageService.accessibleStoreIds.set(
				userDetails.accessibleStoreIds ?? []
			);
		}
		if (!localStorage.getItem("PREFERRED_LANGUAGE")) {
			localStorage.setItem(
				"PREFERRED_LANGUAGE",
				userDetails?.locale ? userDetails.locale : window.navigator.language
			);
		}
		this.localStorageService.selectedLanguage.set(
			localStorage.getItem("PREFERRED_LANGUAGE") || window.navigator.language
		);
	}

	private onErrorLogin(err: any, reject: (reason?: any) => void): void {
		console.log(err);
		reject(false);
	}

	public serviceWorkerAddsHeaders(): boolean {
		return this.worker !== undefined;
	}

	private fallBackToMerchantPortalAuthentication(
		resolve: (value: any) => void
	): void {
		localStorage.setItem("DISABLE_LOGIN_REDIRECT", "0");
		this.redirectService.redirectToMonolithLogin();
		this.setSelectedStore();
		resolve(true);
	}

	private setSelectedStore() {
		let selectedStoreIdFromSession: any =
			this.sessionStorageService.selectedStoreID.value();
		let accessibleStoreIds =
			this.sessionStorageService.accessibleStoreIds.value();
		let selectedStoreId;
		if (Array.isArray(accessibleStoreIds)) {
			if (
				selectedStoreIdFromSession &&
				typeof selectedStoreIdFromSession === "string" &&
				selectedStoreIdFromSession.trim().length > 0 &&
				accessibleStoreIds.indexOf(selectedStoreIdFromSession) !== -1
			) {
				selectedStoreId = JSON.parse(selectedStoreIdFromSession);
			} else {
				selectedStoreId = accessibleStoreIds[0];
			}
		} else {
			selectedStoreId = null;
		}
		this.sessionStorageService.selectedStoreID.set(selectedStoreId);
	}
}
