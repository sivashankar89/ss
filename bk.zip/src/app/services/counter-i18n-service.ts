import { Injectable } from "@angular/core";
import { CdsCounterI18nService } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";

@Injectable()
export class CounterI18nService extends CdsCounterI18nService {
	constructor(private translate: TranslateService) {
		super();
	}

	getMinErrorMessage(value: number): string {
		return this.translate.instantSafe("shared.min_n_number", { n: value });
	}

	getMaxErrorMessage(value: number): string {
		return this.translate.instantSafe("shared.max_n_number", { n: value });
	}
}
