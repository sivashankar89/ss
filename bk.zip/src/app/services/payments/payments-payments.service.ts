import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import {
	PaymentBffService,
	RequestType,
	PaymentResponse,
	PaymentRequest,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";

@Injectable({
	providedIn: "root",
})
export class PaymentsPaymentsService {
	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService
	) {}

	/**
	 * Use this to originate a financial transaction like a sale, preauthorization, or credit.
	 */
	generatePrimaryTransaction(): void {
		throw new Error("Method not implemented.");
	}

	/**
	 * Use this query to get the current state of an existing transaction.
	 */
	retrieveTransactionState(): void {
		throw new Error("Method not implemented.");
	}

	/**
	 * Use this to handle a 3DSecure redirect response authentication, updating the transaction and continuing processing.
	 */
	update3DSecurePayment(): void {
		throw new Error("Method not implemented.");
	}

	/**
	 * Use this to perform a void, postAuth or return secondary transaction. Partial postAuths and returns are allowed.
	 */
	performSecondaryTransaction(
		ipgTransactionId: string,
		requestType: RequestType
	): Observable<PaymentResponse> {
		if (typeof ipgTransactionId !== "string" || !ipgTransactionId) {
			return throwError(
				() => new Error(`'transactionId' needs to be a string`)
			);
		}

		if (!requestType || !Object.values(RequestType).includes(requestType)) {
			const errMsg = `Secondary transaction request type '${requestType}' is not supported.`;
			return throwError(() => new Error(errMsg));
		}

		const paymentRequest: PaymentRequest = { requestType };

		return this.paymentBff.doSecondaryTransaction({
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
			ipgTransactionId: ipgTransactionId,
			paymentRequestV2: paymentRequest,
		});
	}
}
