import {
	HttpTestingController,
	HttpClientTestingModule,
} from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { BASE_PATH, RequestType } from "bff-client";
import { PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE } from "../../../mocks/payment_api/transactions.mock";
import { PaymentsPaymentsService } from "./payments-payments.service";
import { environment } from "environments/environment";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("PaymentsPaymentsService", () => {
	let httpTestingController: HttpTestingController;
	let service: PaymentsPaymentsService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				PaymentsPaymentsService,
				{ provide: BASE_PATH, useValue: environment.bffApiURl },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});

		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(PaymentsPaymentsService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	describe("performSecondaryTransaction", () => {
		it("should succeed", (done) => {
			service
				.performSecondaryTransaction("1", RequestType.VoidTransaction)
				.subscribe((response) => {
					expect(response).toEqual(PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE);
					done();
				});

			httpTestingController
				.expectOne(environment.bffApiURl + "/payments/1")
				.flush(PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE);
		});

		it("should failed - wrong transaction id", (done) => {
			service
				.performSecondaryTransaction(1 as any, RequestType.VoidTransaction)
				.subscribe({
					error: (error) => {
						expect(error).toBeDefined();
						done();
					},
				});
		});

		it("should failed - wrong transaction type", (done) => {
			service
				.performSecondaryTransaction("1", "SALE" as RequestType)
				.subscribe({
					error: (error) => {
						expect(error).toBeDefined();
						done();
					},
				});
		});

		it("should failed - response error", (done) => {
			service
				.performSecondaryTransaction("1", RequestType.VoidTransaction)
				.subscribe({
					error: (error) => {
						expect(error).toBeDefined();
						done();
					},
				});

			httpTestingController
				.expectOne(environment.bffApiURl + "/payments/1")
				.error(new ErrorEvent("network error"));
		});
	});
});
