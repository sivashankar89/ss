import {
	HttpTestingController,
	HttpClientTestingModule,
} from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import {
	BASE_PATH,
	RequestType,
	TransactionAmountCurrencyEnum,
} from "bff-client";
import { environment } from "environments/environment";
import { PAYMENTS_ORDER_DETAILS_MOCK_RESPONSE } from "../../../mocks/payment_api/order-details.mock";
import { ORDER_DETAILS_AND_TRANSACTIONS_MOCK_RESPONE } from "../../../mocks/refund/transaction.mock";
import { PaymentsOrdersService } from "./payments-orders.service";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("PaymentsOrdersService", () => {
	let httpTestingController: HttpTestingController;
	let service: PaymentsOrdersService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				PaymentsOrdersService,
				{ provide: BASE_PATH, useValue: environment.bffApiURl },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});

		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(PaymentsOrdersService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	describe("getOrder", () => {
		it("should return order details for a given `orderId`", (done) => {
			service.getOrder("1").subscribe((response) => {
				expect(response).toEqual(PAYMENTS_ORDER_DETAILS_MOCK_RESPONSE);
				done();
			});

			httpTestingController
				.expectOne(environment.bffApiURl + "/orders/1")
				.flush(PAYMENTS_ORDER_DETAILS_MOCK_RESPONSE);
		});

		it("should return an error when `orderId` is not provided or is not a string", (done) => {
			service.getOrder(1 as any).subscribe({
				error: (error) => {
					expect(error).toBeDefined();
					done();
				},
			});
		});

		it("should return an error from API", (done) => {
			service.getOrder("1").subscribe({
				error: (error) => {
					expect(error).toBeDefined();
					done();
				},
			});

			httpTestingController
				.expectOne(environment.bffApiURl + "/orders/1")
				.error(new ErrorEvent("network error"));
		});
	});

	describe("postReturnOrPostAuthSecondaryTransaction", () => {
		it("should succeed", (done) => {
			service
				.postReturnOrPostAuthSecondaryTransaction(
					"1",
					RequestType.ReturnTransaction,
					{
						transactionAmount: {
							total: 100,
							currency: TransactionAmountCurrencyEnum.Eur,
						},
					}
				)
				.subscribe((response) => {
					expect(response).toEqual(ORDER_DETAILS_AND_TRANSACTIONS_MOCK_RESPONE);
					done();
				});

			httpTestingController
				.expectOne(environment.bffApiURl + "/orders/1")
				.flush(ORDER_DETAILS_AND_TRANSACTIONS_MOCK_RESPONE);
		});

		it("should failed - wrong order id", (done) => {
			service
				.postReturnOrPostAuthSecondaryTransaction(
					1 as any,
					RequestType.ReturnTransaction,
					{
						transactionAmount: {
							total: 100,
							currency: TransactionAmountCurrencyEnum.Eur,
						},
					}
				)
				.subscribe({
					error: (error) => {
						expect(error).toBeDefined();
						done();
					},
				});
		});

		it("should failed - wrong transaction type", (done) => {
			service
				.postReturnOrPostAuthSecondaryTransaction("1", "SALE" as RequestType, {
					transactionAmount: {
						total: 100,
						currency: TransactionAmountCurrencyEnum.Eur,
					},
				})
				.subscribe({
					error: (error) => {
						expect(error).toBeDefined();
						done();
					},
				});
		});

		it("should failed - response error", (done) => {
			service
				.postReturnOrPostAuthSecondaryTransaction(
					"1",
					RequestType.ReturnTransaction,
					{
						transactionAmount: {
							total: 100,
							currency: TransactionAmountCurrencyEnum.Eur,
						},
					}
				)
				.subscribe({
					error: (error) => {
						expect(error).toBeDefined();
						done();
					},
				});

			httpTestingController
				.expectOne(environment.bffApiURl + "/orders/1")
				.error(new ErrorEvent("network error"));
		});
	});
});
