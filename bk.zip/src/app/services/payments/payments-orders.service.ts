import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import {
	OrderDetailsResponse,
	PaymentBffService,
	RequestType,
	PaymentResponse,
	TransactionAmountCurrencyEnum,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";

@Injectable({
	providedIn: "root",
})
export class PaymentsOrdersService {
	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService
	) {}

	/**
	 * Use this query to get the current state of an existing order
	 */
	getOrder(orderId: string): Observable<OrderDetailsResponse> {
		if (typeof orderId !== "string" || !orderId) {
			return throwError(() => new Error(`'orderId' needs to be a string`));
		}
		return this.paymentBff.getOrderDetails({
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
			orderId: orderId,
		});
	}

	/**
	 * Use this to perform a postAuth or return secondary transaction using order ID. Partial postAuths and returns are allowed.
	 */
	postReturnOrPostAuthSecondaryTransaction(
		orderId: string | undefined,
		requestType: RequestType,
		payload?: {
			transactionAmount: {
				total: number;
				currency: TransactionAmountCurrencyEnum;
			};
		}
	): Observable<PaymentResponse> {
		if (typeof orderId !== "string" || !orderId) {
			return throwError(() => new Error(`'orderId' needs to be a string`));
		}

		if (!requestType || !Object.values(RequestType).includes(requestType)) {
			const errMsg = `Secondary transaction request type '${requestType}' is not supported.`;
			return throwError(() => new Error(errMsg));
		}
		return this.paymentBff.doSecondaryTransactionWithOrderId({
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
			orderId: orderId,
			secondaryTransactionRequest: {
				requestType,
				transactionAmount: payload?.transactionAmount,
			},
		});
	}
}
