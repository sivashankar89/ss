import { Injectable } from "@angular/core";
import {
	Country,
	PaymentBffService,
	GetAvailableCountriesRequestParams,
} from "bff-client";
import {
	map,
	Observable,
	of,
	share,
	shareReplay,
	switchMap,
	throwError,
} from "rxjs";
import { SessionStorageService } from "utils/session-storage.service";

@Injectable({
	providedIn: "root",
})
export class CountriesService {
	private countries$!: Observable<Country[]> | undefined;
	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService
	) {}

	public getCountry(countryCode?: string): Observable<Country> {
		return this.getCountries().pipe(
			switchMap((countries) => {
				const countrySettings = countries.find((country) =>
					countryCode
						? country.iso31661Alpha3 === countryCode
						: country.defaultCountry
				);

				if (typeof countrySettings === "undefined") {
					return throwError(
						() =>
							new Error(`Settings for country ${countryCode} is not present`)
					);
				}

				return of(countrySettings);
			})
		);
	}

	public getDefaultCountry(): Observable<Country | undefined> {
		return this.getCountries().pipe(
			map((countries: Country[]) =>
				countries.find((c) => c.defaultCountry === true)
			)
		);
	}

	public getCountries(): Observable<Country[]> {
		if (!this.countries$) {
			this.countries$ = this.fetchCountries().pipe(
				shareReplay({ bufferSize: 1, refCount: true })
			);
		}

		return this.countries$;
	}

	private fetchCountries(): Observable<Country[]> {
		const param: GetAvailableCountriesRequestParams = {
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
		};
		return this.paymentBff.getAvailableCountries(param).pipe(
			share(),
			map((res) => (res.countries ? res.countries : []))
		);
	}

	resetCountry(): void {
		this.countries$ = undefined;
	}
}
