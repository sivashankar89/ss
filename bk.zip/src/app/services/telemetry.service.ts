import { Inject, Injectable, Optional } from "@angular/core";
import { ZoneContextManager } from "@opentelemetry/context-zone-peer-dep";
import {
	Attributes,
	context,
	diag,
	DiagLogger,
	Sampler,
	Span,
	trace,
	Tracer,
} from "@opentelemetry/api";
import {
	AlwaysOffSampler,
	AlwaysOnSampler,
	ParentBasedSampler,
	TraceIdRatioBasedSampler,
} from "@opentelemetry/core";
import { Resource } from "@opentelemetry/resources";
import { WebTracerProvider } from "@opentelemetry/sdk-trace-web";
import * as api from "@opentelemetry/api";
import { HttpRequest } from "@angular/common/http";
import { PlatformLocation } from "@angular/common";
import {
	BatchSpanProcessor,
	ConsoleSpanExporter,
	NoopSpanProcessor,
	SimpleSpanProcessor,
} from "@opentelemetry/sdk-trace-base";
import {
	SemanticResourceAttributes,
	SemanticAttributes,
} from "@opentelemetry/semantic-conventions";
import {
	IExporter,
	IPropagator,
	OpenTelemetryConfig,
	OTEL_CONFIG,
	OTEL_EXPORTER,
	OTEL_LOGGER,
	OTEL_PROPAGATOR,
} from "@jufab/opentelemetry-angular-interceptor";
import { registerInstrumentations } from "@opentelemetry/instrumentation";
import {
	AuthenticationService,
	InstanceConfigService,
} from "@international-payment-platform/portal-core";
import { UserInteractionInstrumentation } from "@opentelemetry/instrumentation-user-interaction";

/**
 * TelemetryService.
 */
@Injectable({
	providedIn: "root",
})
export class TelemetryService {
	/**
	 * tracerProvider
	 */
	private readonly tracerProvider: WebTracerProvider;

	/**
	 * contextManager
	 */
	public contextManager = new ZoneContextManager();

	/**
	 * Constructor
	 *
	 * @param exporterService
	 * @param propagatorService
	 * @param logger
	 * @param platformLocation
	 * @param config
	 * @param authenticationService
	 * @param instanceConfigService
	 */
	constructor(
		@Inject(OTEL_EXPORTER)
		private exporterService: IExporter,
		@Inject(OTEL_PROPAGATOR)
		private propagatorService: IPropagator,
		@Inject(OTEL_LOGGER)
		private logger: DiagLogger,
		@Inject(OTEL_CONFIG)
		private config: OpenTelemetryConfig,
		private platformLocation: PlatformLocation,
		private authenticationService: AuthenticationService,
		private instanceConfigService: InstanceConfigService
	) {
		this.tracerProvider = new WebTracerProvider({
			sampler: TelemetryService.defineProbabilitySampler(
				TelemetryService.convertStringToNumber(
					this.config.commonConfig.probabilitySampler
				)
			),
			resource: Resource.default().merge(
				new Resource({
					[SemanticResourceAttributes.SERVICE_NAME]:
						config.commonConfig.serviceName,
				})
			),
		});
		if (logger && config.commonConfig.console) {
			diag.setLogger(logger, config.commonConfig.logLevel);
		}
		this.init();
	}

	/**
	 * Init instrumentation on init
	 */
	public init() {
		this.insertOrNotSpanExporter();
		this.contextManager.active();
		this.tracerProvider.register({
			contextManager: this.contextManager,
			propagator: this.propagatorService?.getPropagator(),
		});

		registerInstrumentations({
			instrumentations: [
				new UserInteractionInstrumentation({
					shouldPreventSpanCreation: (
						eventType,
						element: HTMLElement,
						span: Span
					) => {
						span.setAttributes(this.buildAttributes());
						return false;
					},
				}),
			],
			tracerProvider: this.tracerProvider,
		});
	}

	private getTracer(): Tracer {
		return this.tracerProvider.getTracer("ecom-tracer");
	}

	public getSpan(): Span | undefined {
		return trace
			.getSpan(context.active())
			?.setAttributes(this.buildAttributes());
	}

	public withSpanName<F extends (span: Span) => unknown>(
		name: string,
		fn: F
	): ReturnType<F> {
		return this.getTracer().startActiveSpan(
			name,
			{ attributes: this.buildAttributes() },
			fn
		);
	}

	public withSpanRequest<F extends (span: Span) => unknown>(
		request: HttpRequest<unknown>,
		fn: F
	): ReturnType<F> {
		const attributes = this.buildAttributes();
		const urlRequest = request.urlWithParams.startsWith("http")
			? new URL(request.urlWithParams)
			: new URL(this.getURL());
		attributes[SemanticAttributes.HTTP_METHOD] = request.method;
		attributes[SemanticAttributes.HTTP_URL] = request.urlWithParams;
		attributes[SemanticAttributes.HTTP_HOST] = urlRequest.host;
		attributes[SemanticAttributes.HTTP_SCHEME] = urlRequest.protocol.replace(
			":",
			""
		);
		attributes[SemanticAttributes.HTTP_TARGET] =
			urlRequest.pathname + urlRequest.search;
		attributes[SemanticAttributes.HTTP_USER_AGENT] = window.navigator.userAgent;
		return this.getTracer().startActiveSpan(
			`${urlRequest.protocol
				.replace(":", "")
				.toUpperCase()} ${request.method.toUpperCase()}`,
			{
				attributes: attributes,
				kind: api.SpanKind.CLIENT,
			},
			fn
		);
	}

	private buildAttributes(): Attributes {
		let allianceCode =
			this.instanceConfigService.configValueGetter("allianceCode");
		let merchantId = this.authenticationService
			.getUserDetails()
			?.merchantId?.toString();
		let clientId = this.authenticationService.getClientId();
		return {
			["ecom.mp.alliance.id"]: allianceCode,
			["ecom.mp.merchant.id"]: merchantId,
			["ecom.mp.clientId.id"]: clientId,
		};
	}

	private getURL() {
		return this.platformLocation.href;
	}

	/**
	 * Verify to insert or not a Span Exporter
	 */
	private insertOrNotSpanExporter() {
		if (this.exporterService.getExporter() !== undefined) {
			this.insertSpanProcessorProductionMode();
			this.insertConsoleSpanExporter();
		} else {
			this.tracerProvider.addSpanProcessor(new NoopSpanProcessor());
		}
	}

	/**
	 * Insert BatchSpanProcessor in production mode
	 * SimpleSpanProcessor otherwise
	 */
	private insertSpanProcessorProductionMode() {
		this.tracerProvider.addSpanProcessor(
			this.config?.commonConfig.production
				? new BatchSpanProcessor(this.exporterService.getExporter(), {
						maxExportBatchSize: TelemetryService.convertStringToNumber(
							this.config?.batchSpanProcessorConfig?.maxExportBatchSize
						),
						scheduledDelayMillis: TelemetryService.convertStringToNumber(
							this.config?.batchSpanProcessorConfig?.scheduledDelayMillis
						),
						exportTimeoutMillis: TelemetryService.convertStringToNumber(
							this.config?.batchSpanProcessorConfig?.exportTimeoutMillis
						),
						maxQueueSize: TelemetryService.convertStringToNumber(
							this.config?.batchSpanProcessorConfig?.maxQueueSize
						),
				  })
				: new SimpleSpanProcessor(this.exporterService.getExporter())
		);
	}

	/**
	 * Insert in tracer the console span if config is true   *
	 */
	private insertConsoleSpanExporter() {
		if (this.config?.commonConfig.console) {
			this.tracerProvider.addSpanProcessor(
				new SimpleSpanProcessor(new ConsoleSpanExporter())
			);
		}
	}

	/**
	 * convert String to Number (or undefined)
	 *
	 * @param value
	 * @returns number or undefined
	 */
	private static convertStringToNumber(value: string | undefined): number {
		// @ts-ignore
		return value !== undefined ? Number(value) : undefined;
	}

	/**
	 * define the Probability Sampler
	 * By Default, it's always (or 1)
	 *
	 * @param sampleConfig the sample configuration
	 */
	private static defineProbabilitySampler(sampleConfig: number): Sampler {
		if (sampleConfig >= 1) {
			return new ParentBasedSampler({ root: new AlwaysOnSampler() });
		} else if (sampleConfig <= 0 || sampleConfig === undefined) {
			return new ParentBasedSampler({ root: new AlwaysOffSampler() });
		} else {
			return new ParentBasedSampler({
				root: new TraceIdRatioBasedSampler(sampleConfig),
			});
		}
	}
}
