import { Injectable } from "@angular/core";
import { TranslateService } from "@tolgee/ngx";

@Injectable({
	providedIn: "root",
})
export class RecurringOrderService {
	constructor(private translateService: TranslateService) {}

	public getRecurringOptionLists() {
		return [
			{
				name: this.translateService.instantSafe("new_sale.days"),
				value: "DAY",
			},
			{
				name: this.translateService.instantSafe("new_sale.weeks"),
				value: "WEEK",
			},
			{
				name: this.translateService.instantSafe("new_sale.months"),
				value: "MONTH",
			},
			{
				name: this.translateService.instantSafe("new_sale.years"),
				value: "YEAR",
			},
		];
	}

	public getDelayOptionList() {
		return [
			{
				name: this.translateService.instantSafe("new_sale.never"),
				value: "Never",
			},
			{
				name: this.translateService.instantSafe(
					"new_sale.after_number_of_payments"
				),
				value: "afterDelay",
			},
		];
	}
}
