import { TestBed } from "@angular/core/testing";
import { PaymentsPaymentsService } from "services/payments/payments-payments.service";

import { VoidTransactionService } from "./void-transaction.service";

describe("VoidTransactionService", () => {
	let service: VoidTransactionService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [{ provide: PaymentsPaymentsService, useValue: {} }],
		});
		service = TestBed.inject(VoidTransactionService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});
});
