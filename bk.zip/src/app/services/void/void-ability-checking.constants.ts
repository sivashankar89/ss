import {
	TransactionInfo,
	TransactionState,
	PaymentResponse,
	TransactionType,
	PaymentMethodType,
	ReportingPaymentType,
} from "bff-client";

export const VOIDABLE_TRANSACTION_TYPES: TransactionType[] = [
	TransactionType.Sale,
	TransactionType.Preauth,
	TransactionType.Credit,
	TransactionType.Return,
	TransactionType.Postauth,
];

export const VOIDABLE_PAYMENT_TYPES: ReportingPaymentType[] = [
	ReportingPaymentType.Creditcard,
	ReportingPaymentType.Sepa,
	ReportingPaymentType.Debitde, // SEPA
];

export const VOIDABLE_PAYMENT_METHODS: PaymentMethodType[] = [
	PaymentMethodType.PaymentCard,
	PaymentMethodType.Sepa,
	PaymentMethodType.Debitde, // SEPA
];

export const NOT_VOIDABLE_TRANSACTION_STATES: TransactionState[] = [
	TransactionState.Settled,
	TransactionState.Voided,
	TransactionState.Declined,
];

export const TRANSACTION_HAS_PAYMENT_TYPE = (
	transaction: unknown
): transaction is TransactionInfo => {
	return (
		!!transaction &&
		typeof transaction === "object" &&
		"paymentType" in (transaction as TransactionInfo)
	);
};

export const TRANSACTION_HAS_PAYMENT_DETAILS = (
	transaction: unknown
): transaction is PaymentResponse => {
	return (
		!!transaction &&
		typeof transaction === "object" &&
		"paymentMethodDetails" in (transaction as PaymentResponse)
	);
};

export const GET_SORTED_TRANSACTIONS_FOR_VOID = (
	transactions?: Array<PaymentResponse | TransactionInfo>
): Array<PaymentResponse | TransactionInfo> => {
	const list = [...(transactions || [])].filter((transaction) => {
		return (
			!!transaction &&
			// used later on for sort
			typeof transaction.transactionTime === "number"
		);
	});

	list.sort((a, b) => {
		if (
			typeof a.transactionTime !== "number" ||
			typeof b.transactionTime !== "number"
		) {
			return 0;
		}

		return b.transactionTime - a.transactionTime;
	});

	return list;
};
