import { TestBed } from "@angular/core/testing";
import { AuthenticationService } from "@international-payment-platform/portal-core";
import {
	PaymentMethodType,
	ReportingPaymentType,
	TransactionState,
	TransactionType,
} from "bff-client";
import { AuthenticationServiceStub } from "mocks/services/services.mock";
import { VoidAbilityCheckingService } from "./void-ability-checking.service";

describe("VoidAbilityCheckingService", () => {
	let service: VoidAbilityCheckingService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [],
			providers: [
				VoidAbilityCheckingService,
				{ provide: AuthenticationService, useValue: AuthenticationServiceStub },
			],
		});

		service = TestBed.inject(VoidAbilityCheckingService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	describe("getTransactionsWithVoidAbilityInfo", () => {
		it("should handle incorrect call arguments", () => {
			expect(service.getTransactionsWithVoidAbilityInfo(null as any)).toEqual(
				[]
			);
		});

		it("should sort transactions", () => {
			const transactionA = {
				orderId: "test-order",
				ipgTransactionId: "test-a",
				transactionTime: 10,
			};
			const transactionB = {
				orderId: "test-order",
				ipgTransactionId: "test-b",
				transactionTime: 10,
			};
			const transactionC = {
				orderId: "test-order",
				ipgTransactionId: "test-c",
				transactionTime: 5,
			};
			const transactionD = {
				orderId: "test-order",
				ipgTransactionId: "test-d",
				transactionTime: 20,
			};

			expect(
				service.getTransactionsWithVoidAbilityInfo([
					transactionA,
					transactionB,
					transactionC,
					transactionD,
				])
			).toEqual([
				{
					canBeVoided: false,
					enabledToBeVoided: false,
					transaction: transactionD,
				},
				{
					canBeVoided: false,
					enabledToBeVoided: false,
					transaction: transactionA,
				},
				{
					canBeVoided: false,
					enabledToBeVoided: false,
					transaction: transactionB,
				},
				{
					canBeVoided: false,
					enabledToBeVoided: false,
					transaction: transactionC,
				},
			]);
		});

		describe("test enabled transaction", () => {
			it(`should enable transaction if it's only one`, () => {
				const transaction = {
					transactionTime: 0,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType: TransactionType.Sale,
				};

				expect(
					service.getTransactionsWithVoidAbilityInfo([transaction])
				).toEqual([
					{
						canBeVoided: true,
						enabledToBeVoided: true,
						transaction,
					},
				]);
			});

			it(`should enable transaction if it's a first one`, () => {
				const transactionA = {
					transactionTime: 0,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType: TransactionType.Sale,
				};
				const transactionB = {
					transactionTime: 10,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType: TransactionType.Sale,
				};

				expect(
					service.getTransactionsWithVoidAbilityInfo([
						transactionA,
						transactionB,
					])
				).toEqual([
					{
						canBeVoided: true,
						enabledToBeVoided: true,
						transaction: transactionB,
					},
					{
						canBeVoided: true,
						enabledToBeVoided: false,
						transaction: transactionA,
					},
				]);
			});

			it(`should enable multiple RETURN transactions`, () => {
				const transactionA = {
					transactionTime: 20,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType: TransactionType.Return,
				};
				const transactionB = {
					transactionTime: 30,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType: TransactionType.Return,
				};
				const transactionC = {
					transactionTime: 10,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType: TransactionType.Sale,
				};

				expect(
					service.getTransactionsWithVoidAbilityInfo([
						transactionA,
						transactionB,
						transactionC,
					])
				).toEqual([
					{
						canBeVoided: true,
						enabledToBeVoided: true,
						transaction: transactionB,
					},
					{
						canBeVoided: true,
						enabledToBeVoided: true,
						transaction: transactionA,
					},
					{
						canBeVoided: true,
						enabledToBeVoided: false,
						transaction: transactionC,
					},
				]);
			});
		});

		describe("test transaction type", () => {
			it("should handle voidable types", () => {
				const types = [
					TransactionType.Sale,
					TransactionType.Preauth,
					TransactionType.Credit,
					TransactionType.Return,
					TransactionType.Postauth,
				];

				const voidableTransaction = types.map((transactionType) => ({
					transactionTime: 0,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType,
				}));

				const transactionsWithVoidInfo =
					service.getTransactionsWithVoidAbilityInfo(voidableTransaction);

				expect(transactionsWithVoidInfo.length).toBe(
					voidableTransaction.length
				);
				transactionsWithVoidInfo.forEach((transaction) => {
					expect(transaction.canBeVoided).toBeTruthy();
				});
			});

			it("should handle not voidable types", () => {
				const types = [
					TransactionType.ForcedTicket,
					TransactionType.Void,
					TransactionType.PayerAuth,
					TransactionType.Disbursement,
				];

				const voidableTransaction = types.map((transactionType) => ({
					transactionTime: 0,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType,
				}));

				const transactionsWithVoidInfo =
					service.getTransactionsWithVoidAbilityInfo(voidableTransaction);

				expect(transactionsWithVoidInfo.length).toBe(
					voidableTransaction.length
				);
				transactionsWithVoidInfo.forEach((transaction) => {
					expect(transaction.canBeVoided).toBeFalsy();
				});
			});
		});

		describe("test transaction payment type and payment method", () => {
			it("should handle voidable payment types", () => {
				const paymentTypes = [
					ReportingPaymentType.Creditcard,
					ReportingPaymentType.Sepa,
					ReportingPaymentType.Debitde,
				];

				const voidableTransaction = paymentTypes.map((paymentType) => ({
					transactionTime: 0,
					ipgTransactionId: `${Math.random()}`,
					transactionType: TransactionType.Sale,
					paymentType,
				}));

				const transactionsWithVoidInfo =
					service.getTransactionsWithVoidAbilityInfo(voidableTransaction);

				expect(transactionsWithVoidInfo.length).toBe(
					voidableTransaction.length
				);
				transactionsWithVoidInfo.forEach((transaction) => {
					expect(transaction.canBeVoided).toBeTruthy();
				});
			});

			it("should handle not voidable payment types", () => {
				const paymentTypes = [ReportingPaymentType.Paymentlink];

				const voidableTransaction = paymentTypes.map((paymentType) => ({
					transactionTime: 0,
					ipgTransactionId: `${Math.random()}`,
					transactionType: TransactionType.Sale,
					paymentType,
				}));

				const transactionsWithVoidInfo =
					service.getTransactionsWithVoidAbilityInfo(voidableTransaction);

				expect(transactionsWithVoidInfo.length).toBe(
					voidableTransaction.length
				);
				transactionsWithVoidInfo.forEach((transaction) => {
					expect(transaction.canBeVoided).toBeFalsy();
				});
			});

			it("should handle voidable payment methods", () => {
				const paymentMethodTypes = [
					PaymentMethodType.PaymentCard,
					PaymentMethodType.Sepa,
					PaymentMethodType.Debitde,
				];

				const voidableTransaction = paymentMethodTypes.map(
					(paymentMethodType) => ({
						transactionTime: 0,
						ipgTransactionId: `${Math.random()}`,
						transactionType: TransactionType.Sale,
						paymentMethodDetails: {
							paymentMethodType,
						},
					})
				);

				const transactionsWithVoidInfo =
					service.getTransactionsWithVoidAbilityInfo(voidableTransaction);

				expect(transactionsWithVoidInfo.length).toBe(
					voidableTransaction.length
				);
				transactionsWithVoidInfo.forEach((transaction) => {
					expect(transaction.canBeVoided).toBeTruthy();
				});
			});

			it("should handle not voidable payment methods", () => {
				const paymentMethodTypes = [
					PaymentMethodType.Alipay,
					PaymentMethodType.AlipayPaysecureUs,
					PaymentMethodType.AlipayDomestic,
					PaymentMethodType.Apm,
					PaymentMethodType.CupDomestic,
					PaymentMethodType.Emi,
					PaymentMethodType.Giropay,
					PaymentMethodType.Ideal,
					PaymentMethodType.Indiawallet,
					PaymentMethodType.Klarna,
					PaymentMethodType.Kps,
					PaymentMethodType.Netbanking,
					PaymentMethodType.PaymentToken,
					PaymentMethodType.Paypal,
					PaymentMethodType.Sofort,
					PaymentMethodType.Wallet,
					PaymentMethodType.WechatDomestic,
					PaymentMethodType.Telecheck,
					PaymentMethodType.Blik,
				];

				const voidableTransaction = paymentMethodTypes.map(
					(paymentMethodType) => ({
						transactionTime: 0,
						ipgTransactionId: `${Math.random()}`,
						transactionType: TransactionType.Sale,
						paymentMethodDetails: {
							paymentMethodType,
						},
					})
				);

				const transactionsWithVoidInfo =
					service.getTransactionsWithVoidAbilityInfo(voidableTransaction);

				expect(transactionsWithVoidInfo.length).toBe(
					voidableTransaction.length
				);
				transactionsWithVoidInfo.forEach((transaction) => {
					expect(transaction.canBeVoided).toBeFalsy();
				});
			});
		});

		describe("test transaction state", () => {
			it("should handle voidable states", () => {
				const states = [
					undefined,
					TransactionState.Authorized,
					TransactionState.Captured,
					TransactionState.Checked,
					TransactionState.CompletedGet,
					TransactionState.Initialized,
					TransactionState.Pending,
					TransactionState.Ready,
					TransactionState.Template,
					TransactionState.Waiting,
				];

				const voidableTransaction = states.map((transactionState) => ({
					transactionTime: 0,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType: TransactionType.Sale,
					transactionState,
				}));

				const transactionsWithVoidInfo =
					service.getTransactionsWithVoidAbilityInfo(voidableTransaction);

				expect(transactionsWithVoidInfo.length).toBe(
					voidableTransaction.length
				);
				transactionsWithVoidInfo.forEach((transaction) => {
					expect(transaction.canBeVoided).toBeTruthy();
				});
			});

			it("should handle voidable not states", () => {
				const states = [
					TransactionState.Settled,
					TransactionState.Voided,
					TransactionState.Declined,
				];

				const voidableTransaction = states.map((transactionState) => ({
					transactionTime: 0,
					ipgTransactionId: `${Math.random()}`,
					paymentType: ReportingPaymentType.Creditcard,
					transactionType: TransactionType.Sale,
					transactionState,
				}));

				const transactionsWithVoidInfo =
					service.getTransactionsWithVoidAbilityInfo(voidableTransaction);

				expect(transactionsWithVoidInfo.length).toBe(
					voidableTransaction.length
				);
				transactionsWithVoidInfo.forEach((transaction) => {
					expect(transaction.canBeVoided).toBeFalsy();
				});
			});
		});
	});
});
