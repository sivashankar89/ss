import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { PaymentsPaymentsService } from "services/payments/payments-payments.service";
import {
	RequestType,
	PaymentResponse,
	TransactionInfo,
	TransactionType,
} from "bff-client";

@Injectable({
	providedIn: "root",
})
export class VoidTransactionService {
	constructor(private paymentsPaymentsService: PaymentsPaymentsService) {}

	voidTransaction(
		transaction?: PaymentResponse | TransactionInfo
	): Observable<PaymentResponse> {
		if (!transaction || !transaction.ipgTransactionId) {
			return throwError(() => new Error(`Cannot find 'ipgTransactionId'`));
		}

		const requestType =
			transaction.transactionType === TransactionType.Preauth
				? RequestType.VoidPreAuthTransactions
				: RequestType.VoidTransaction;

		return this.paymentsPaymentsService.performSecondaryTransaction(
			transaction.ipgTransactionId,
			requestType
		);
	}
}
