import { Injectable } from "@angular/core";
import {
	PaymentResponse,
	TransactionInfo,
	TransactionState,
	TransactionType,
} from "bff-client";
import {
	GET_SORTED_TRANSACTIONS_FOR_VOID,
	NOT_VOIDABLE_TRANSACTION_STATES,
	TRANSACTION_HAS_PAYMENT_TYPE,
	VOIDABLE_TRANSACTION_TYPES,
	VOIDABLE_PAYMENT_TYPES,
	TRANSACTION_HAS_PAYMENT_DETAILS,
	VOIDABLE_PAYMENT_METHODS,
} from "./void-ability-checking.constants";
import { VoidableInfo } from "./void-ability-checking.model";

@Injectable({
	providedIn: "root",
})
export class VoidAbilityCheckingService {
	public getTransactionsWithVoidAbilityInfo<
		T = PaymentResponse | TransactionInfo
	>(allTransactions: T[]): VoidableInfo<T>[] {
		const transactions = GET_SORTED_TRANSACTIONS_FOR_VOID(allTransactions);
		const voidableTransactions: string[] = [];
		const hasSettledPostAuthTransaction = transactions.some(
			(transaction) =>
				transaction.transactionType === TransactionType.Postauth &&
				transaction.transactionState === TransactionState.Settled
		);

		transactions.forEach((transaction) => {
			if (
				transaction.ipgTransactionId &&
				this.isTransactionVoidable(transaction, hasSettledPostAuthTransaction)
			) {
				voidableTransactions.push(transaction.ipgTransactionId);
			}
		});

		return transactions.reduce<VoidableInfo<T>[]>((all, transaction) => {
			const canBeVoided = !!(
				transaction.ipgTransactionId &&
				voidableTransactions.includes(transaction.ipgTransactionId)
			);

			const enabledToBeVoided =
				canBeVoided &&
				(transactions.length === 1 ||
					transaction.transactionType === TransactionType.Return ||
					(transaction.ipgTransactionId &&
						voidableTransactions.indexOf(transaction.ipgTransactionId) === 0));

			all.push({
				canBeVoided,
				enabledToBeVoided,
				transaction,
			} as VoidableInfo<T>);

			return all;
		}, []);
	}

	private isTransactionVoidable(
		transaction: PaymentResponse | TransactionInfo,
		hasSettledPostAuthTransaction: boolean
	): boolean {
		if (!transaction || !transaction.ipgTransactionId) {
			return false;
		}

		return (
			this.hasTransactionVoidableType(transaction) &&
			this.hasTransactionVoidablePaymentMethod(transaction) &&
			this.hasTransactionVoidableState(transaction) &&
			this.isVoidablePreAuthTransaction(
				transaction,
				hasSettledPostAuthTransaction
			)
		);
	}

	private isVoidablePreAuthTransaction(
		transaction: PaymentResponse | TransactionInfo,
		hasSettledPostAuthTransaction: boolean
	): boolean {
		if (!transaction.transactionType) {
			return false;
		}

		return !(
			transaction.transactionType === TransactionType.Preauth &&
			transaction.transactionState === TransactionState.Authorized &&
			hasSettledPostAuthTransaction
		);
	}

	private hasTransactionVoidableType(
		transaction: PaymentResponse | TransactionInfo
	): boolean {
		if (!transaction.transactionType) {
			return false;
		}

		return VOIDABLE_TRANSACTION_TYPES.includes(
			transaction.transactionType as TransactionType
		);
	}

	private hasTransactionVoidablePaymentMethod(
		transaction: PaymentResponse | TransactionInfo
	): boolean {
		if (
			TRANSACTION_HAS_PAYMENT_TYPE(transaction) &&
			!!transaction.paymentType
		) {
			return VOIDABLE_PAYMENT_TYPES.includes(transaction.paymentType as any);
		}

		if (
			TRANSACTION_HAS_PAYMENT_DETAILS(transaction) &&
			!!transaction.paymentMethodDetails?.paymentMethodType
		) {
			return VOIDABLE_PAYMENT_METHODS.includes(
				transaction.paymentMethodDetails?.paymentMethodType
			);
		}

		return false;
	}

	private hasTransactionVoidableState(
		transaction: PaymentResponse | TransactionInfo
	): boolean {
		if (!transaction.transactionState) {
			return true;
		}

		return !NOT_VOIDABLE_TRANSACTION_STATES.includes(
			transaction.transactionState as TransactionState
		);
	}
}
