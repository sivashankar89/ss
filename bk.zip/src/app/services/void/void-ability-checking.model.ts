import { PaymentResponse, TransactionInfo } from "bff-client";

export interface VoidableInfo<T = PaymentResponse | TransactionInfo> {
	enabledToBeVoided: boolean;
	canBeVoided: boolean;
	transaction: T;
}
