import { TestBed } from "@angular/core/testing";
import { HttpClientModule } from "@angular/common/http";

import { MerchantDatasService } from "./merchant-datas.service";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";
import { MerchantDatasServiceStub } from "../../mocks/services/services.mock";

describe("MerchantDatasService", () => {
	let service: MerchantDatasService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [HttpClientModule],
			providers: [
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{ provide: MerchantDatasService, useValue: MerchantDatasServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		TestBed.configureTestingModule({});
		service = TestBed.inject(MerchantDatasService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});
});
