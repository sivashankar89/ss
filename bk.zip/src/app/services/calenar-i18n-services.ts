import { getLocaleFirstDayOfWeek } from "@angular/common";
import { Inject, Injectable, LOCALE_ID } from "@angular/core";
import { getMonth } from "date-fns";

@Injectable({
	providedIn: "root",
})
export class CalendarI18nService {
	constructor(@Inject(LOCALE_ID) private locale: string) {}

	getMonthLabel(value: Date | number): string {
		let index = typeof value === "number" ? value : null;

		if (index === null) {
			index = getMonth(value);
		}

		return [
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December",
		][index];
	}

	getWeekdayLabel(weekday: number): string {
		// Sun - 0, Mon - 1 ... Sat - 6
		const startIndex = getLocaleFirstDayOfWeek(this.locale);
		return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][
			(startIndex + weekday - 1) % 7
		];
	}
}
