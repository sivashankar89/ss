import { Injectable } from "@angular/core";
import {
	Observable,
	of,
	shareReplay,
	switchMap,
	throwError,
	map,
	share,
} from "rxjs";

import {
	Currency,
	PaymentBffService,
	GetAvailableCurrenciesRequestParams,
	CurrencyResponse,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";
import { getLocaleNumberSymbol, NumberSymbol } from "@angular/common";

@Injectable({ providedIn: "root" })
export class CurrenciesService {
	private currencies$!: Observable<Currency[]> | undefined;

	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService
	) {}

	// TODO: cache currency find results
	public getCurrency(currencyCode?: string): Observable<Currency> {
		return this.getCurrencies().pipe(
			switchMap((currencies) => {
				const currencySettings = currencies.find((currency) =>
					currencyCode
						? currency.literalCurrencyCode === currencyCode
						: currency.defaultCurrency
				);

				if (typeof currencySettings === "undefined") {
					return throwError(
						() =>
							new Error(`Settings for currency ${currencyCode} is not present`)
					);
				}

				return of(currencySettings);
			})
		);
	}

	public getDefaultCurrency(): Observable<Currency | undefined> {
		return this.getCurrencies().pipe(
			map((currencies: Currency[]) =>
				currencies.find((c) => c.defaultCurrency === true)
			)
		);
	}

	public getCurrencies(): Observable<Currency[]> {
		if (!this.currencies$) {
			this.currencies$ = this.fetchCurrencies().pipe(
				shareReplay({ bufferSize: 1, refCount: true })
			);
		}

		return this.currencies$;
	}

	private fetchCurrencies(): Observable<Currency[]> {
		const param: GetAvailableCurrenciesRequestParams = {
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
		};
		let availableCurrencies: Observable<CurrencyResponse> =
			this.paymentBff.getAvailableCurrencies(param);
		availableCurrencies.subscribe({ error: (err) => console.log(err) });
		return availableCurrencies.pipe(
			share(),
			map((res) => (res.currencies ? res.currencies : []))
		);
	}

	public getDecimalSepartor(): string {
		const key = this.getNavigatorLanguae();
		return getLocaleNumberSymbol(key, NumberSymbol.Decimal) || ".";
	}

	public getNavigatorLanguae(): string {
		return navigator.languages
			? navigator.languages[0].replace(/^(.+?)(-.*)?$/, "$1")
			: "en";
	}

	resetCurrency(): void {
		this.currencies$ = undefined;
	}
}
