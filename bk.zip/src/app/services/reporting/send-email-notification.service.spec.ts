import {
	HttpClientTestingModule,
	HttpTestingController,
} from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { BASE_PATH } from "../../../bff-client";
import { environment } from "../../../environments/environment";
import { SendEmailNotificationService } from "./send-email-notification.service";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("SendEmailNotificationService", () => {
	let httpTestingController: HttpTestingController;
	let service: SendEmailNotificationService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				SendEmailNotificationService,
				{ provide: BASE_PATH, useValue: environment.bffApiURl },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});

		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(SendEmailNotificationService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	describe("sendEmailNotification", () => {
		it("should return an error when `transaction id` is not provided or is not a transaction info type", (done) => {
			service.sendEmailNotification(1 as any).subscribe({
				error: (error) => {
					expect(error).toBeDefined();
					done();
				},
			});
		});
	});
});
