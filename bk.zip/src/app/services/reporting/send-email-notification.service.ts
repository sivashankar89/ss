import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import {
	PaymentBffService,
	SendEmailNotificationResponse,
	TransactionInfo,
} from "../../../bff-client";
import { SessionStorageService } from "../../utils/session-storage.service";

@Injectable({
	providedIn: "root",
})
export class SendEmailNotificationService {
	constructor(
		private storageService: SessionStorageService,
		private paymentBff: PaymentBffService
	) {}

	sendEmailNotification(
		transaction?: TransactionInfo
	): Observable<SendEmailNotificationResponse> {
		if (!transaction || !transaction.ipgTransactionId) {
			return throwError(() => new Error(`Cannot find 'ipgTransactionId'`));
		}

		return this.paymentBff.sendEmailNotification({
			transactionId: transaction.ipgTransactionId,
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
		});
	}
}
