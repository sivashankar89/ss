import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";

import {
	OrderReportResponse,
	PaymentBffService,
	GetOrderReportRequestParams,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";

@Injectable({
	providedIn: "root",
})
export class ReportingOrdersService {
	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService
	) {}

	public getOrderDetailsAndTransactions(
		orderId: string
	): Observable<OrderReportResponse> {
		if (typeof orderId !== "string") {
			return throwError(() => new Error("Order Id needs to be a string"));
		}
		const param: GetOrderReportRequestParams = {
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
			orderId: orderId,
		};
		return this.paymentBff.getOrderReport(param);
	}

	// TODO: implement method to expose `getList` endpoint form reporting API/orders if needed
}
