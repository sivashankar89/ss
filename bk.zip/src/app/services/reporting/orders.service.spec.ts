import {
	HttpClientTestingModule,
	HttpTestingController,
} from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { BASE_PATH } from "bff-client";
import { environment } from "environments/environment";
import { REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE } from "mocks/reporting_api/orders.mock";

import { ReportingOrdersService } from "./orders.service";
import {
	AuthenticationService,
	InstanceConfigService,
} from "@international-payment-platform/portal-core";
import {
	AuthenticationServiceStub,
	TelemetryServiceStub,
} from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

describe("ReportingOrdersService", () => {
	let httpTestingController: HttpTestingController;
	let service: ReportingOrdersService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				ReportingOrdersService,
				{ provide: BASE_PATH, useValue: environment.bffApiURl },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});

		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(ReportingOrdersService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	describe("getOrderDetailsAndTransactions", () => {
		it("should return order details for a given `orderId`", (done) => {
			service.getOrderDetailsAndTransactions("1").subscribe((response) => {
				expect(response).toEqual(REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE);
				done();
			});

			httpTestingController
				.expectOne(environment.bffApiURl + "/reporting/orders/1")
				.flush(REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE);
		});

		it("should return an error when `orderId` is not provided or is not a string", (done) => {
			service.getOrderDetailsAndTransactions(1 as any).subscribe({
				error: (error) => {
					expect(error).toBeDefined();
					done();
				},
			});
		});

		it("should return an error from API", (done) => {
			service.getOrderDetailsAndTransactions("1").subscribe({
				error: (error) => {
					expect(error).toBeDefined();
					done();
				},
			});

			httpTestingController
				.expectOne(environment.bffApiURl + "/reporting/orders/1")
				.error(new ErrorEvent("network error"));
		});
	});
});
