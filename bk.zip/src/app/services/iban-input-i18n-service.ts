import { Injectable } from "@angular/core";
import { CdsIbanInputI18nService } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";

@Injectable({
	providedIn: "root",
})
export class IbanInputI18nService extends CdsIbanInputI18nService {
	constructor(private translate: TranslateService) {
		super();
	}

	getRequiredFieldErrorMessage(): string {
		return this.translate.instantSafe("shared.field_required_error");
	}

	getErrorMessage(): string {
		return this.translate.instantSafe("shared.iban_input_error");
	}
}
