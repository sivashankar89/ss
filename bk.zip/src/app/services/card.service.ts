import { Injectable } from "@angular/core";
import { catchError, map, Observable } from "rxjs";
import {
	CardRequest,
	LookUpCardRequestParams,
	PaymentBffService,
	GetAvailableBrandsRequestParams,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";

@Injectable({
	providedIn: "root",
})
export class CardService {
	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService
	) {}

	postData(cardRequest: CardRequest): Observable<any> {
		const param: LookUpCardRequestParams = {
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
			cardRequest: cardRequest,
		};
		return this.paymentBff.lookUpCard(param).pipe(
			map((response) => {
				return response;
			}),
			catchError((err) => {
				throw new Error("Error in saving panel info");
			})
		);
	}

	getAvailableBrands(): Observable<any> {
		const param: GetAvailableBrandsRequestParams = {
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
		};
		return this.paymentBff.getAvailableBrands(param).pipe(
			map((response) => {
				return response;
			}),
			catchError((err) => {
				throw new Error("Error in fetching brands");
			})
		);
	}
}
