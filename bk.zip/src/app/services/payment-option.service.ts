import { Injectable } from "@angular/core";
import { map, Observable, share, shareReplay } from "rxjs";
import { StoreBffService } from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";

@Injectable({
	providedIn: "root",
})
export class PaymentOptionService {
	private optTypes$!: Observable<Array<any>> | undefined;
	constructor(
		private storeBff: StoreBffService,
		private storageService: SessionStorageService
	) {}

	public getPamentOptions(): Observable<Array<any>> {
		if (!this.optTypes$) {
			this.optTypes$ = this.fetchPaymentOptions().pipe(
				shareReplay({ bufferSize: 1, refCount: true })
			);
		}
		return this.optTypes$;
	}

	private fetchPaymentOptions(): Observable<Array<any>> {
		return this.storeBff
			.getSupportedPaymentMethods({
				authorizerId: this.storageService.getStoreId(),
				selectedGatewayServiceEnvironment:
					this.storageService.getGatewayEnvironment(),
			})
			.pipe(
				share(),
				map((res) => (res ? res : []))
			);
	}

	resetPaymentMethods(): void {
		this.optTypes$ = undefined;
	}
}
