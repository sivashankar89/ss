import { BehaviorSubject, Observable } from "rxjs";
import { Injectable } from "@angular/core";
import { ApiErrorMessage } from "../model/error.model";
import { WithLoadingError } from "../model/common.model";
import {
	OrderDetailsResponse,
	PaymentBffService,
	PaymentMethodType,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";
import { SaleInfoService } from "./sale-info.service";

@Injectable({
	providedIn: "root",
})
export class OrderDetailsService {
	private orderId = "";
	private orderDetails = new BehaviorSubject<
		WithLoadingError<OrderDetailsResponse>
	>({
		loading: false,
	});
	public orderDetails$ = this.orderDetails.asObservable();

	public isQueryOrderId = new BehaviorSubject<boolean>(false);
	public isQueryOrderId$ = this.isQueryOrderId.asObservable();

	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService,
		private saleInfoService: SaleInfoService
	) {}

	private loadOrderDetails(orderId: string): void {
		if (!orderId || orderId === "") {
			this.setOrderDetails(false);
			return;
		}
		this.setOrderDetails(true);
		this.getOrderDetails(orderId).subscribe({
			next: (order) => {
				// TODO: should be thrown when cardholder name present in the API. Currently we passed billing name
				this.assignCardHolderName(order);
				// TODO: should be thrown when account name present in the API. Currently we passed billing name
				this.accountHolderName(order);
				this.setOrderDetails(false, order);
				this.saleInfoService.orderIdCheckProgress = false;
			},
			error: (err) => {
				this.saleInfoService.orderIdCheckProgress = false;
				this.setOrderDetails(false, undefined, err?.error || { code: "" });
			},
		});
	}

	private assignCardHolderName(order: OrderDetailsResponse): void {
		if (!order.transactions) {
			return;
		}
		const billingName = order.billing?.name;
		order.transactions.forEach((transaction) => {
			if (
				transaction.paymentMethodDetails &&
				transaction.paymentMethodDetails.paymentCard &&
				billingName
			) {
				transaction.paymentMethodDetails.paymentCard.cardholderName =
					billingName;
			}
		});
	}

	private accountHolderName(order: OrderDetailsResponse): void {
		if (!order.transactions) {
			return;
		}
		const billingName = order.billing?.name;
		order.transactions.forEach((transaction) => {
			if (
				transaction.paymentMethodDetails &&
				transaction.paymentMethodDetails.paymentMethodType !==
					PaymentMethodType.PaymentCard &&
				billingName
			) {
				transaction.paymentMethodDetails.accountHolderName = billingName;
			}
		});
	}

	public getOrderDetails(orderId: string): Observable<OrderDetailsResponse> {
		return this.paymentBff.getOrderDetails({
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
			orderId: orderId,
		});
	}

	private setOrderDetails(
		loading: boolean,
		value?: OrderDetailsResponse,
		error?: ApiErrorMessage
	): void {
		this.orderDetails.next({ loading, value, error });
	}

	/**
	 * Set Order Id
	 */
	public setOrderId(orderId: string): void {
		this.orderId = orderId;
		const order = this.orderDetails.getValue();
		if (this.orderDetails.value && order.value?.orderId !== orderId.trim()) {
			this.loadOrderDetails(orderId);
		}
	}

	/**
	 * Get Order Id
	 */
	public getOrderId(): string {
		return this.orderId;
	}
}
