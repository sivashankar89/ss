import { Injectable } from "@angular/core";
import { MerchantDataResponse, StoreBffService } from "bff-client";
import { map, Observable, share, shareReplay } from "rxjs";
import { SessionStorageService } from "utils/session-storage.service";
import { StoreListResponse } from "../../bff-client/model/storeListResponse";

@Injectable({
	providedIn: "root",
})
export class MerchantDatasService {
	private merchantData$!: Observable<MerchantDataResponse> | undefined;
	constructor(
		private storageService: SessionStorageService,
		private storeBffService: StoreBffService
	) {}

	public getMerchantData(): Observable<MerchantDataResponse> {
		if (!this.merchantData$) {
			this.merchantData$ = this.fetchMerchantData().pipe(
				shareReplay({ bufferSize: 1, refCount: true })
			);
		}
		return this.merchantData$;
	}

	private fetchMerchantData(): Observable<MerchantDataResponse> {
		return this.storeBffService
			.getMerchantData({
				authorizerId: this.storageService.getStoreId(),
				selectedGatewayServiceEnvironment:
					this.storageService.getGatewayEnvironment(),
			})
			.pipe(
				share(),
				map((res) => res || [])
			);
	}

	getStoreIds(): Observable<StoreListResponse> {
		return this.storeBffService
			.getListOfAccessibleStoreId({
				selectedGatewayServiceEnvironment:
					this.storageService.getGatewayEnvironment(),
			})
			.pipe(map((res) => res || []));
	}

	getBestMatchStoreIds(storeId: string): Observable<StoreListResponse> {
		return this.storeBffService
			.getListOfStoresBestMatch({
				storeIdBestMatch: storeId,
				selectedGatewayServiceEnvironment:
					this.storageService.getGatewayEnvironment(),
			})
			.pipe(map((res) => res || []));
	}

	resetMerchantData(): void {
		this.merchantData$ = undefined;
	}
}
