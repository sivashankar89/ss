import { HttpClientModule } from "@angular/common/http";
import { TestBed } from "@angular/core/testing";
import { NGXLoggerMock } from "ngx-logger/testing/ngx-logger-testing";
import { NGXLogger, NgxLoggerLevel, TOKEN_LOGGER_CONFIG } from "ngx-logger";

import { PaymentUrlService } from "./payment-url.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

describe("PaymentUrlService", () => {
	let service: PaymentUrlService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [HttpClientModule],
			providers: [
				{ provide: NGXLogger, useClass: NGXLoggerMock },
				{
					provide: TOKEN_LOGGER_CONFIG,
					useValue: { level: NgxLoggerLevel.ERROR },
				},
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		TestBed.configureTestingModule({});
		service = TestBed.inject(PaymentUrlService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});
});
