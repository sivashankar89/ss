import { Injectable } from "@angular/core";
import {
	ActivatedRouteSnapshot,
	CanActivate,
	Router,
	RouterStateSnapshot,
} from "@angular/router";
import { AuthenticationService } from "@international-payment-platform/portal-core";

@Injectable({
	providedIn: "root",
})
export class PermissionGuardService implements CanActivate {
	constructor(
		private authenticationService: AuthenticationService,
		private router: Router
	) {}

	canActivate(
		route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot
	): boolean {
		let canProceed = true;
		if (route.data && route.data.permissions) {
			canProceed = this.hasPermission(route.data.permissions);
		}
		if (canProceed && route.data && route.data.noPermissions) {
			canProceed = this.hasPermission(route.data.noPermissions) ? false : true;
		}
		if (!canProceed) {
			this.router.navigate(["/", "no-access"], {
				skipLocationChange: true,
				queryParams: {
					url: state.url,
				},
			});
		}
		return canProceed;
	}

	hasPermission(permissions: string | Array<string>): boolean {
		const userPermissions: string[] =
			this.authenticationService.getPermissions();
		if (typeof permissions === "string") {
			permissions = [permissions];
		}
		return permissions.some((permission) =>
			userPermissions.includes(permission)
		);
	}
}
