import { TestBed } from "@angular/core/testing";
import {
	HttpClientTestingModule,
	HttpTestingController,
} from "@angular/common/http/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { CardInputI18nService } from "./card-input-i18n-service";
import { TelemetryService } from "services/telemetry.service";

describe("cardInputi18nService", () => {
	let httpTestingController: HttpTestingController;
	let service: CardInputI18nService;
	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				CardInputI18nService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});
		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(CardInputI18nService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it("getRequiredFieldErrorMessage should return expected data", () => {
		service.getRequiredFieldErrorMessage();
	});

	it("getCardNumberErrorMessage should return expected data", () => {
		service.getCardNumberErrorMessage();
	});
	it("getCardNumberLabel should return expected data", () => {
		service.getCardNumberLabel();
	});

	it("getCvvLabel should return expected data", () => {
		service.getCvvLabel();
	});
	it("getCvvErrorMessage should return expected data", () => {
		service.getCvvErrorMessage();
	});

	it("getExpiryDateLabel should return expected data", () => {
		service.getExpiryDateLabel();
	});

	it("getExpiryDateErrorMessage should return expected data", () => {
		service.getExpiryDateErrorMessage();
	});
});
