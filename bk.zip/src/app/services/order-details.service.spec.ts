import { TestBed } from "@angular/core/testing";
import {
	HttpClientTestingModule,
	HttpTestingController,
} from "@angular/common/http/testing";
import { OrderDetailsService } from "./order-details.service";
import { OrderDetails } from "mocks/constant";
import { environment } from "environments/environment";
import { BASE_PATH } from "bff-client";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("OrderDetailsService", () => {
	let httpTestingController: HttpTestingController;
	let service: OrderDetailsService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				OrderDetailsService,
				{ provide: BASE_PATH, useValue: environment.bffApiURl },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});

		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(OrderDetailsService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	describe("getOrder", () => {
		it("should return order details for a given `orderId`", (done) => {
			service.setOrderId("1");
			service.orderDetails$.subscribe((response) => {
				expect(response.value).toEqual(OrderDetails);
				done();
			});

			httpTestingController
				.expectOne(environment.bffApiURl + "/orders/1")
				.flush(OrderDetails);
		});
	});
});
