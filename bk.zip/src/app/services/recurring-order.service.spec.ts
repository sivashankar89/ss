import { TestBed } from "@angular/core/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "../../mocks/services/services.mock";
import { RecurringOrderService } from "./recurring-order.service";
import { TelemetryService } from "services/telemetry.service";

describe("RecurringOrderService", () => {
	let service: RecurringOrderService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});

		service = TestBed.inject(RecurringOrderService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});
});
