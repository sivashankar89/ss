import { Injectable } from "@angular/core";
import { CdsCardInputsI18nService } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";

@Injectable()
export class CardInputI18nService extends CdsCardInputsI18nService {
	constructor(private translate: TranslateService) {
		super();
	}

	getRequiredFieldErrorMessage(): string {
		return this.translate.instantSafe("shared.field_required_error");
	}

	getCardNumberLabel(): string {
		return this.translate.instantSafe("shared.card_number");
	}

	getCardNumberErrorMessage(): string {
		return this.translate.instantSafe("shared.card_number_error");
	}

	getCvvLabel(): string {
		return this.translate.instantSafe("shared.card_cvv_label");
	}

	getCvvErrorMessage(): string {
		return this.translate.instantSafe("shared.card_cvv_error");
	}

	getExpiryDateLabel(): string {
		return this.translate.instantSafe("shared.card_expiry_date_label");
	}

	getExpiryDateErrorMessage(): string {
		return this.translate.instantSafe("shared.card_expiry_date_error");
	}
}
