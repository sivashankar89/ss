import { Injectable } from "@angular/core";
import { catchError, Observable } from "rxjs";
import {
	PaymentBffService,
	PaymentLinkRequest,
	PaymentLinkResponse,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";
import { NGXLogger } from "ngx-logger";
import { TelemetryService } from "services/telemetry.service";

@Injectable({
	providedIn: "root",
})
export class PaymentUrlService {
	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService,
		private logger2: NGXLogger,
		private telemetryService: TelemetryService
	) {}

	postData(
		paymentLinkRequest: PaymentLinkRequest
	): Observable<PaymentLinkResponse> {
		return this.telemetryService.withSpanName("paymentLinkRequest", () => {
			return this.paymentBff
				.createPaymentLink({
					authorizerId: this.storageService.getStoreId(),
					selectedGatewayServiceEnvironment:
						this.storageService.getGatewayEnvironment(),
					paymentLinkRequest: paymentLinkRequest,
				})
				.pipe(
					catchError((err) => {
						const error = new Error(err.error.detail);
						throw new Error(err.error.detail);
					})
				);
		});
	}
}
