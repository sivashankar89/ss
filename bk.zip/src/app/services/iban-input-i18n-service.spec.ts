import { TestBed } from "@angular/core/testing";
import {
	HttpClientTestingModule,
	HttpTestingController,
} from "@angular/common/http/testing";
import { TranslateService } from "@tolgee/ngx";
import { TranslateServiceStub } from "mocks/services/services.mock";
import { IbanInputI18nService } from "./iban-input-i18n-service";

describe("IbanInputI18nService", () => {
	let httpTestingController: HttpTestingController;
	let service: IbanInputI18nService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				IbanInputI18nService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
			],
		});
		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(IbanInputI18nService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it("getRequiredFieldErrorMessage should return expected data", () => {
		service.getRequiredFieldErrorMessage();
	});

	it("getIbanInputErrorMessage should return expected data", () => {
		service.getErrorMessage();
	});
});
