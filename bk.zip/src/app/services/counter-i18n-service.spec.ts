import { TestBed } from "@angular/core/testing";
import {
	HttpClientTestingModule,
	HttpTestingController,
} from "@angular/common/http/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { CounterI18nService } from "./counter-i18n-service";
import { TelemetryService } from "services/telemetry.service";

describe("CounterI18nService", () => {
	let httpTestingController: HttpTestingController;
	let service: CounterI18nService;
	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				CounterI18nService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});
		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(CounterI18nService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it("getMinErrorMessage should return expected data", () => {
		service.getMinErrorMessage(5);
	});

	it("getMaxErrorMessage should return expected data", () => {
		service.getMaxErrorMessage(100);
	});
});
