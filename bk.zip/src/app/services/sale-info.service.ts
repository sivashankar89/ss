import { Injectable } from "@angular/core";
import { PAGE_FROM } from "enum/primary.transaction.enum";
import { BehaviorSubject, map, Observable, filter } from "rxjs";
import {
	Address,
	PaymentCard,
	PaymentRequest,
	PaymentSEPA,
	ScheduledPaymentRequest,
	TransactionOrigin,
	PaymentLinkRequest,
	PaymentLinkResponse,
	Mcc6012,
	TransactionAmount,
} from "bff-client";
import {
	initAddressValues,
	initOrderDetails,
	initRecurringOrderDetails,
} from "../model/new-sale-order.model";
import { TransactionType } from "bff-client";

@Injectable({
	providedIn: "root",
})
export class SaleInfoService {
	private saleDetails = new BehaviorSubject<PaymentRequest>(
		JSON.parse(JSON.stringify(initOrderDetails))
	);
	private recurringOrderDetails = new BehaviorSubject<ScheduledPaymentRequest>(
		initRecurringOrderDetails
	);
	private recurringOrderDetails$ = this.recurringOrderDetails.asObservable();
	isOrderAvailable = false;
	isDeliveryAvailable = false;
	isBillingAvailable = false;
	isRecurringPayment = false;
	paymentType = "";
	retainedTab = "";
	tabPayType = false;
	storeCurrency: any;
	pageToInitiate = PAGE_FROM.SALE;
	paymentLinkCreated = false;
	paymentLinkExpiryDate!: Date;
	paymentLinkResponse!: PaymentLinkResponse | null;
	cardResponse: any;
	tokenToGenerate = false;
	mccSupportedMerchant = false;
	mccActivatedTab = "accNumber";
	payCardBrand: string | undefined = "";
	cardNumber = "";
	isTokenGenerateClicked = false;
	orderIdCheckProgress = false;

	public setSaleInfo(order: PaymentRequest): void {
		this.saleDetails.next(order);
	}

	public resetSaleInfo(): void {
		this.isOrderAvailable = false;
		this.isDeliveryAvailable = false;
		this.isBillingAvailable = false;
		this.isRecurringPayment = false;
		this.paymentType = "";
		this.retainedTab = "";
		this.tabPayType = false;
		this.storeCurrency = "";
		this.paymentLinkCreated = false;
		this.paymentLinkResponse = null;
		this.cardResponse = "";
		this.tokenToGenerate = false;
		this.mccSupportedMerchant = false;
		this.mccActivatedTab = "accNumber";
		this.payCardBrand = "";
		this.cardNumber = "";
		this.isTokenGenerateClicked = false;
		this.orderIdCheckProgress = false;
		this.setSaleInfo(JSON.parse(JSON.stringify(initOrderDetails)));
	}

	public getOrderDetails$(): Observable<PaymentRequest> {
		return this.saleDetails.asObservable();
	}

	changeAddresLines(address: Address | undefined): any {
		if (!address) {
			return { ...initAddressValues };
		}
		return {
			address1: address.address1,
			address2: address.address2,
			city: address.city,
			region: address.region,
			postalCode: address.postalCode,
			country: address.country,
			company: address.company,
		};
	}

	updateCardPayment(card: PaymentCard, origin?: TransactionOrigin): void {
		const data = { ...this.saleDetails.value };
		if (!data.paymentMethod) {
			data.paymentMethod = {};
		}
		if (!!origin) {
			data.transactionOrigin = origin;
		} else {
			delete data.transactionOrigin;
		}
		data.paymentMethod.paymentCard = card;
		this.saleDetails.next(data);
	}

	updateMccIndustryExtension(mccData: Mcc6012, recurringMethod = false): void {
		if (recurringMethod) {
			const recData = { ...this.recurringOrderDetails.value };
			recData.industrySpecificExtensions = { ...recData, mcc6012: mccData };
			this.recurringOrderDetails.next(recData);
		} else {
			const data = { ...this.saleDetails.value };
			data.order = {
				...data.order,
				industrySpecificExtensions: { mcc6012: mccData },
			};
			this.saleDetails.next(data);
		}
	}

	updateSepaPayment(sepa: PaymentSEPA): void {
		const data = { ...this.saleDetails.value };
		if (!data.paymentMethod) {
			data.paymentMethod = {};
		}
		data.paymentMethod.sepa = sepa;
		this.saleDetails.next(data);
	}

	updateTokenPayment(token: string, origin: TransactionOrigin): void {
		const data = { ...this.saleDetails.value };
		if (!data.paymentMethod) {
			data.paymentMethod = {};
		}
		data.paymentMethod.paymentToken = {
			value: token,
		};
		if (!!origin) {
			data.transactionOrigin = origin;
		} else {
			delete data.transactionOrigin;
		}
		this.saleDetails.next(data);
	}

	createToken(): void {
		const data = { ...this.saleDetails.value };
		data.createToken = {};
		this.saleDetails.next(data);
	}

	setRecurringPayment(recurringData: any, origin: TransactionOrigin): void {
		const recurringOrder = { ...initRecurringOrderDetails };
		if (!recurringOrder.frequency) {
			recurringOrder.frequency = {};
		}
		recurringOrder.frequency.every = recurringData.counter;
		recurringOrder.frequency.unit = recurringData.recurringPeriod;

		if (recurringData.repeatDelayAfter === undefined) {
			delete recurringOrder.numberOfPayments; // In case of "Never" - numberOfPayments will NOT be passed.
		} else if (recurringData.repeatDelayAfter) {
			recurringOrder.numberOfPayments = recurringData.repeatDelayAfter;
		}
		recurringOrder.startDate = recurringData.startDate;
		if (!!origin) {
			recurringOrder.transactionOrigin = origin;
		} else {
			delete recurringOrder.transactionOrigin;
		}
		this.recurringOrderDetails.next(recurringOrder);
	}

	checkTransactionAmount(
		transactionAmount?: TransactionAmount
	): TransactionAmount {
		const amount = transactionAmount
			? JSON.parse(JSON.stringify(transactionAmount))
			: {};
		const returnZeroIfEmpty = (num: number | string): string => {
			if (typeof num === "number") {
				num = num.toString();
			}
			if (!num || num.trim() === "" || parseFloat(num) === 0) {
				return "0";
			}
			return num;
		};

		amount.total = returnZeroIfEmpty(amount.total);
		amount.currency = amount.currency || "";

		if (amount.components) {
			for (const key in amount.components) {
				amount.components[key] = returnZeroIfEmpty(amount.components[key]);
			}

			if (!amount.components["subtotal"]) {
				amount.components["subtotal"] = "0";
			}
		}

		return amount;
	}

	getRecurringPayload$(): Observable<ScheduledPaymentRequest | undefined> {
		return this.getOrderDetails$().pipe(
			filter((order) => !!order),
			map((orderDetails: PaymentRequest) => {
				const recurringOrder: ScheduledPaymentRequest =
					this.recurringOrderDetails.value;
				recurringOrder.paymentMethod = orderDetails.paymentMethod;
				recurringOrder.transactionAmount = this.checkTransactionAmount(
					orderDetails.transactionAmount
				);
				if (this.saleDetails.value.order?.orderId?.trim()) {
					recurringOrder.orderId = !!orderDetails.order?.orderId
						? orderDetails.order.orderId.trim()
						: "";
				}
				if (!!orderDetails.order?.billing) {
					recurringOrder.billing = orderDetails.order?.billing;
				}
				if (!!orderDetails.order?.shipping) {
					recurringOrder.shipping = orderDetails.order.shipping;
				}
				return recurringOrder;
			})
		);
	}

	getSinglePaymentPayload$(): Observable<any | undefined> {
		return this.getOrderDetails$().pipe(
			filter((order) => !!order),
			map((order: PaymentRequest) => {
				const payload = JSON.parse(JSON.stringify(order));
				delete payload.transactionType;
				payload.transactionAmount = this.checkTransactionAmount(
					payload.transactionAmount
				);
				if (payload.order?.orderId?.trim()) {
					payload.order.orderId = payload.order.orderId.trim();
				}
				return payload;
			})
		);
	}

	getPaymentLinkPayload$(expiration?: Date): Observable<PaymentLinkRequest> {
		return this.getOrderDetails$().pipe(
			filter((order) => !!order),
			map((order: PaymentRequest) => {
				const orderDetails = { ...order.order };

				if (orderDetails.orderId?.trim()) {
					orderDetails.orderId = orderDetails.orderId?.trim();
				}

				if (
					orderDetails?.billing?.address &&
					Object.values(orderDetails?.billing.address).every(
						(o) => o === "" || o === " "
					)
				) {
					delete orderDetails?.billing.address;
				}

				if (
					orderDetails?.billing &&
					(Object.keys(orderDetails?.billing).length === 0 ||
						!this.isBillingAvailable)
				) {
					delete orderDetails?.billing;
				}

				if (
					orderDetails?.shipping &&
					Object.keys(orderDetails?.shipping).length === 0
				) {
					delete orderDetails?.shipping;
				}

				const request = {
					merchantId: "merchant1",
					merchantTransactionId: "merchant1",
					transactionType:
						order.transactionType === TransactionType.Preauth
							? "PRE-AUTH"
							: order.transactionType,
					transactionAmount: {
						total: order?.transactionAmount?.total || 0,
						currency: order?.transactionAmount?.currency || "",
						components: {
							subtotal: order?.transactionAmount?.components?.subtotal || 0,
							shipping: order?.transactionAmount?.components?.shipping || 0,
							vatAmount: order?.transactionAmount?.components?.vatAmount || 0,
						},
					},
					paymentLinkDetails: {},
					order: orderDetails,
					checkoutSettings: {
						locale: "en-us",
					},
				} as PaymentLinkRequest;
				if (expiration && request?.paymentLinkDetails) {
					expiration.setMilliseconds(999);
					request.paymentLinkDetails.expiryDateTime = expiration.toISOString();
				}
				return request;
			})
		);
	}
}
