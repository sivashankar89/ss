import { Injectable, SecurityContext } from "@angular/core";
import { ActivatedRoute, NavigationStart, Router } from "@angular/router";
import { delay, fromEvent, of, Subscription } from "rxjs";
import { DomSanitizer } from "@angular/platform-browser";

@Injectable({
	providedIn: "root",
})
export class RedirectCallbackService {
	private callbackUrl = "";
	private defaultUrl = "/";
	private enableReturn = false;
	private subscriptions: Subscription[] = [];

	constructor(
		private route: ActivatedRoute,
		private router: Router,
		private sanitize: DomSanitizer
	) {}

	init(defaultUrl?: string): void {
		this.defaultUrl = defaultUrl ? defaultUrl : "/";
		this.subscriptions.push(
			this.route.queryParams.subscribe((params) => {
				this.enableReturn = true;
				this.callbackUrl = params.callback ? params.callback : "";
			})
		);

		this.subscriptions.push(
			fromEvent(window, "beforeunload").subscribe(() => {
				this.enableReturn = false;
			})
		);

		this.subscriptions.push(
			this.router.events.subscribe((event) => {
				if (event instanceof NavigationStart) {
					this.enableReturn = false;
				}
			})
		);
	}

	destroy(): void {
		this.enableReturn = false;
		this.subscriptions.forEach((s) => s.unsubscribe());
	}

	return(): void {
		if (!this.enableReturn) {
			return;
		}
		if (this.callbackUrl) {
			window.location.assign(
				this.sanitize.sanitize(SecurityContext.URL, this.callbackUrl) || ""
			);
		} else {
			this.router.navigate([this.defaultUrl]);
		}
	}
}
