import { HttpClientTestingModule } from "@angular/common/http/testing";
import { fakeAsync, TestBed, tick } from "@angular/core/testing";
import { ActivatedRoute, Router } from "@angular/router";
import { of } from "rxjs";
import { RedirectCallbackService } from "./redirect-callback.service";

describe("RedirectCallbackService", () => {
	let service: RedirectCallbackService;
	let router: Router;
	let activatedRoute: ActivatedRoute;
	const mockNavigate = jest.fn();

	beforeAll(() => {
		Object.defineProperty(window, "location", {
			value: { assign: jest.fn() },
		});
	});

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				RedirectCallbackService,
				{
					provide: ActivatedRoute,
					useValue: {
						queryParams: of({}),
					},
				},
				{
					provide: Router,
					useValue: {
						navigate: mockNavigate,
						events: of(null),
					},
				},
			],
		});

		service = TestBed.inject(RedirectCallbackService);
		router = TestBed.inject(Router);
		activatedRoute = TestBed.inject(ActivatedRoute);
	});

	afterEach(() => {});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it("check init method with no query params", fakeAsync(() => {
		service.init();
		service.return();
		tick(500);
		expect(router.navigate).toHaveBeenCalledWith(["/"]);
	}));

	it("check init method with query params", fakeAsync(() => {
		activatedRoute.queryParams = of({ callback: "test" });
		service.init();
		service.return();
		tick(500);
		expect(window.location.assign).toHaveBeenCalledWith("test");
	}));

	it("check destroy method", fakeAsync(() => {
		service.init();
		service.destroy();
		service.return();
		tick(500);
		expect(router.navigate).not.toHaveBeenCalledWith([""]);
		expect(window.location.assign).not.toHaveBeenCalledWith("");
	}));
});
