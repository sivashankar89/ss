import { TestBed } from "@angular/core/testing";
import { HttpClientModule } from "@angular/common/http";

import { PaymentOptionService } from "./payment-option.service";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("PaymentOptionService", () => {
	let service: PaymentOptionService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [HttpClientModule],
			providers: [
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		TestBed.configureTestingModule({});
		service = TestBed.inject(PaymentOptionService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});
});
