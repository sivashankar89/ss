import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { PermissionGuardService } from "services/permission-guard.service";

export const routes: Routes = [
	{
		path: "virtual-terminal",
		loadChildren: () =>
			import("./transaction-entry/transaction-entry.module").then(
				(m) => m.TransactionEntryModule
			),
	},
	{
		path: "order-details",
		loadChildren: () =>
			import("./order-details/order-details.module").then(
				(m) => m.OrderDetailsModule
			),
		data: {
			permissions: [VTPaymentPermissions.EcomVTOrderDetailsView],
		},
		canActivate: [PermissionGuardService],
	},
	{
		path: "no-access",
		loadChildren: () =>
			import("./no-access/no-access.module").then((m) => m.NoAccessModule),
	},
	{ path: "", redirectTo: "virtual-terminal", pathMatch: "full" },
];

@NgModule({
	declarations: [],
	imports: [RouterModule.forRoot(routes, { useHash: true })],
	exports: [RouterModule],
})
export class AppRoutingModule {}
