import { Inject, Injectable, Optional } from "@angular/core";
import { catchError, finalize, map, Observable } from "rxjs";
import {
	HttpEvent,
	HttpHandler,
	HttpHeaders,
	HttpInterceptor,
	HttpRequest,
	HttpResponse,
} from "@angular/common/http";
import {
	AuthenticationService,
	InstanceConfigService,
} from "@international-payment-platform/portal-core";
import { environment } from "environments/environment";
import { TelemetryService } from "services/telemetry.service";
import * as api from "@opentelemetry/api";
import { context, Span, SpanStatusCode, trace } from "@opentelemetry/api";
import {
	OpenTelemetryConfig,
	OTEL_CONFIG,
} from "@jufab/opentelemetry-angular-interceptor";
import { SemanticAttributes } from "@opentelemetry/semantic-conventions";
import { SsoService } from "services/sso.service";

@Injectable()
export class HttpHeadersInterceptor implements HttpInterceptor {
	/**
	 * Log or not body
	 */
	logBody: boolean | undefined = false;

	constructor(
		@Optional() @Inject(OTEL_CONFIG) private config: OpenTelemetryConfig,
		private authenticationService: AuthenticationService,
		private instanceConfigService: InstanceConfigService,
		private telemetryService: TelemetryService,
		private ssoService: SsoService
	) {
		this.logBody = config?.commonConfig.logBody;
		this.ssoService = ssoService;
	}

	public intercept(
		req: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		if (req.url.indexOf(environment.bffApiURl) !== -1) {
			return this.telemetryService.withSpanRequest(req, () => {
				const span: Span | undefined = trace.getSpan(context.active());
				// all header values must be strings, otherwise expect pain
				let allianceCode = this.instanceConfigService
					.configValueGetter("allianceCode")
					?.toString();
				let realm = this.instanceConfigService
					.configValueGetter("realm")
					?.toString();
				let merchantId = this.authenticationService
					.getUserDetails()
					?.merchantId?.toString();
				let carier = {
					"alliance-code": allianceCode,
					realm: realm,
					merchantId: merchantId ? merchantId : "NOT_KNOWN",
					"ecom-application-version": environment.appVersion.toString(),
				};
				let clone;
				if (this.ssoService.serviceWorkerAddsHeaders()) {
					clone = this.injectContextAndHeader(req, req.headers, carier);
				} else {
					// TODO remove, let the service worker inject both once merchant portal provides support
					clone = this.injectContextAndHeader(
						req,
						this.authenticationService.addAuthenticationHeader(req.headers),
						carier
					);
				}
				return next.handle(clone).pipe(
					map((event: HttpEvent<any>) => {
						if (event instanceof HttpResponse) {
							span?.setAttributes({
								[SemanticAttributes.HTTP_STATUS_CODE]: event?.status,
							});
							if (this.logBody && event?.body != null) {
								span?.addEvent("response", {
									body: JSON.stringify(event?.body),
								});
							}
							span?.setStatus({
								code: SpanStatusCode.UNSET,
							});
						}
						return event;
					}),
					catchError((event) => {
						span?.setAttributes({
							[SemanticAttributes.HTTP_STATUS_CODE]: event.status,
						});
						span?.recordException({
							name: event.name,
							message: event.message,
							stack: event.error,
						});
						span?.setStatus({
							code: SpanStatusCode.ERROR,
						});
						throw new Error(event?.error?.detail);
					}),
					finalize(() => {
						span?.end();
					})
				);
			});
		}

		return next.handle(req);
	}

	/**
	 * Add header trace-id propagator(s) in request and conserve original header
	 *
	 * @param request request
	 * @param headers
	 * @param carrier
	 */
	private injectContextAndHeader(
		request: HttpRequest<unknown>,
		headers: HttpHeaders,
		carrier: { [name: string]: string | string[] }
	) {
		api.propagation.inject(
			this.telemetryService.contextManager.active(),
			carrier,
			api.defaultTextMapSetter
		);
		request.headers.keys().map((key) => {
			const value = request.headers.get(key);
			if (value != null) {
				carrier[key] = value;
			}
		});
		return request.clone({
			headers: headers,
			setHeaders: carrier,
		});
	}
}
