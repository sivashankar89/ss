import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { SessionStorageService } from "../utils/session-storage.service";

@Injectable({
	providedIn: "root",
})
export class DevPanelSettingsService {
	private https: HttpClient;

	constructor(
		https: HttpClient,
		private storageService: SessionStorageService
	) {
		this.https = https;
	}

	getEcomProfile(): Observable<any> {
		return this.https.get<any>(`/ecom/profile`);
	}

	getEcomVersion(): Observable<any> {
		return this.https.get<any>(`/ecom/version`);
	}

	getEcomHealth(): Observable<any> {
		return this.https.get<any>(`/health`);
	}

	getEcomAPIStatus(path: string): Observable<any> {
		return this.https.get<any>(
			`/ecom` + path + this.storageService.getStoreId()
		);
	}
}
