import {
	HttpClientTestingModule,
	HttpTestingController,
} from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { BASE_PATH } from "../../bff-client";
import { environment } from "../../environments/environment";
import { DevPanelSettingsService } from "./dev-panel-settings.service";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("DevPanelSettingsService", () => {
	let httpTestingController: HttpTestingController;
	let service: DevPanelSettingsService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				DevPanelSettingsService,
				{ provide: BASE_PATH, useValue: environment.bffApiURl },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});

		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(DevPanelSettingsService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});
});
