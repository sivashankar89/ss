export const DevPanelInfo = {
	stores: [
		{
			id: "760995002",
			name: "Fiserv eCom Domain - Polcard",
			environments: ["test, test 2"],
			paymentMethods: [
				"Cards, 3DS, BLIK, Google Pay, Apple Pay, DCC, Currency PLN",
			],
		},
		{
			id: "120885001",
			name: "Fiserv eCom Domain - TeleCash",
			environments: ["test, test 2"],
			paymentMethods: ["Cards, 3DS, SEPA DD, Google Pay, DCC, Currency EUR"],
		},
		{
			id: "120885002",
			name: "Fiserv eCom Domain - Shopreme (TC)",
			environments: ["test, test 2"],
			paymentMethods: ["Cards, 3DS, SEPA DD, Google Pay, DCC, Currency EUR"],
		},
		{
			id: "11099500049",
			name: "Fiserv eCom Domain - Clover UK",
			environments: ["test, test 3"],
			paymentMethods: [
				"Cards, 3DS, PayPal, Tokenisation, Currency GBP, MCC 6012",
			],
		},
		{
			id: "120995000",
			name: "MANAGED STORE - IPG TEST STORE",
			environments: ["test, test 2, test 3"],
			paymentMethods: [
				"Cards, 3DS, SEPA DD, giropay, eps, iDEAL, Tokenisation, Scheduled recurring",
			],
		},
		{
			id: "640700300",
			name: "Accor Spain SIT 0",
			environments: ["test 2, test 3"],
			paymentMethods: [
				"Cards, 3DS, DCC, Tokenisation, Google Pay, Sofort, Currency EUR",
			],
		},
		{
			id: "812300001",
			name: "DEUTSCHE BANK JV-SIT TEST",
			environments: ["test 2"],
			paymentMethods: ["Cards, Currency EUR"],
		},
		{
			id: "81230000149",
			name: "e-Commerce DBJV TEST",
			environments: ["test 2"],
			paymentMethods: ["Cards, Currency EUR"],
		},
	],
	gatewayEnvironments: [
		{
			url: "https://test.ipg-online.com",
			ipg: "ipg-test",
			ecom: "ecom-ci",
		},
		{
			url: "https://test2.ipg-online.com",
			ipg: "ipg-test2",
			ecom: "ecom-uat",
		},
		{
			url: "https://test3.ipg-online.com",
			ipg: "ipg-test3",
			ecom: "ecom-dev",
		},
	],

	ecom_api: [
		{
			id: "1",
			name: "currencies",
			path: "/availableCurrencies/",
			status: false,
			result: [],
		},
		{
			id: "2",
			name: "brands",
			path: "/availableBrands/",
			status: false,
			result: [],
		},
		{
			id: "3",
			name: "isoCountries",
			path: "/availableCountries/",
			status: false,
			result: [],
		},
		{
			id: "4",
			name: "paymentMethods",
			path: "/availablePaymentMethods/",
			status: false,
			result: [],
		},
	],

	externalLinks: [
		{
			url: "https://emea.gitlab-pages.scm-emea.aws.fisv.cloud/CIO-DO/eCom/ecom-doc/",
			name: "dev_panel.ecom_arc",
		},
		{
			url: "https://ecom-tolgee.ecom-dev.app.whirlpool.aws.fisv.cloud/projects",
			name: "dev_panel.i18n_link",
		},
		{
			url: "https://escmconfluence.1dc.com/display/EDOM/IPG+Test+Stores",
			name: "dev_panel.ipg_test_stores",
		},
		{
			url: "https://escmconfluence.1dc.com/pages/viewpage.action?pageId=257398721",
			name: "dev_panel.ipg_test_data_general",
		},
		{
			url: "https://escmconfluence.1dc.com/display/SDD/Test+Data",
			name: "dev_panel.ipg_test_data_sepa",
		},
		{
			url: "https://escmconfluence.1dc.com/display/EDOM/Environment+Details",
			name: "dev_panel.env_details",
		},
	],
};
