import { VTPermissionCheckboxConfig } from "./dev-panel.model";
import { PaymentVTPermissions } from "./permissions.enum";

export const VT_PERMISSIONS_CHECKBOXES: VTPermissionCheckboxConfig[] = [
	{
		name: PaymentVTPermissions.VT_TRANSACTION_SALE,
		desc: "Allow to perform Sale transactions including the option to make a transaction recurring",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_TRANSACTION_SALE_NO_RECCURING,
		desc: "Allow to perform Sale transactions without the option to make a transaction recurring",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_PAYMENT_LINK,
		desc: "Allow to perform Sale with the payment link option",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_TRANSACTION_PREAUTH,
		desc: "Allow to perform a PreAuth transaction",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_TRANSACTION_COMPLETION,
		desc: "Allow to perform a Completion transaction",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_TRANSACTION_VOID,
		desc: "Allows Virtual Terminal user to perform a Void transaction",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_TRANSACTION_REFUND,
		desc: "Allows Virtual Terminal user to perform a Refund transaction",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_TRANSACTION_CREDIT,
		desc: "Allows Virtual Terminal user to perform a Credit transaction",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_ORDER_DETAILS_VIEW,
		desc: "Allow to see details of the order",
		type: "action",
		page: "Order Details",
	},
	{
		name: PaymentVTPermissions.VT_ORDER_DETAILS_MANAGE_SCHEDULE,
		desc: "Allow to cancel an existing scheduled recurring payment, and/or, edit an existing scheduled recurring payment.",
		type: "action",
		page: "Order Details",
	},
	{
		name: PaymentVTPermissions.VT_ORDER_DETAILS_ACTION_REFUND,
		desc: "Allow to perform a Refund from the Order Details screen",
		type: "action",
		page: "Order Details",
	},
	{
		name: PaymentVTPermissions.VT_ORDER_DETAILS_ACTION_VOID,
		desc: "Allow to perform a Void from the Order Details screen",
		type: "action",
		page: "Order Details",
	},
	{
		name: PaymentVTPermissions.VT_ORDER_DETAILS_ACTION_COMPLETION,
		desc: "Allow to perform Completion from Order Details screen",
		type: "action",
		page: "Order Details",
	},
	{
		name: PaymentVTPermissions.VT_CREATE_TOKEN,
		desc: "Allow the VT user to generate a token for a Card transaction for Sale, Pre-authorisation and Credit, and the ability to view the token in the Order Details screen",
		type: "action",
		page: "Transaction Screen - Card Payment option",
	},
	{
		name: PaymentVTPermissions.VT_TRANSACTION_USE_TOKEN,
		desc: "Allow the VT user to perform a Sale, Pre-auth and Credit transaction using a token",
		type: "action",
		page: "Transaction screen",
	},
	{
		name: PaymentVTPermissions.VT_NOTIFICATION_LANGUAGE,
		desc: "Allow the VT user to be setup in order to access the Notification language - All transaction types",
		type: "action",
		page: "Transaction screen",
	},
];
