import { PaymentVTPermissions } from "./permissions.enum";

export interface MyStoreData {
	storeId: string;
	storeName: string;
	baseLang: string;
}

export interface GatewayEnvironment {
	url: string;
	ipg: string;
	ecom: string;
}

export interface VTPermissionCheckboxConfig {
	name: PaymentVTPermissions;
	desc: string;
	type: string;
	page: string;
}
