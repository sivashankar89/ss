import {
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	OnInit,
	Output,
} from "@angular/core";
import { TranslateService } from "@tolgee/ngx";
import { Observable } from "rxjs";
import { TranslationService } from "utils/translation.service";
import { LocalStorageService } from "../utils/local-storage.service";
import { SessionStorageService } from "../utils/session-storage.service";
import { VT_PERMISSIONS_CHECKBOXES } from "./dev-panel-constants";
import { DevPanelInfo } from "./dev-panel-data";
import { DevPanelSettingsService } from "./dev-panel-settings.service";
import { VTPermissionCheckboxConfig } from "./dev-panel.model";
import { PaymentVTPermissions } from "./permissions.enum";

export interface Checks {
	name?: string;
	status?: string;
}

@Component({
	selector: "app-dev-panel-settings",
	templateUrl: "./dev-panel-settings.component.html",
	styleUrls: ["./dev-panel-settings.component.scss"],
})
export class DevPanelSettingsComponent implements OnInit, OnDestroy {
	@Input() isOpen = false;
	@Output() valueChange = new EventEmitter();
	readonly selectedLang$!: Observable<string>;
	selectedLang!: string;
	readonly selectedStore$!: Observable<string>;
	selectedStore!: string;
	readonly selectedGatewayEnvironment$!: Observable<string>;
	selectedGatewayEnvironment!: string;
	languages: any = [];
	devPanelInfo!: any;
	isSuccess = false;
	public userPermissions: Array<string> = [];
	readonly vtPermissionsList: VTPermissionCheckboxConfig[];

	storeId!: string;
	gatewayEnvironment!: string;
	langCode!: string;
	ecomHealthCheckList: Array<Checks> = [];
	ecomVersion!: string;
	ecomVersionCheckLoading = true;
	ecomHealthCheckListLoading = true;
	ecomAPICheckLoading = true;

	isClicked = false;
	accessibleStoreIds: string[] = [];

	constructor(
		private translationService: TranslationService,
		private localStorageService: LocalStorageService,
		private sessionStorageService: SessionStorageService,
		public translateService: TranslateService,
		private devPanelService: DevPanelSettingsService
	) {
		this.localStorageService.selectedLanguage.load();
		this.sessionStorageService.selectedGatewayEnvironment.load();

		this.vtPermissionsList = VT_PERMISSIONS_CHECKBOXES;

		this.selectedLang$ = localStorageService.selectedLanguage.obs$;
		this.selectedLang$.subscribe((data) => {
			this.selectedLang = data;
		});
		this.selectedStore$ = sessionStorageService.selectedStoreID.obs$;
		this.selectedStore$.subscribe((data) => {
			this.selectedStore = data;
		});
		this.selectedGatewayEnvironment$ =
			sessionStorageService.selectedGatewayEnvironment.obs$;
		this.selectedGatewayEnvironment$.subscribe((data) => {
			this.selectedGatewayEnvironment = data;
			if (this.selectedGatewayEnvironment) {
				this.gatewayEnvironment = this.selectedGatewayEnvironment;
			}
		});
	}

	ngOnInit(): void {
		this.devPanelService.getEcomVersion().subscribe({
			next: (res) => {
				this.ecomVersionCheckLoading = false;
				this.ecomVersion = res?.version;
			},
			error: () => {
				this.ecomVersionCheckLoading = false;
				this.ecomVersion = this.translateService.instantSafe(
					"general.message_went_wrong"
				);
			},
		});

		this.devPanelService.getEcomHealth().subscribe({
			next: (res) => {
				this.ecomHealthCheckListLoading = false;
				this.ecomHealthCheckList = res.checks;
			},
			error: (err) => {
				this.ecomHealthCheckListLoading = false;
				this.ecomHealthCheckList = err.error.checks
					? err.error.checks
					: [
							{
								name: this.translateService.instantSafe(
									"general.message_went_wrong"
								),
								checks: "DOWN",
							},
					  ];
			},
		});

		this.devPanelInfo = DevPanelInfo;

		const ecomApi = this.devPanelInfo.ecom_api;

		ecomApi.forEach((element: any) => {
			this.devPanelService.getEcomAPIStatus(element.path).subscribe({
				next: (res) => {
					this.ecomAPICheckLoading = false;
					element.status = true;
					element.result = JSON.stringify(
						this.ecomAPIResults(res, element.name),
						null,
						2
					);
				},
				error: () => {
					this.ecomAPICheckLoading = false;
					element.status = false;
					element.result = this.translateService.instantSafe(
						"general.message_went_wrong"
					);
				},
			});
		});

		this.translationService
			.fetchAvailableLanguagesList()
			.subscribe((lang: any) => {
				this.languages = lang._embedded.languages;
				if (this.selectedLang) {
					this.langCode = this.selectedLang;
				}
			});

		if (this.selectedStore) {
			this.storeId = this.selectedStore;
		}

		this.userPermissions = JSON.parse(
			window.sessionStorage.getItem("PORTAL_CORE_SSO_PERMISSIONS") || "{}"
		);
	}

	ecomAPIResults(response: any, type: string): any {
		switch (type) {
			case "currencies":
				return response?.map((x: any) => x?.literalCurrencyCode);
			case "brands":
				return response;
			case "isoCountries":
				return response?.map((x: any) =>
					this.translateService.instantSafe("countryISO." + x?.iso31661Alpha3)
				);
			case "paymentMethods":
				return response;
			default:
				return response;
		}
	}

	permissionsTracker(
		_: number,
		item: VTPermissionCheckboxConfig
	): PaymentVTPermissions {
		return item.name;
	}

	updateDevPanelInfo(): void {
		this.isSuccess = true;
		this.localStorageService.selectedLanguage.set(this.langCode);
		this.sessionStorageService.selectedStoreID.set(this.storeId);
		this.sessionStorageService.selectedGatewayEnvironment.set(
			this.gatewayEnvironment
		);
		window.sessionStorage.setItem(
			"PORTAL_CORE_SSO_PERMISSIONS",
			JSON.stringify(this.userPermissions)
		);

		this.accessibleStoreIds =
			this.sessionStorageService.accessibleStoreIds.value() || [];

		this.accessibleStoreIds.indexOf(this.storeId.toString()) == -1
			? this.accessibleStoreIds.push(this.storeId)
			: {};

		this.sessionStorageService.accessibleStoreIds.set(this.accessibleStoreIds);
		window.location.reload();
	}

	closeToast(): void {
		this.isSuccess = false;
	}

	languageChange(event: any): void {
		this.langCode = event;
	}

	storeChange(event: any): void {
		// The regex (/\s/g) matches to every whitespace - including those between words, and replaces them with empty string
		this.storeId = event.replace(/\s/g, "");
	}

	gatewayEnvironmentChange(event: any): void {
		this.gatewayEnvironment = event;
	}

	slidePanelChange(event: any): void {
		this.valueChange.emit(event);
	}

	onChangePermission(permission: string, checked: boolean): void {
		if (checked && !this.userPermissions.includes(permission)) {
			this.userPermissions.push(permission);
		}

		if (!checked && this.userPermissions.includes(permission)) {
			this.userPermissions = this.userPermissions.filter(
				(p) => p !== permission
			);
		}
	}

	goToLink(url: string) {
		window.open(url, "_blank");
	}

	ngOnDestroy(): void {
		this.isOpen = false;
	}
}
