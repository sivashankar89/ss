import { Injectable } from "@angular/core";
import { CdsSearchI18nService } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";

@Injectable()
export class SearchI18nService extends CdsSearchI18nService {
	constructor(private translate: TranslateService) {
		super();
	}
	getSearchText(): string {
		return this.translate.instantSafe("general.search");
	}
}
