import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, throwError } from "rxjs";
import {
	PaymentResponse,
	TransactionAmount,
	PaymentRequest,
	RequestType,
	PaymentBffService,
	TransactionAmountCurrencyEnum,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";
@Injectable({
	providedIn: "root",
})
export class CompletionService {
	private initAmount: TransactionAmount = {
		total: 0,
		currency: TransactionAmountCurrencyEnum.Aed,
		components: {},
	};
	private amount = new BehaviorSubject<TransactionAmount>(this.initAmount);
	public amount$ = this.amount.asObservable();
	isAmountPrePopulated = false;

	constructor(
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService
	) {}

	resetAmount(): void {
		this.amount.next(this.initAmount);
		this.isAmountPrePopulated = false;
	}

	setAmount(amount: TransactionAmount): void {
		this.amount.next(amount);
	}

	getAmount(): TransactionAmount {
		return this.amount.getValue();
	}

	/**
	 * getApiPayload
	 */
	public getApiPayload(): PaymentRequest {
		const amount = this.checkTransactionAmount(this.getAmount());
		return {
			requestType: RequestType.PostAuthTransaction,
			transactionAmount: amount,
		};
	}

	checkTransactionAmount(
		transactionAmount?: TransactionAmount
	): TransactionAmount {
		const amount = transactionAmount
			? JSON.parse(JSON.stringify(transactionAmount))
			: {};
		const returnZeroIfEmpty = (num: number | string): string => {
			if (typeof num === "number") {
				num = num.toString();
			}
			if (!num || num.trim() === "" || parseFloat(num) === 0) {
				return "0";
			}
			return num;
		};

		amount.total = returnZeroIfEmpty(amount.total);
		amount.currency = amount.currency || "";

		if (amount.components) {
			for (const key in amount.components) {
				amount.components[key] = returnZeroIfEmpty(amount.components[key]);
			}

			if (!amount.components["subtotal"]) {
				amount.components["subtotal"] = "0";
			}
		}

		return amount;
	}

	/**
	 * doPostAuth
	 */
	public postAuthStartTransaction(
		ipgTransactionId: string | undefined
	): Observable<PaymentResponse> {
		if (!ipgTransactionId) {
			return throwError(
				() => new Error(`ipgTransactionId not found for this transaction`)
			);
		}
		const paymentRequest = this.getApiPayload();
		return this.paymentBff.doSecondaryTransaction({
			authorizerId: this.storageService.getStoreId(),
			selectedGatewayServiceEnvironment:
				this.storageService.getGatewayEnvironment(),
			ipgTransactionId: ipgTransactionId,
			paymentRequestV2: paymentRequest,
		});
	}
}
