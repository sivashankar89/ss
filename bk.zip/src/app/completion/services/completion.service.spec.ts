import {
	HttpTestingController,
	HttpClientTestingModule,
} from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { BASE_PATH } from "bff-client";
import { environment } from "environments/environment";
import { PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE } from "mocks/payment_api/transactions.mock";
import { COMPLETION_TRANSACTION_MOCK } from "mocks/refund/refund.mock";
import { CompletionService } from "./completion.service";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("PaymentsPaymentsService", () => {
	let httpTestingController: HttpTestingController;
	let service: CompletionService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [
				CompletionService,
				{ provide: BASE_PATH, useValue: environment.bffApiURl },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});

		httpTestingController = TestBed.inject(HttpTestingController);
		service = TestBed.inject(CompletionService);
	});

	afterEach(() => {
		httpTestingController.verify();
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it("it should call the method setAmount and set amount ", () => {
		const mockAmount = PAYMENTS_SALE_TRANSACTION_MOCK_RESPONSE.approvedAmount;
		const apiSpy = jest.spyOn(service, "setAmount");
		if (mockAmount) {
			service.setAmount(mockAmount);
			expect(apiSpy).toHaveBeenCalledWith(mockAmount);
		}
	});

	it("it should call the method resetAmount", () => {
		const apiSpy = jest.spyOn(service, "resetAmount");
		service.resetAmount();
		expect(apiSpy).toHaveBeenCalled();
	});

	describe("postAuthStartTransaction", () => {
		it("it should return response with valid data", (done) => {
			service.postAuthStartTransaction("844750669949").subscribe((response) => {
				expect(response).toEqual(COMPLETION_TRANSACTION_MOCK);
				done();
			});

			httpTestingController
				.expectOne(environment.bffApiURl + "/payments/844750669949")
				.flush(COMPLETION_TRANSACTION_MOCK);
		});

		it("it should throw response error", (done) => {
			service.postAuthStartTransaction("844750669949").subscribe({
				error: (error) => {
					expect(error).toBeDefined();
					done();
				},
			});

			httpTestingController
				.expectOne(environment.bffApiURl + "/payments/844750669949")
				.error(new ErrorEvent("unknown error"));
		});
	});
});
