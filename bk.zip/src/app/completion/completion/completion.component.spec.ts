import { OverlayModule } from "@angular/cdk/overlay";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { TitleService } from "@international-payment-platform/portal-core";
import { DefaultTranspiler, TRANSLOCO_TRANSPILER } from "@ngneat/transloco";
import { CompletionStepperComponent } from "../page/completion-stepper/completion-stepper.component";

import { CompletionComponent } from "./completion.component";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

const TitleServiceStub: Partial<TitleService> = {
	setTitle: (titleLabel: string) => {},
};

describe("CompletionComponent", () => {
	let component: CompletionComponent;
	let fixture: ComponentFixture<CompletionComponent>;
	let modalService: CdsModalService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [OverlayModule, HttpClientTestingModule, RouterTestingModule],
			declarations: [CompletionComponent, CompletionStepperComponent],
			providers: [
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TRANSLOCO_TRANSPILER, useClass: DefaultTranspiler },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{
					provide: CdsModalService,
					useValue: {
						openModal: jest.fn(),
						closeModal: jest.fn(),
					},
				},
			],
			schemas: [NO_ERRORS_SCHEMA],
		})
			.overrideModule(BrowserDynamicTestingModule, {
				set: {
					entryComponents: [CompletionStepperComponent],
				},
			})
			.compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CompletionComponent);
		component = fixture.componentInstance;
		modalService = TestBed.inject(CdsModalService);
		jest.spyOn(TitleServiceStub, "setTitle");
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should close modal on destroy", fakeAsync(() => {
		jest.spyOn(modalService, "closeModal").mockReturnValue();
		component.ngOnDestroy();
		tick();
		expect(modalService.closeModal).toHaveBeenCalled();
	}));
});
