import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import {
	CdsListModule,
	CdsResultModule,
	CdsSearchI18nService,
} from "@international-payment-platform/design-system-angular";
import { CompletionStepperComponent } from "./page/completion-stepper/completion-stepper.component";
import { SharedModule } from "shared/shared.module";
import { DetailsFormComponent } from "./template/details-form/details-form.component";
import { ConfirmationScreenComponent } from "./template/confirmation-screen/confirmation-screen.component";
import { PreAuthSuccessDetailsComponent } from "./components/organism/pre-auth-success-details/pre-auth-success-details.component";
import { ConfirmationSuccessDetailsComponent } from "./components/organism/confirmation-success-details/confirmation-success-details.component";
import { ShippingDetailsComponent } from "./components/organism/shipping-details/shipping-details.component";
import { BillingDetailsComponent } from "./components/organism/billing-details/billing-details.component";
import { CompletionService } from "./services/completion.service";
import { CompletionResultsComponent } from "./template/completion-results/completion-results.component";
import { AmountCompletionInputComponent } from "./components/organism/amount-completion-input/amount-completion-input.component";
import { FormsModule } from "@angular/forms";
import { SearchI18nService } from "./services/search-i18n.service";
import { CompletionRoutingModule } from "./completion-routing.module";
import { CompletionComponent } from "./completion/completion.component";

@NgModule({
	declarations: [
		CompletionStepperComponent,
		DetailsFormComponent,
		ConfirmationScreenComponent,
		PreAuthSuccessDetailsComponent,
		ConfirmationSuccessDetailsComponent,
		ShippingDetailsComponent,
		BillingDetailsComponent,
		CompletionResultsComponent,
		AmountCompletionInputComponent,
		CompletionComponent,
	],
	imports: [
		CommonModule,
		FormsModule,
		CdsListModule,
		CdsResultModule,
		SharedModule,
		CompletionRoutingModule,
	],
	providers: [
		CompletionService,
		{
			provide: CdsSearchI18nService,
			useClass: SearchI18nService,
		},
	],
	exports: [DetailsFormComponent, ConfirmationSuccessDetailsComponent],
})
export class CompletionModule {}
