import {
	Component,
	EventEmitter,
	OnDestroy,
	OnInit,
	Output,
} from "@angular/core";
import { OrderDetailsService } from "../../../services/order-details.service";
import { CompletionResultsComponent } from "../../template/completion-results/completion-results.component";
import { ConfirmationScreenComponent } from "../../template/confirmation-screen/confirmation-screen.component";
import { DetailsFormComponent } from "../../template/details-form/details-form.component";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { StepInfo } from "model/common.model";

@Component({
	selector: "app-completion-stepper",
	templateUrl: "./completion-stepper.component.html",
})
export class CompletionStepperComponent implements OnDestroy {
	@Output() destroy = new EventEmitter();

	public steps: StepInfo[] = [
		{
			title: this.translate.instantSafe("completion.title_details"),
			component: DetailsFormComponent,
		},
		{
			title: this.translate.instantSafe("general.confirmation"),
			component: ConfirmationScreenComponent,
			back: true,
		},
		{
			title: this.translate.instantSafe("general.confirmation"),
			component: CompletionResultsComponent,
			hide: true,
			closeLabel: this.translate.instantSafe("general.close"),
		},
	];

	constructor(
		private orderDetailsService: OrderDetailsService,
		private titleService: TitleService,
		private translate: TranslateService
	) {}

	ngOnDestroy(): void {
		// Reset the order details when leaving the new transaction
		this.orderDetailsService.setOrderId("");
		this.titleService.setTitle("New transaction");
		this.orderDetailsService.isQueryOrderId.next(false);
		this.destroy.emit();
	}

	updateBrowserTitle(title: string): void {
		this.titleService.setTitle("Completion | " + title);
	}
}
