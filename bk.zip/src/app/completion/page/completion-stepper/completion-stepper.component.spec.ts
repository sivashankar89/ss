import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { OrderDetailsService } from "../../../services/order-details.service";
import { CompletionService } from "../../services/completion.service";
import { CompletionStepperComponent } from "./completion-stepper.component";
import { RouterTestingModule } from "@angular/router/testing";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

describe("CompletionStepperComponent", () => {
	let component: CompletionStepperComponent;
	let fixture: ComponentFixture<CompletionStepperComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [CompletionStepperComponent],
			imports: [HttpClientModule, RouterTestingModule, PipesMockModule],
			providers: [
				CompletionService,
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CompletionStepperComponent);
		component = fixture.componentInstance;
		jest.spyOn(TitleServiceStub, "setTitle");
		jest.spyOn(TranslateServiceStub, "instantSafe");
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should call the method ngOnDestroy ", () => {
		const param = "";
		const appService = fixture.debugElement.injector.get(OrderDetailsService);
		jest.spyOn(component, "ngOnDestroy");
		component.ngOnDestroy();
		appService.setOrderId(param);
		fixture.detectChanges();
		expect(component.ngOnDestroy).toHaveBeenCalled();
		expect(appService.setOrderId("")).toBe(undefined);
	});

	it("THEN should set title", () => {
		component.updateBrowserTitle("Completion");
		expect(TitleServiceStub.setTitle).toHaveBeenCalled();
	});
});
