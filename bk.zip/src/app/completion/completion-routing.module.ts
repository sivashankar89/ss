import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { PermissionGuardService } from "services/permission-guard.service";
import { CompletionComponent } from "./completion/completion.component";

const routes = [
	{
		path: "",
		component: CompletionComponent,
		data: {
			permissions: [VTPaymentPermissions.EcomVTTransactionCompletion],
		},
		canActivate: [PermissionGuardService],
	},
	{
		path: ":id",
		component: CompletionComponent,
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class CompletionRoutingModule {}
