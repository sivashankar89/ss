import { Component, Input } from "@angular/core";
import { OrderDetailsResponse } from "bff-client";
@Component({
	selector: "app-shipping-details",
	templateUrl: "./shipping-details.component.html",
	styleUrls: ["./shipping-details.component.scss"],
})
export class ShippingDetailsComponent {
	@Input() shipping!: OrderDetailsResponse | undefined;
}
