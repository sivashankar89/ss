import { ShippingDetailsComponent } from "./shipping-details.component";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";

import { BillingAddressComponent } from "../../../../shared/components/molecules/billing-address/billing-address.component";
import { ContactDetailsComponent } from "../../../../shared/components/molecules/contact-details/contact-details.component";
import { DividerComponent } from "../../../../shared/components/atoms/divider/divider.component";
import { transactionsObj } from "../../../../../mocks/constant";
import { HttpClient, HttpHandler } from "@angular/common/http";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

describe("BillingDetailsComponent", () => {
	let component: ShippingDetailsComponent;
	let fixture: ComponentFixture<ShippingDetailsComponent>;
	let shippingAddressComponent: BillingAddressComponent;
	let billingAddressFixture: ComponentFixture<BillingAddressComponent>;
	let contactDetailsComponent: ContactDetailsComponent;
	let contactDetailsFixture: ComponentFixture<ContactDetailsComponent>;
	let dividerComponent: DividerComponent;
	let dividerFixture: ComponentFixture<DividerComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [
				ShippingDetailsComponent,
				DividerComponent,
				BillingAddressComponent,
				ContactDetailsComponent,
			],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [HttpClient, HttpHandler],
			imports: [PipesMockModule],
		});
		fixture = TestBed.createComponent(ShippingDetailsComponent);
		billingAddressFixture = TestBed.createComponent(BillingAddressComponent);
		contactDetailsFixture = TestBed.createComponent(ContactDetailsComponent);
		dividerFixture = TestBed.createComponent(DividerComponent);
		dividerComponent = dividerFixture.componentInstance;
		component = fixture.componentInstance;
		shippingAddressComponent = billingAddressFixture.componentInstance;
		contactDetailsComponent = contactDetailsFixture.componentInstance;
	});

	test("should create instance", () => {
		expect(component).toBeDefined();
		expect(shippingAddressComponent).toBeDefined();
		expect(contactDetailsComponent).toBeDefined();
		expect(dividerComponent).toBeDefined();
		expect(fixture).toMatchSnapshot();
		expect(billingAddressFixture).toMatchSnapshot();
		expect(contactDetailsFixture).toMatchSnapshot();
		expect(dividerFixture).toMatchSnapshot();
	});

	test("should pass delivery and contact address with  data", () => {
		const shippingoBj: any = transactionsObj?.shipping;
		const contactObj: any = transactionsObj?.contact;

		shippingAddressComponent.address = transactionsObj?.shipping;
		contactDetailsComponent.contact = transactionsObj?.contact;
		contactDetailsComponent.address = transactionsObj?.shipping;
		expect(fixture).toMatchSnapshot();
		expect(billingAddressFixture).toMatchSnapshot();
		expect(contactDetailsFixture).toMatchSnapshot();
		fixture.detectChanges();
		billingAddressFixture.detectChanges();
		contactDetailsFixture.detectChanges();
		expect(shippingAddressComponent.address).toEqual(shippingoBj);
		expect(contactDetailsComponent.contact).toEqual(contactObj);
		expect(contactDetailsComponent.address).toEqual(shippingoBj);
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
