import { Component, Input } from "@angular/core";
import { OrderDetailsResponse } from "bff-client";

@Component({
	selector: "app-billing-details",
	templateUrl: "./billing-details.component.html",
	styleUrls: ["./billing-details.component.scss"],
})
export class BillingDetailsComponent {
	@Input() billing!: OrderDetailsResponse | undefined;
}
