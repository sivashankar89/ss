import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";

import { BillingDetailsComponent } from "./billing-details.component";
import { BillingAddressComponent } from "shared/components/molecules/billing-address/billing-address.component";
import { ContactDetailsComponent } from "shared/components/molecules/contact-details/contact-details.component";
import { DividerComponent } from "shared/components/atoms/divider/divider.component";
import { transactionsObj } from "../../../../../mocks/constant";
import { HttpClient, HttpHandler } from "@angular/common/http";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

describe("BillingDetailsComponent", () => {
	let component: BillingDetailsComponent;
	let fixture: ComponentFixture<BillingDetailsComponent>;
	let billingAddressComponent: BillingAddressComponent;
	let billingAddressFixture: ComponentFixture<BillingAddressComponent>;
	let contactDetailsComponent: ContactDetailsComponent;
	let contactDetailsFixture: ComponentFixture<ContactDetailsComponent>;
	let dividerComponent: DividerComponent;
	let dividerFixture: ComponentFixture<DividerComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [
				BillingDetailsComponent,
				DividerComponent,
				BillingAddressComponent,
				ContactDetailsComponent,
			],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [HttpClient, HttpHandler],
			imports: [PipesMockModule],
		});
		fixture = TestBed.createComponent(BillingDetailsComponent);
		billingAddressFixture = TestBed.createComponent(BillingAddressComponent);
		contactDetailsFixture = TestBed.createComponent(ContactDetailsComponent);
		dividerFixture = TestBed.createComponent(DividerComponent);
		dividerComponent = dividerFixture.componentInstance;
		component = fixture.componentInstance;
		billingAddressComponent = billingAddressFixture.componentInstance;
		contactDetailsComponent = contactDetailsFixture.componentInstance;
	});

	test("should create instance", () => {
		expect(component).toBeDefined();
		expect(billingAddressComponent).toBeDefined();
		expect(contactDetailsComponent).toBeDefined();
		expect(dividerComponent).toBeDefined();
		expect(fixture).toMatchSnapshot();
		expect(billingAddressFixture).toMatchSnapshot();
		expect(contactDetailsFixture).toMatchSnapshot();
		expect(dividerFixture).toMatchSnapshot();
	});

	test("should pass Billig and contact address with mock data", () => {
		const billingObJ = transactionsObj?.billing;
		const contactObj = transactionsObj?.contact;
		billingAddressComponent.address = transactionsObj?.billing;
		contactDetailsComponent.contact = transactionsObj?.contact;
		contactDetailsComponent.address = transactionsObj.billing;
		expect(fixture).toMatchSnapshot();
		expect(billingAddressFixture).toMatchSnapshot();
		expect(contactDetailsFixture).toMatchSnapshot();
		fixture.detectChanges();
		billingAddressFixture.detectChanges();
		contactDetailsFixture.detectChanges();
		expect(billingAddressComponent.address).toEqual(billingObJ);
		expect(contactDetailsComponent.contact).toEqual(contactObj);
		expect(contactDetailsComponent.address).toEqual(billingObJ);
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
