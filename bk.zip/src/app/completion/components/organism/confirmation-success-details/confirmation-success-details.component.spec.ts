import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import {
	COMPLETION_MOCK_RESPONSE,
	COMPLETION_TRANSACTION_MOCK,
} from "mocks/refund/refund.mock";
import { CompletionService } from "../../../services/completion.service";
import { ConfirmationSuccessDetailsComponent } from "./confirmation-success-details.component";
import { TransactionType } from "bff-client";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

describe("ConfirmationSuccessDetailsComponent", () => {
	let component: ConfirmationSuccessDetailsComponent;
	let fixture: ComponentFixture<ConfirmationSuccessDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [ConfirmationSuccessDetailsComponent],
			providers: [CompletionService],
			schemas: [NO_ERRORS_SCHEMA],
			imports: [HttpClientModule, PipesMockModule],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(ConfirmationSuccessDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
		expect(fixture).toMatchSnapshot();
	});

	it("it should check the completion valid response", () => {
		component.order = COMPLETION_MOCK_RESPONSE;
		component.ngOnChanges();
		fixture.detectChanges();
		expect(component.transaction).toEqual(COMPLETION_TRANSACTION_MOCK);
		expect(fixture).toMatchSnapshot();
	});

	it("it should check the completion invalid", () => {
		const mockResponse = { ...COMPLETION_MOCK_RESPONSE };
		mockResponse.transactions[0].transactionType = TransactionType.Sale;
		component.order = mockResponse;
		component.ngOnChanges();
		fixture.detectChanges();
		expect(component.transaction).toBeUndefined();
		expect(fixture).toMatchSnapshot();
	});
});
