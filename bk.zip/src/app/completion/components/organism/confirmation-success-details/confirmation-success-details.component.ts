import { Component, Input, OnChanges } from "@angular/core";
import {
	OrderDetailsResponse,
	PaymentResponse,
	TransactionAmount,
} from "bff-client";
import { getValidPreAuthTransaction } from "utils/order-details.utils";
import { VTPaymentPermissions } from "enum/permissions.enum";
@Component({
	selector: "app-confirmation-success-details",
	templateUrl: "./confirmation-success-details.component.html",
	styleUrls: ["./confirmation-success-details.component.scss"],
})
export class ConfirmationSuccessDetailsComponent implements OnChanges {
	@Input() order!: OrderDetailsResponse;
	@Input() amount!: TransactionAmount | undefined | null;
	public transaction?: PaymentResponse;
	paymentPermissions = VTPaymentPermissions;

	ngOnChanges(): void {
		try {
			this.transaction = getValidPreAuthTransaction(this.order);
		} catch (e) {
			this.transaction = undefined;
		}
	}
}
