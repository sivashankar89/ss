import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { PreAuthSuccessDetailsComponent } from "./pre-auth-success-details.component";

describe("PreAuthSuccessDetailsComponent", () => {
	let component: PreAuthSuccessDetailsComponent;
	let fixture: ComponentFixture<PreAuthSuccessDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PreAuthSuccessDetailsComponent],
			schemas: [NO_ERRORS_SCHEMA],
			imports: [HttpClientModule, PipesMockModule],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PreAuthSuccessDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("it should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});
});
