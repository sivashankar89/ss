import { Component, Input } from "@angular/core";
import { PaymentResponse } from "bff-client";

@Component({
	selector: "app-pre-auth-success-details",
	templateUrl: "./pre-auth-success-details.component.html",
	styleUrls: ["./pre-auth-success-details.component.scss"],
})
export class PreAuthSuccessDetailsComponent {
	@Input() transaction!: PaymentResponse;
}
