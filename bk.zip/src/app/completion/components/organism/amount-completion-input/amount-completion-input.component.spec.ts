import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule } from "@angular/forms";
import { TransactionAmountCurrencyEnum } from "bff-client";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { COMPLETION_TRANSACTION_MOCK } from "mocks/refund/refund.mock";
import { CompletionService } from "../../../services/completion.service";
import { AmountCompletionInputComponent } from "./amount-completion-input.component";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("AmountCompletionInputComponent", () => {
	let component: AmountCompletionInputComponent;
	let fixture: ComponentFixture<AmountCompletionInputComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [AmountCompletionInputComponent],
			providers: [
				CompletionService,
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			imports: [FormsModule, HttpClientModule, PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(AmountCompletionInputComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
		expect(fixture).toMatchSnapshot();
	});

	it("it should render the amount input", () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-amount-input-box"
		);
	});

	describe("amount completion update amount", () => {
		const param = { key: "subtotal", value: "10" };
		it("it should call the method updateAmount ", () => {
			jest.spyOn(component, "updateAmount");
			component.updateAmount(param.key, param.value);
			fixture.detectChanges();
			expect(component.updateAmount).toHaveBeenCalled();
		});

		it("it should call the method updateAmount for emitting false ", () => {
			jest.spyOn(component, "updateAmount");
			component.maxAmount = 8;
			component.updateAmount(param.key, param.value);
			fixture.detectChanges();
			expect(component.updateAmount).toHaveBeenCalled();
		});
	});

	it("it should check the amount input method", () => {
		const input = { total: 10.24, currency: TransactionAmountCurrencyEnum.Usd };
		component.transaction = COMPLETION_TRANSACTION_MOCK;
		component.ngOnChanges();
		fixture.detectChanges();
		expect(component.maxAmount).toEqual(input.total);
		expect(component.currency).toEqual(input.currency);
	});
});
