import {
	Component,
	EventEmitter,
	Input,
	OnChanges,
	Output,
	ViewChild,
} from "@angular/core";
import { NgForm } from "@angular/forms";
import {
	PaymentResponse,
	TransactionAmountComponents,
	TransactionAmountCurrencyEnum,
} from "bff-client";
import { combineLatest, debounceTime, of, Subject, takeUntil } from "rxjs";
import { getTotalAmount } from "utils/common.utils";
import { CompletionService } from "../../../../completion/services/completion.service";

@Component({
	selector: "app-amount-completion-input",
	templateUrl: "./amount-completion-input.component.html",
	styleUrls: ["./amount-completion-input.component.scss"],
})
export class AmountCompletionInputComponent implements OnChanges {
	@Input() transaction!: PaymentResponse;
	@Output() validChange = new EventEmitter();
	@ViewChild("amountForm") amountForm!: NgForm;
	@Input() resultFocus = false;

	public maxAmount!: number;
	public currency!: TransactionAmountCurrencyEnum;
	private destroy = new Subject();

	constructor(public completionService: CompletionService) {}

	ngOnChanges(): void {
		if (this.transaction?.approvedAmount) {
			const tAmount = this.transaction.approvedAmount;
			this.maxAmount = tAmount.total || 0;
			this.currency = tAmount.currency || "";
			if (!this.completionService.isAmountPrePopulated) {
				if (tAmount.components?.subtotal) {
					this.updateAmount("subtotal", tAmount.components?.subtotal);
				}
				if (tAmount.components?.shipping) {
					this.updateAmount("shipping", tAmount.components?.shipping);
				}
				if (tAmount.components?.vatAmount) {
					this.updateAmount("vatAmount", tAmount.components?.vatAmount);
				}
			}
			this.completionService.isAmountPrePopulated = true;
		}
	}

	ngAfterViewInit(): void {
		combineLatest([
			this.amountForm.statusChanges ?? of(null),
			this.completionService.amount$,
		])
			.pipe(debounceTime(300), takeUntil(this.destroy))
			.subscribe(([status, amount]) => {
				if (status === null || status === "INVALID") {
					this.validChange.emit(false);
					return;
				}
				if (this.maxAmount < amount.total || amount.total === 0) {
					this.validChange.emit(false);
				} else {
					this.validChange.emit(true);
				}
			});
	}

	ngOnDestroy(): void {
		this.destroy.next("");
		this.destroy.complete();
	}

	updateAmount(key: string, value: string | number): void {
		this.validChange.emit(false);
		const amount = this.completionService.getAmount();
		const numValue: number =
			typeof value === "number" ? value : parseFloat(value);
		const components = {
			...(amount && amount.components ? amount.components : {}),
			[key]: isNaN(numValue) ? 0 : numValue,
		};
		const total = components ? getTotalAmount(components) : 0;
		this.completionService.setAmount({
			total,
			components,
			currency: this.currency,
		});
	}
}
