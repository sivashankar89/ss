import { OverlayModule } from "@angular/cdk/overlay";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { CompletionService } from "../../services/completion.service";

import { ConfirmationScreenComponent } from "./confirmation-screen.component";
import { TelemetryService } from "services/telemetry.service";
import { TelemetryServiceStub } from "mocks/services/services.mock";

describe("ConfirmationScreenComponent", () => {
	let component: ConfirmationScreenComponent;
	let fixture: ComponentFixture<ConfirmationScreenComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [ConfirmationScreenComponent],
			providers: [
				StepperFullScreenComponent,
				CompletionService,
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			imports: [
				HttpClientModule,
				OverlayModule,
				RouterTestingModule,
				PipesMockModule,
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(ConfirmationScreenComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should call the method goBack ", () => {
		const stepperComponent = TestBed.inject(StepperFullScreenComponent);
		stepperComponent.goBack = jest.fn();
		const transactionSpy = jest.spyOn(component, "goBack");
		component.goBack();
		expect(transactionSpy).toHaveBeenCalled();
	});

	it("it should call the method confirmPayment ", () => {
		const steppercomponent = TestBed.inject(StepperFullScreenComponent);
		steppercomponent.goNext = jest.fn();
		const transactionSpy = jest.spyOn(component, "confirmPayment");
		component.confirmPayment();
		expect(transactionSpy).toHaveBeenCalled();
	});
});
