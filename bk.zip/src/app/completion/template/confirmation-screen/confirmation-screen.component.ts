import {
	AfterViewInit,
	Component,
	OnInit,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { Observable } from "rxjs";
import { OrderDetailsResponse, TransactionAmount } from "bff-client";
import { WithLoadingError } from "../../../model/common.model";
import { OrderDetailsService } from "../../../services/order-details.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { CompletionService } from "../../services/completion.service";

@Component({
	selector: "app-confirmation-screen",
	templateUrl: "./confirmation-screen.component.html",
	styleUrls: ["./confirmation-screen.component.scss"],
})
export class ConfirmationScreenComponent implements OnInit, AfterViewInit {
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;

	public orderDetails$!: Observable<WithLoadingError<OrderDetailsResponse>>;
	public amount$!: Observable<TransactionAmount>;

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private orderDetailsService: OrderDetailsService,
		private completionService: CompletionService
	) {}

	ngOnInit(): void {
		this.orderDetails$ = this.orderDetailsService.orderDetails$;
		this.amount$ = this.completionService.amount$;
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	goBack(): void {
		this.stepperComponent.goBack();
	}

	confirmPayment(): void {
		this.stepperComponent.goNext();
	}
}
