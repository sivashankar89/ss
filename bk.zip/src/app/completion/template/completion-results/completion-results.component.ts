import {
	AfterViewInit,
	Component,
	Input,
	OnDestroy,
	OnInit,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { map, Subscription, switchMap } from "rxjs";
import { ApiErrorResponse } from "model/error.model";
import { StepperFullScreenComponent } from "shared/template/stepper-full-screen/stepper-full-screen.component";
import { OrderDetailsService } from "services/order-details.service";
import { getValidPreAuthTransaction } from "utils/order-details.utils";
import {
	AuthenticationService,
	TitleService,
} from "@international-payment-platform/portal-core";
import { CompletionService } from "completion/services/completion.service";
import { TranslateService } from "@tolgee/ngx";
import { PaymentResponse } from "bff-client";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";

@Component({
	selector: "app-completion-results",
	templateUrl: "./completion-results.component.html",
	styleUrls: ["./completion-results.component.scss"],
})
export class CompletionResultsComponent
	implements OnInit, OnDestroy, AfterViewInit
{
	@ViewChild("modalFooterOptionalPrimaryBtn", { read: TemplateRef })
	modalFooterOptionalPrimaryBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	@Input() transaction: any;

	public subscription!: Subscription;
	public isLoading = true;
	public completeTransaction!: PaymentResponse;
	public completionAmount = "";
	public isValidForAnotherCompletion = true;
	public error!: PaymentResponse | undefined;
	transactionOrderId!: string;
	showViewTreansaction = true;

	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private modalService: CdsModalService,
		private orderDetailsService: OrderDetailsService,
		private completionService: CompletionService,
		private titleService: TitleService,
		private translate: TranslateService,
		private authenticationService: AuthenticationService,
		private openOrderDetailsService: OpenOrderDetailsService
	) {}

	ngOnInit(): void {
		this.completionTransaction();
		this.orderDetailsService.isQueryOrderId$.subscribe((data) => {
			this.isValidForAnotherCompletion = !data;
		});
		this.showViewTreansaction = this.authenticationService
			.getPermissions()
			.includes(VTPaymentPermissions.EcomVTOrderDetailsView);
	}

	completionTransaction(): void {
		this.subscription = this.orderDetailsService.orderDetails$
			.pipe(
				map((order) => {
					const transaction = getValidPreAuthTransaction(order.value);
					this.transactionOrderId = order?.value?.orderId || "";
					return transaction;
				}),
				switchMap((transaction) => {
					return this.completionService.postAuthStartTransaction(
						transaction?.ipgTransactionId
					);
				})
			)
			.subscribe({
				next: (res) => {
					this.isLoading = false;
					if (res.error) {
						this.titleService.setTitle(
							`${this.translate.instantSafe(
								"app.title_completion"
							)} | ${this.translate.instantSafe("general.unsuccess_message")}`
						);
						this.error = res;
					} else {
						this.titleService.setTitle(
							`${this.translate.instantSafe(
								"app.title_completion"
							)} | ${this.translate.instantSafe("general.success_message")}`
						);
						this.completeTransaction = res;
					}
				},
				error: (err) => {
					this.titleService.setTitle(
						`${this.translate.instantSafe(
							"app.title_completion"
						)} | ${this.translate.instantSafe("general.unsuccess_message")}`
					);
					this.isLoading = false;
					this.error = err?.error;
				},
			});
	}

	ngOnDestroy(): void {
		this.subscription.unsubscribe();
		this.reset();
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			OptPrimaryBtn: this.modalFooterOptionalPrimaryBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	reset(): void {
		this.orderDetailsService.setOrderId("");
		this.completionService.resetAmount();
	}

	closeModal(): void {
		this.modalService.closeModal();
	}

	newTransaction(): void {
		this.reset();
		this.stepperComponent.goStep(0);
	}

	viewTransaction(): void {
		this.openOrderDetailsService.openOrderDetailsModal(this.transactionOrderId);
	}
}
