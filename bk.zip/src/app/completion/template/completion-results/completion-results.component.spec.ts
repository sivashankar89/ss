import { OverlayModule } from "@angular/cdk/overlay";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { OrderDetailsService } from "../../../services/order-details.service";
import { CompletionService } from "../../services/completion.service";
import { CompletionResultsComponent } from "./completion-results.component";
import { of, throwError } from "rxjs";
import { OpenOrderDetailsService } from "../../../order-details/services/open-order-details.service";
import { COMPLETION_MOCK_RESPONSE } from "mocks/refund/refund.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { TitleService } from "@international-payment-platform/portal-core";
import { RouterTestingModule } from "@angular/router/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

const orderDetailsMock = {
	loading: false,
	value: COMPLETION_MOCK_RESPONSE,
};
describe("CompletionResultsComponent", () => {
	let component: CompletionResultsComponent;
	let fixture: ComponentFixture<CompletionResultsComponent>;

	beforeAll(() => {
		Object.defineProperty(window, "location", {
			value: { assign: jest.fn() },
		});
	});

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [CompletionResultsComponent],
			providers: [
				CdsModalService,
				OrderDetailsService,
				CompletionService,
				StepperFullScreenComponent,
				OpenOrderDetailsService,
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			imports: [
				HttpClientModule,
				OverlayModule,
				PipesMockModule,
				RouterTestingModule,
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CompletionResultsComponent);
		component = fixture.componentInstance;
		jest.spyOn(TitleServiceStub, "setTitle");
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should throw error for invalid response from API", () => {
		const appService = TestBed.inject(OrderDetailsService);
		appService.orderDetails$ = of(orderDetailsMock);
		const postAPI = TestBed.inject(CompletionService);
		postAPI.postAuthStartTransaction = jest.fn().mockReturnValue(
			throwError(() => ({
				error: {
					error: {
						code: "Invalid",
						message: "Invalid Response from API",
					},
					orderId: "123eredfgd",
				},
			}))
		);
		component.completionTransaction();
		fixture.detectChanges();
		expect(component.isLoading).toBe(false);
		expect(component.completeTransaction).toBeUndefined();
		expect(component.transactionOrderId).toBeTruthy();
		expect(component.error).toBeDefined();
	});

	it("it should call http post with valid response", fakeAsync(() => {
		const appService = TestBed.inject(OrderDetailsService);
		appService.orderDetails$ = of(orderDetailsMock);
		const postAPI = fixture.debugElement.injector.get(CompletionService);
		postAPI.postAuthStartTransaction = jest
			.fn()
			.mockReturnValue(of(orderDetailsMock.value));
		component.completionTransaction();
		tick();
		expect(component.isLoading).toBe(false);
		expect(component.completeTransaction).toBeDefined();
		expect(component.transactionOrderId).toBeTruthy();
		expect(component.error).toBeUndefined();
	}));

	it("should run close modal method", () => {
		const service = TestBed.inject(CdsModalService);
		service.closeModal = jest.fn();
		component.closeModal();
		expect(service.closeModal).toHaveBeenCalled();
	});

	it("it should call the method newTransaction ", () => {
		const steppercomponent = TestBed.inject(StepperFullScreenComponent);
		steppercomponent.goBack = jest.fn();
		const transactionSpy = jest.spyOn(component, "newTransaction");
		component.newTransaction();
		expect(transactionSpy).toHaveBeenCalled();
	});

	it("should run viewTransaction method", () => {
		const service = TestBed.inject(OpenOrderDetailsService);
		service.openOrderDetailsModal = jest.fn();
		component.viewTransaction();
		expect(service.openOrderDetailsModal).toHaveBeenCalled();
	});
});
