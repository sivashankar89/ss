import {
	AfterViewInit,
	Component,
	EventEmitter,
	OnInit,
	Output,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { map, Observable, tap } from "rxjs";
import { WithLoadingError } from "../../../model/common.model";
import { getValidPreAuthTransaction } from "../../../utils/order-details.utils";
import { OrderDetailsService } from "../../../services/order-details.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { ApiErrorMessage } from "model/error.model";
import { throwInvalidOrderErrorMessage } from "utils/common.utils";
import { TranslateService } from "@tolgee/ngx";
import { OrderDetailsResponse, PaymentResponse } from "bff-client";
import { CompletionService } from "completion/services/completion.service";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";

@Component({
	selector: "app-details-form",
	templateUrl: "./details-form.component.html",
	styleUrls: ["./details-form.component.scss"],
})
export class DetailsFormComponent implements OnInit, AfterViewInit {
	@ViewChild("modalFooterLinkBtn", { read: TemplateRef })
	modalFooterLinkBtn!: TemplateRef<any>;
	@ViewChild("modalFooterPrimaryBtn", { read: TemplateRef })
	modalFooterPrimaryBtn!: TemplateRef<any>;
	@Output() buttonRefs = new EventEmitter();

	public isValidTab = false;
	public orderDetails$!: Observable<WithLoadingError<OrderDetailsResponse>>;
	public transaction?: PaymentResponse;
	public orderId = "";
	public isOrderValid = false;
	public isQueryOrderId = false;
	public title = "Find pre-authorisation";
	searchInputFocus = true;
	afterSearchFocus = false;
	constructor(
		private stepperComponent: StepperFullScreenComponent,
		private orderDetailsService: OrderDetailsService,
		private translate: TranslateService,
		public completionService: CompletionService,
		private openOrderDetailsService: OpenOrderDetailsService
	) {}

	ngOnInit(): void {
		this.title = `${this.translate.instantSafe(
			"general.find"
		)} ${this.translate.instantSafe("pre-auth._preauth")}`;
		this.orderId = this.orderDetailsService.getOrderId();
		this.orderDetailsService.isQueryOrderId$.subscribe((data) => {
			if (data) {
				this.isQueryOrderId = data;
			}
		});
		this.orderDetails$ = this.orderDetailsService.orderDetails$.pipe(
			tap(() => {
				this.isValidTab = false;
			}),
			map((order) => {
				try {
					if (order.error) {
						this.isOrderValid = false;
						throwInvalidOrderErrorMessage(order.error.code);
					} else if (order.value) {
						this.isOrderValid = true;
						this.searchInputFocus = false;
						this.afterSearchFocus = true;
						this.transaction = getValidPreAuthTransaction(order.value);
					} else {
						this.transaction = undefined;
					}
				} catch (e: any) {
					delete order.value;
					e.message = this.translate.instantSafe(e.message);
					order.error = e as ApiErrorMessage;
				}
				return order;
			})
		);
	}

	ngAfterViewInit(): void {
		this.stepperComponent.loadFooterTemplateRefs({
			linkBtn: this.modalFooterLinkBtn,
			primaryBtn: this.modalFooterPrimaryBtn,
		});
	}

	searchOrder(orderId: string): void {
		orderId = orderId.trim();
		this.orderId = orderId;
		this.completionService.resetAmount();
		this.orderDetailsService.setOrderId(orderId);
	}

	goNext(): void {
		this.stepperComponent.goNext();
	}

	validChange(valid: boolean): void {
		this.isValidTab = valid;
	}

	viewTransaction(): void {
		this.openOrderDetailsService.openOrderDetailsModal(this.orderId);
	}
}
