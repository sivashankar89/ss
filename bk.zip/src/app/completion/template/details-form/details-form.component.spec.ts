import { OverlayModule } from "@angular/cdk/overlay";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { TranslateService } from "@tolgee/ngx";
import { TransactionType } from "bff-client";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	COMPLETION_MOCK_RESPONSE,
	COMPLETION_TRANSACTION_MOCK,
} from "mocks/refund/refund.mock";
import {
	OpenOrderDetailsServiceStub,
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";
import { of, throwError } from "rxjs";
import { OrderDetailsService } from "../../../services/order-details.service";
import { StepperFullScreenComponent } from "../../../shared/template/stepper-full-screen/stepper-full-screen.component";
import { DetailsFormComponent } from "./details-form.component";
import { TelemetryService } from "services/telemetry.service";

const orderDetailsMock = {
	loading: false,
	value: COMPLETION_MOCK_RESPONSE,
};

describe("DetailsFormComponent", () => {
	let component: DetailsFormComponent;
	let fixture: ComponentFixture<DetailsFormComponent>;
	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [
				HttpClientModule,
				OverlayModule,
				RouterTestingModule,
				PipesMockModule,
			],
			providers: [
				StepperFullScreenComponent,
				OrderDetailsService,
				{
					provide: OpenOrderDetailsService,
					useValue: OpenOrderDetailsServiceStub,
				},
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			declarations: [DetailsFormComponent],
			schemas: [NO_ERRORS_SCHEMA],
		});
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(DetailsFormComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("it should render the input", () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-search-order-input"
		);
	});

	it("it should call the method searchOrder ", () => {
		const param = "12345";
		const searchOrderSpy = jest.spyOn(component, "searchOrder");
		component.searchOrder(param);
		expect(searchOrderSpy).toHaveBeenCalledWith(param);
	});

	it("it should throw error for invalid input from API", fakeAsync(() => {
		const appService = TestBed.inject(OrderDetailsService);
		appService.getOrderDetails = jest.fn().mockReturnValue(
			throwError(() => ({
				error: {
					error: {
						code: "INVALID",
						message:
							"The order Id entered is invalid. Please enter a valid Order ID.",
					},
				},
			}))
		);
		component.searchOrder("testinput");
		component.orderDetails$.subscribe();
		tick(1000);
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
	}));

	it("it should handle return preauth error order", fakeAsync(() => {
		const appService = fixture.debugElement.injector.get(OrderDetailsService);
		appService.getOrderDetails = jest.fn().mockReturnValue(
			throwError(() => ({
				error: {
					error: {
						code: "NOT_PRE_AUTH",
						message:
							"The orderID entered cannot be procedd for completion. Please enter a valid Order ID.",
					},
				},
			}))
		);

		component.searchOrder("testinput");
		fixture.detectChanges();
		component.orderDetails$.subscribe();
		tick(1000);
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
	}));

	it("it should call the method goNext ", () => {
		jest.spyOn(component, "goNext");
		component.goNext();
		expect(component.goNext).toHaveBeenCalled();
	});

	it("it should call the method validChange ", () => {
		jest.spyOn(component, "validChange");
		component.validChange(true);
		expect(component.validChange).toHaveBeenCalledWith(true);
		expect(component.isValidTab).toBeTruthy();
	});

	it("it should call order details with valid response", () => {
		const appService = fixture.debugElement.injector.get(OrderDetailsService);
		appService.orderDetails$ = of(orderDetailsMock).pipe();
		component.ngOnInit();
		fixture.detectChanges();
		component.orderDetails$.subscribe();
		expect(component.transaction).toEqual(COMPLETION_TRANSACTION_MOCK);
		expect(fixture).toMatchSnapshot();
	});

	it("it should call order details with error response", () => {
		const mockResponse = { ...COMPLETION_MOCK_RESPONSE };
		mockResponse.transactions[0].transactionType = TransactionType.Sale;
		const appService = fixture.debugElement.injector.get(OrderDetailsService);
		appService.orderDetails$ = of({
			loading: false,
			value: mockResponse,
		}).pipe();
		component.ngOnInit();
		fixture.detectChanges();
		component.orderDetails$.subscribe();
		expect(component.transaction).toBeUndefined();
		expect(fixture).toMatchSnapshot();
	});
});
