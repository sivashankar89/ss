import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CreditLayoutComponent } from "./page/credit-layout/credit-layout.component";

@NgModule({
	imports: [
		RouterModule.forChild([
			{
				path: "",
				component: CreditLayoutComponent,
			},
		]),
	],
	exports: [RouterModule],
})
export class CreditRoutingModule {}
