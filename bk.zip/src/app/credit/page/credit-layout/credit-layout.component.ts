import { Component, OnDestroy, OnInit } from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { ReplaySubject, takeUntil } from "rxjs";
import { RedirectCallbackService } from "../../../services/redirect/redirect-callback.service";
import { CreditStepperComponent } from "../credit-stepper/credit-stepper.component";

@Component({
	selector: "app-credit-layout",
	template: "",
})
export class CreditLayoutComponent implements OnInit, OnDestroy {
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private modalService: CdsModalService,
		private redirectService: RedirectCallbackService
	) {}

	ngOnInit(): void {
		this.redirectService.init();

		const modalRef = this.modalService.openModal(CreditStepperComponent);
		if (!!modalRef) {
			modalRef.instance.destroy
				.pipe(takeUntil(this.destroyed$))
				.subscribe(() => this.redirectService.return());
		}
	}

	ngOnDestroy(): void {
		this.redirectService.destroy();
		this.destroyed$.next();
		this.destroyed$.complete();
		this.modalService.closeModal();
	}
}
