import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, fakeAsync, TestBed } from "@angular/core/testing";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { RouterTestingModule } from "@angular/router/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { CreditStepperComponent } from "../credit-stepper/credit-stepper.component";
import { CreditLayoutComponent } from "./credit-layout.component";
import { TelemetryService } from "services/telemetry.service";

describe("CreditLayoutComponent", () => {
	let component: CreditLayoutComponent;
	let fixture: ComponentFixture<CreditLayoutComponent>;
	let modalService: CdsModalService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [CreditLayoutComponent, CreditStepperComponent],
			imports: [RouterTestingModule, CdsModalModule, CdsModalFullscreenModule],
			providers: [
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		})
			.overrideModule(BrowserDynamicTestingModule, {
				set: {
					entryComponents: [CreditStepperComponent],
				},
			})
			.compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CreditLayoutComponent);
		component = fixture.componentInstance;
		modalService = TestBed.inject(CdsModalService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should close modal on destroy", fakeAsync(() => {
		jest.spyOn(modalService, "closeModal").mockReturnValue();
		component.ngOnDestroy();
		expect(modalService.closeModal).toHaveBeenCalled();
	}));
});
