import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { TitleService } from "@international-payment-platform/portal-core";
import { CreditStepperComponent } from "./credit-stepper.component";
import { SaleInfoService } from "../../../services/sale-info.service";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TranslateService } from "@tolgee/ngx";
import { TelemetryService } from "services/telemetry.service";

describe("CreditStepperComponent", () => {
	let component: CreditStepperComponent;
	let fixture: ComponentFixture<CreditStepperComponent>;
	let saleInfoService: SaleInfoService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [CreditStepperComponent],
			providers: [
				SaleInfoService,
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CreditStepperComponent);
		component = fixture.componentInstance;
		jest.spyOn(TitleServiceStub, "setTitle");
		saleInfoService = TestBed.get(SaleInfoService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("THEN should set title", () => {
		component.updateBrowserTitle("Credit");
		expect(TitleServiceStub.setTitle).toHaveBeenCalled();
	});

	it("title to reset when destroy component", () => {
		component.ngOnDestroy();
		expect(saleInfoService.tabPayType).toEqual(false);
	});
});
