import { Component, EventEmitter, OnDestroy, Output } from "@angular/core";
import { OrderSummaryComponent } from "../../../new-sale/template/order-summary/order-summary.component";
import { SaleInfoService } from "../../../services/sale-info.service";
import { SaleInformationComponent } from "../../../new-sale/template/sale-information/sale-information.component";
import { PaymentOptionComponent } from "../../../new-sale/template/payment-option/payment-option.component";
import { PaymentSuccessFailureComponent } from "../../../new-sale/template/payment-success-failure/payment-success-failure.component";
import { PAGE_FROM } from "../../../enum/primary.transaction.enum";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { StepInfo } from "model/common.model";

@Component({
	selector: "app-credit-stepper",
	templateUrl: "./credit-stepper.component.html",
	styles: [],
})
export class CreditStepperComponent implements OnDestroy {
	public steps: StepInfo[] = [
		{
			title: this.translateService.instantSafe("credit.credit_amt"),
			component: SaleInformationComponent,
		},
		{
			title: this.translateService.instantSafe("shared.orderSummary"),
			component: OrderSummaryComponent,
			back: true,
		},
		{
			title: this.translateService.instantSafe("shared.payment_options"),
			component: PaymentOptionComponent,
			back: true,
		},
		{
			title: this.translateService.instantSafe("shared.payment_options"),
			component: PaymentSuccessFailureComponent,
			hide: true,
			closeLabel: this.translateService.instantSafe("general.close"),
		},
	];
	@Output() destroy = new EventEmitter();

	constructor(
		private saleInfo: SaleInfoService,
		private titleService: TitleService,
		private translateService: TranslateService
	) {
		this.saleInfo.pageToInitiate = PAGE_FROM.CREDIT;
	}

	updateBrowserTitle(title: string): void {
		this.titleService.setTitle(
			this.translateService.instantSafe("app.title_credit") + " | " + title
		);
	}

	ngOnDestroy(): void {
		this.saleInfo.resetSaleInfo();
		this.titleService.setTitle(
			this.translateService.instantSafe("app.title_transaction")
		);
		this.destroy.emit();
	}
}
