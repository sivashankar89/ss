import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CreditStepperComponent } from "./page/credit-stepper/credit-stepper.component";
import { SharedModule } from "../shared/shared.module";
import { FormsModule } from "@angular/forms";
import { OrderEntrySummaryModule } from "../shared/modules/order-entry-summary/order-entry-summary.module";
import { CreditRoutingModule } from "./credit-routing.module";
import { CreditLayoutComponent } from "./page/credit-layout/credit-layout.component";

@NgModule({
	declarations: [CreditStepperComponent, CreditLayoutComponent],
	imports: [
		CommonModule,
		FormsModule,
		OrderEntrySummaryModule,
		SharedModule,
		CreditRoutingModule,
	],
})
export class CreditModule {}
