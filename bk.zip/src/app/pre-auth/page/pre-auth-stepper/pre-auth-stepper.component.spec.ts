import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { SaleInfoService } from "services/sale-info.service";
import { PreAuthStepperComponent } from "./pre-auth-stepper.component";
import { TelemetryService } from "services/telemetry.service";

describe("PreAuthStepperComponent", () => {
	let component: PreAuthStepperComponent;
	let fixture: ComponentFixture<PreAuthStepperComponent>;
	let saleInfoService: SaleInfoService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PreAuthStepperComponent],
			providers: [
				SaleInfoService,
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PreAuthStepperComponent);
		component = fixture.componentInstance;
		jest.spyOn(TitleServiceStub, "setTitle");
		saleInfoService = TestBed.get(SaleInfoService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("THEN should set title", () => {
		component.updateBrowserTitle("Pre-authrisation");
		expect(TitleServiceStub.setTitle).toHaveBeenCalled();
	});

	it("title to reset when destroy component", () => {
		component.ngOnDestroy();
		expect(saleInfoService.tabPayType).toEqual(false);
	});
});
