import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { RouterTestingModule } from "@angular/router/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TitleServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PreAuthStepperComponent } from "../pre-auth-stepper/pre-auth-stepper.component";

import { PreAuthLayoutComponent } from "./pre-auth-layout.component";
import { TelemetryService } from "services/telemetry.service";

describe("PreAuthLayoutComponent", () => {
	let component: PreAuthLayoutComponent;
	let fixture: ComponentFixture<PreAuthLayoutComponent>;
	let modalService: CdsModalService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [PreAuthLayoutComponent, PreAuthStepperComponent],
			imports: [RouterTestingModule, CdsModalModule, CdsModalFullscreenModule],
			providers: [
				{ provide: TitleService, useValue: TitleServiceStub },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		})
			.overrideModule(BrowserDynamicTestingModule, {
				set: {
					entryComponents: [PreAuthStepperComponent],
				},
			})
			.compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(PreAuthLayoutComponent);
		component = fixture.componentInstance;
		modalService = TestBed.inject(CdsModalService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should close modal on destroy", fakeAsync(() => {
		jest.spyOn(modalService, "closeModal").mockReturnValue();
		component.ngOnDestroy();
		tick();
		expect(modalService.closeModal).toHaveBeenCalled();
	}));
});
