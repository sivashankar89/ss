import { Component, OnDestroy, OnInit } from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { ReplaySubject, takeUntil } from "rxjs";
import { RedirectCallbackService } from "../../../services/redirect/redirect-callback.service";
import { PreAuthStepperComponent } from "../pre-auth-stepper/pre-auth-stepper.component";

@Component({
	selector: "app-pre-auth-layout",
	template: "",
})
export class PreAuthLayoutComponent implements OnInit, OnDestroy {
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private modalService: CdsModalService,
		private redirectService: RedirectCallbackService
	) {}

	ngOnInit(): void {
		this.redirectService.init();
		const modalRef = this.modalService.openModal(PreAuthStepperComponent);
		if (!!modalRef) {
			modalRef.instance.destroy
				.pipe(takeUntil(this.destroyed$))
				.subscribe(() => this.redirectService.return());
		}
	}

	ngOnDestroy(): void {
		this.redirectService.destroy();
		this.destroyed$.next();
		this.destroyed$.complete();
		this.modalService.closeModal();
	}
}
