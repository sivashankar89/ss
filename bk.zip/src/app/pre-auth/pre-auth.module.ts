import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { OrderEntrySummaryModule } from "../shared/modules/order-entry-summary/order-entry-summary.module";
import { SharedModule } from "../shared/shared.module";
import { PreAuthLayoutComponent } from "./page/pre-auth-layout/pre-auth-layout.component";
import { PreAuthStepperComponent } from "./page/pre-auth-stepper/pre-auth-stepper.component";
import { PreAuthRoutingModule } from "./pre-auth-routing.module";

@NgModule({
	declarations: [PreAuthStepperComponent, PreAuthLayoutComponent],
	imports: [
		CommonModule,
		FormsModule,
		OrderEntrySummaryModule,
		SharedModule,
		PreAuthRoutingModule,
	],
})
export class PreAuthModule {}
