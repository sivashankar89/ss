import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { PreAuthLayoutComponent } from "./page/pre-auth-layout/pre-auth-layout.component";

@NgModule({
	imports: [
		RouterModule.forChild([
			{
				path: "",
				component: PreAuthLayoutComponent,
			},
		]),
	],
	exports: [RouterModule],
})
export class PreAuthRoutingModule {}
