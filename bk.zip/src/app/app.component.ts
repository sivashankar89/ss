import { Component } from "@angular/core";
import {
	InstanceService,
	ThemeService,
	TitleService,
} from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { Builds } from "environments/enums";
import { environment } from "environments/environment";
import { Observable } from "rxjs";
import { StoreListResponse } from "../bff-client/model/storeListResponse";
import { DevPanelInfo } from "./dev-panel-settings/dev-panel-data";
import { DevPanelSettingsService } from "./dev-panel-settings/dev-panel-settings.service";
import { MerchantDatasService } from "./services/merchant-datas.service";
import { LocalStorageService } from "./utils/local-storage.service";
import { SessionStorageService } from "./utils/session-storage.service";
import { TranslationService } from "./utils/translation.service";
import { SsoService } from "services/sso.service";

@Component({
	selector: "app-root",
	templateUrl: "./app.component.html",
	styleUrls: ["./app.component.scss"],
})
export class AppComponent {
	isLocal = environment.build == Builds.LOCAL;
	isOpen = false;
	isTestEnvironment: boolean;
	isLoggedIn!: boolean;
	isLoading = false;
	devPanelInfo!: any;
	ecomProfile!: string;
	ecomHealth!: string;
	ecomHealthStatusColor!: string;
	selectedStore$!: Observable<string>;
	selectedStore!: string;

	constructor(
		themeService: ThemeService,
		instanceService: InstanceService,
		titleService: TitleService,
		ssoService: SsoService,
		translationService: TranslationService,
		private sessionStorageService: SessionStorageService,
		private localStorageService: LocalStorageService,
		devPanelService: DevPanelSettingsService,
		translateService: TranslateService,
		private merchantDataService: MerchantDatasService
	) {
		const languagePreference = localStorageService.selectedLanguage.value();
		this.isTestEnvironment = !ssoService.requiresAuthentication;
		if (languagePreference !== "undefined") {
			translationService.updateLanguage(languagePreference);
		}

		this.devPanelInfo = DevPanelInfo;
		if (this.isTestEnvironment) {
			devPanelService.getEcomHealth().subscribe({
				next: (response) => {
					this.ecomHealth = response.status;
					this.ecomHealthStatusColor =
						this.ecomHealth === "UP" ? "success" : "danger";
				},
				error: (error) => {
					this.ecomHealth = error.error.status;
					this.ecomHealthStatusColor =
						this.ecomHealth === "UP" ? "success" : "danger";
				},
			});

			// `ecom/profile` to get the configured profile for the environment.
			if (!this.hasValidGateway) {
				devPanelService.getEcomProfile().subscribe((profile: any) => {
					this.ecomProfile = profile.active;
					sessionStorageService.selectedGatewayEnvironment.set(
						this.ecomProfile
					);
				});
			}
		}

		const instance = instanceService.discoverInstance();
		themeService.loadTheme(instance);
		titleService.setTitle("title");
	}

	ngOnInit(): void {
		this.loadAccessibleStoreIds();
	}

	loadAccessibleStoreIds(): void {
		this.sessionStorageService.accessibleStoreIds.load();
		this.sessionStorageService.selectedStoreID.load();
		this.sessionStorageService.hasMoreRows.load();
		// If already selectedStore exists, then getStoreIds NOT REQUIRED to load/call again.
		this.selectedStore$ = this.sessionStorageService.selectedStoreID.obs$;
		this.selectedStore$.subscribe((data) => {
			this.selectedStore = data;
		});

		// On first load, getStoreIds - unless already fetched by sso service
		if (!this.selectedStore) {
			this.isLoading = true;
			// TODO move to ssoService, rename to StoreAccessService
			this.merchantDataService.getStoreIds().subscribe({
				next: (response?: StoreListResponse) => {
					if (response) {
						// hasMoreRows (>100 store logic)
						if (response?.hasMoreRows!) {
							// If  hasmoreRows is true, No List of stores will be loaded (required), so removed.
							this.sessionStorageService.accessibleStoreIds.remove();
							this.sessionStorageService.hasMoreRows.set(
								response?.hasMoreRows!
							);
							if (this.selectedStore) {
								this.merchantDataService
									.getBestMatchStoreIds(this.selectedStore)
									.subscribe({
										next: (value: StoreListResponse) => {
											if (
												value?.storeList?.length &&
												value.storeList.length > 0
											) {
												this.sessionStorageService.selectedStoreID.set(
													this.selectedStore
												);
											}
										},
										error: () => {
											this.sessionStorageService.selectedStoreID.remove();
										},
									});
							}
						} else {
							// accessibleStoreIds - it will be unique sorted list.
							const accessibleStoreIds = response?.storeList!;
							this.sessionStorageService.hasMoreRows.set(
								response?.hasMoreRows!
							);

							this.sessionStorageService.accessibleStoreIds.set(
								accessibleStoreIds
							);

							if (accessibleStoreIds) {
								let storeIdSet: boolean = false;
								if (this.selectedStore) {
									for (let storeId of accessibleStoreIds) {
										if (storeId == this.selectedStore) {
											storeIdSet = true;
											this.sessionStorageService.selectedStoreID.set(
												this.selectedStore
											);
											break;
										}
									}
								}
								if (!storeIdSet) {
									this.sessionStorageService.selectedStoreID.set(
										accessibleStoreIds[0]
									);
								}
							}
						}
					} else {
						this.sessionStorageService.accessibleStoreIds.remove();
						this.sessionStorageService.selectedStoreID.remove();
						this.sessionStorageService.hasMoreRows.remove();
					}
					this.isLoading = false;
				},
				error: () => {
					this.sessionStorageService.accessibleStoreIds.remove();
					this.sessionStorageService.selectedStoreID.remove();
					this.sessionStorageService.hasMoreRows.remove();
					this.isLoading = false;
				},
			});
		}
	}

	get hasValidGateway(): boolean {
		return this.devPanelInfo.gatewayEnvironments.some(
			(item: any) =>
				item.ecom ==
				this.sessionStorageService.selectedGatewayEnvironment.value()
		);
	}

	valueChange(event: any): void {
		this.isOpen = event;
	}
}
