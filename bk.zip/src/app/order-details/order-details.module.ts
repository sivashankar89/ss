import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import {
	CdsAlertModule,
	CdsButtonModule,
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsResultModule,
	CdsSpinnerModule,
	CdsTooltipModule,
} from "@international-payment-platform/design-system-angular";
import { PipesModule } from "pipes/pipes.module";
import { SharedModule } from "../shared/shared.module";
import {
	OrderDetailsGeneralDetailComponent,
	OrderDetailsTransactionDetailComponent,
} from "./atoms";
import { OrderDetailsMccDetailComponent } from "./atoms/order-details-mcc-detail/order-details-mcc-detail.component";
import { OrderDetailsRecurringDetailComponent } from "./atoms/order-details-recurring-detail/order-details-recurring-detail.component";
import { OpenOrderDetailsDirective } from "./directives/open-order-details.directive";
import {
	OrderDetailsGeneralAddressComponent,
	OrderDetailsTransactionActionsComponent,
	OrderDetailsTransactionDetailsComponent,
	OrderDetailsTransactionOverviewComponent,
	TransactionPrintReceiptBillingDetailsComponent,
} from "./molecules";
import { OrderDetailsRoutingModule } from "./order-details-routing.module";
import {
	OrderDetailsGeneralDetailsComponent,
	OrderDetailsHeaderComponent,
	OrderDetailsRefundOptionComponent,
	OrderDetailsTransactionComponent,
	OrderDetailsTransactionsListComponent,
	TransactionPrintReceiptContentComponent,
	AmendRecurringComponent,
	CancelRecurringComponent,
} from "./organisms";
import { OrderDetailsMccDetailsComponent } from "./organisms/order-details-mcc-details/order-details-mcc-details.component";
import { OrderDetailsRecurringDetailsComponent } from "./organisms/order-details-recurring-details/order-details-recurring-details.component";
import {
	OrderDetailsContentComponent,
	OrderDetailsModalComponent,
} from "./pages";
import { SearchOrderLayoutComponent } from "./pages/search-order-layout/search-order-layout.component";
import { SearchOrderComponent } from "./pages/search-order/search-order.component";
import { AmendRecurringCardFormComponent } from "./molecules/amend-recurring-card-form/amend-recurring-card-form.component";
import { AmendRecurringAmountFormComponent } from "./molecules/amend-recurring-amount-form/amend-recurring-amount-form.component";
import { AmendRecurringBillingAddressFormComponent } from "./molecules/amend-recurring-billing-address-form/amend-recurring-billing-address-form.component";
import { AmendRecurringDetailsFormComponent } from "./molecules/amend-recurring-details-form/amend-recurring-details-form.component";

@NgModule({
	imports: [
		CdsAlertModule,
		CdsButtonModule,
		CdsModalModule,
		CdsModalFullscreenModule,
		CdsResultModule,
		CdsSpinnerModule,
		CdsTooltipModule,
		CommonModule,
		PipesModule,
		SharedModule,
		FormsModule,
		OrderDetailsRoutingModule,
	],
	declarations: [
		OpenOrderDetailsDirective,
		OrderDetailsContentComponent,
		OrderDetailsGeneralAddressComponent,
		OrderDetailsGeneralDetailComponent,
		OrderDetailsGeneralDetailsComponent,
		OrderDetailsHeaderComponent,
		OrderDetailsRefundOptionComponent,
		OrderDetailsModalComponent,
		OrderDetailsTransactionActionsComponent,
		OrderDetailsTransactionComponent,
		OrderDetailsTransactionDetailComponent,
		OrderDetailsTransactionDetailsComponent,
		OrderDetailsTransactionOverviewComponent,
		OrderDetailsTransactionsListComponent,
		TransactionPrintReceiptContentComponent,
		TransactionPrintReceiptBillingDetailsComponent,
		SearchOrderComponent,
		SearchOrderLayoutComponent,
		OrderDetailsMccDetailsComponent,
		OrderDetailsMccDetailComponent,
		OrderDetailsRecurringDetailComponent,
		OrderDetailsRecurringDetailsComponent,
		AmendRecurringComponent,
		CancelRecurringComponent,
		AmendRecurringCardFormComponent,
		AmendRecurringAmountFormComponent,
		AmendRecurringBillingAddressFormComponent,
		AmendRecurringDetailsFormComponent,
	],
	providers: [],
	exports: [OpenOrderDetailsDirective],
})
export class OrderDetailsModule {}
