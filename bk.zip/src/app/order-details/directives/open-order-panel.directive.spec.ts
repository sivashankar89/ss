import { TestBed } from "@angular/core/testing";
import { OpenOrderDetailsService } from "../services/open-order-details.service";
import { OpenOrderDetailsDirective } from "./open-order-details.directive";

describe("OpenOrderDetailsDirective", () => {
	let directive: OpenOrderDetailsDirective;
	let openOrderPanelService: OpenOrderDetailsService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				{
					provide: OpenOrderDetailsService,
					useValue: {
						openOrderDetailsModal: jest.fn(),
					},
				},
			],
		});

		openOrderPanelService = TestBed.inject(OpenOrderDetailsService);

		directive = new OpenOrderDetailsDirective(openOrderPanelService);
	});

	it("should create an instance", () => {
		expect(directive).toBeTruthy();
	});

	it("should handle onClick event", () => {
		directive.onclick();
		expect(openOrderPanelService.openOrderDetailsModal).toHaveBeenCalled();
	});
});
