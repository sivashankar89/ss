import { Directive, HostListener, Input } from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { OrderDetailsModalComponent } from "../pages/order-details-modal/order-details-modal.component";
import { OpenOrderDetailsService } from "../services/open-order-details.service";

@Directive({
	selector: "[appOpenOrderDetails]",
})
export class OpenOrderDetailsDirective {
	@Input("appOpenOrderDetails") public orderId!: string;

	@HostListener("click", ["$event"])
	onclick(): void {
		this.openOrderDetailsService.openOrderDetailsModal(this.orderId);
	}

	constructor(private openOrderDetailsService: OpenOrderDetailsService) {}
}
