import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { SearchOrderLayoutComponent } from "./pages/search-order-layout/search-order-layout.component";

const routes = [
	{
		path: "",
		component: SearchOrderLayoutComponent,
	},
	{
		path: ":id",
		component: SearchOrderLayoutComponent,
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class OrderDetailsRoutingModule {}
