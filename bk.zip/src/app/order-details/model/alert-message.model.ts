import { CdsIcon } from "@international-payment-platform/design-system-angular/lib/icon/icon.model";

export interface OrderDetailsAlertMessage {
	content?: string;
	title?: string;
	icon: CdsIcon;
	type: "info" | "success" | "danger";
}
