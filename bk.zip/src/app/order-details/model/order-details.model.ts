export interface PrintPopupInputData {
	orderId: string;
	transactionId: string;
}
