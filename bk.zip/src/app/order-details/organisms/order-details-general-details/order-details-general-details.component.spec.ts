import { ComponentFixture, TestBed } from "@angular/core/testing";
import { OrderDetailsGeneralDetailsComponent } from "./order-details-general-details.component";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE } from "mocks/reporting_api/orders.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

describe("GeneralDetailsMoleculeComponent", () => {
	let component: OrderDetailsGeneralDetailsComponent;
	let fixture: ComponentFixture<OrderDetailsGeneralDetailsComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [OrderDetailsGeneralDetailsComponent],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(OrderDetailsGeneralDetailsComponent);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("should render details", () => {
		component.order = REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE;
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			'key="shared.ip_address"'
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			'key="shared.trans_origin"'
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			'key="shared.billing_details"'
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			'key="shared.delivery_details"'
		);
	});
});
