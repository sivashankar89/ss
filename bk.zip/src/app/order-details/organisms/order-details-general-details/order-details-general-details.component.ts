import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import {
	BillingAddress,
	OrderReportResponse,
	ShippingAddress,
} from "bff-client";

@Component({
	selector: "app-order-details-general-details",
	templateUrl: "order-details-general-details.component.html",
	styleUrls: ["order-details-general-details.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsGeneralDetailsComponent {
	@Input() order!: OrderReportResponse;
	@Input() cashback!: number;

	get doesShippingAddressContainsData(): boolean {
		return this.isAddressNotEmpty(this.order.shipping);
	}

	get doesBillingAddressContainsData(): boolean {
		return this.isAddressNotEmpty(this.order.billing);
	}

	private isAddressNotEmpty(
		address?: BillingAddress | ShippingAddress
	): boolean {
		return !!address && !!Object.keys(address).length;
	}
}
