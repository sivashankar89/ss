import {
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	Component,
	Inject,
	OnDestroy,
	OnInit,
} from "@angular/core";
import { PrintPopupInputData } from "../../../order-details/model/order-details.model";
import { map, ReplaySubject, takeUntil } from "rxjs";
import { PaymentsOrdersService } from "services/payments/payments-orders.service";
import { POPUP_DATA, POPUP_ROOT_HREF } from "popup/popup-token";
import { DOCUMENT } from "@angular/common";
import { TranslateService } from "@tolgee/ngx";
import { OrderDetailsResponse, PaymentResponse } from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";

@Component({
	selector: "app-transaction-print-receipt-content",
	templateUrl: "./transaction-print-receipt-content.component.html",
	styleUrls: ["./transaction-print-receipt-content.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TransactionPrintReceiptContentComponent
	implements OnInit, OnDestroy
{
	private readonly orderId: string;
	private readonly transactionId: string;
	isLoading = false;
	order?: OrderDetailsResponse;
	transaction?: PaymentResponse;
	storeId: string = this.storageService.getStoreId();
	root: string;
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);
	printBtnLabel!: string;
	rawCurrency = true;

	constructor(
		private paymentsOrdersService: PaymentsOrdersService,
		private changeDetectorRef: ChangeDetectorRef,
		@Inject(POPUP_DATA) { orderId, transactionId }: PrintPopupInputData,
		@Inject(DOCUMENT) private readonly documentRef: Document,
		@Inject(POPUP_ROOT_HREF) href: string,
		private translateService: TranslateService,
		private storageService: SessionStorageService
	) {
		this.orderId = orderId;
		this.transactionId = transactionId;
		this.root = href;
		this.printBtnLabel = this.translateService.instantSafe(
			"shared.print_receipt"
		);
	}

	ngOnInit(): void {
		this.getOrderDetails();
	}

	getOrderDetails(): void {
		this.isLoading = true;
		this.paymentsOrdersService
			.getOrder(this.orderId)
			.pipe(
				map((order) => {
					const transaction = order.transactions?.find((ransactionData) => {
						return ransactionData.ipgTransactionId === this.transactionId;
					});

					if (!transaction) {
						throw new Error(
							this.translateService.instantSafe("shared.trans_not_found")
						);
					}

					return {
						transaction,
						order,
					};
				}),
				takeUntil(this.destroyed$)
			)
			.subscribe({
				next: ({ order, transaction }) => {
					this.isLoading = false;
					this.order = order;
					this.transaction = transaction;
					this.changeDetectorRef.detectChanges();
				},
				error: () => {
					this.isLoading = false;
					this.order = undefined;
					this.transaction = undefined;
					this.changeDetectorRef.detectChanges();
				},
			});
	}

	printReceipt(): void {
		const window = this.documentRef.defaultView;

		if (!window) {
			return;
		}

		window.print();
	}

	ngOnDestroy(): void {
		this.destroyed$.next();
		this.destroyed$.complete();
	}
}
