import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { TranslateService } from "@tolgee/ngx";
import { PAYMENTS_ORDER_DETAILS_MOCK_RESPONSE } from "mocks/payment_api/order-details.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { POPUP_DATA, POPUP_ROOT_HREF } from "popup/popup-token";
import { of, throwError } from "rxjs";
import { PaymentsOrdersService } from "services/payments/payments-orders.service";
import { TransactionPrintReceiptContentComponent } from "./transaction-print-receipt-content.component";
import { TelemetryService } from "services/telemetry.service";

const paymentsServiceMock = {
	getOrder: jest.fn().mockReturnValue(of(PAYMENTS_ORDER_DETAILS_MOCK_RESPONSE)),
};

describe("TransactionPrintReceiptContentComponent", () => {
	let component: TransactionPrintReceiptContentComponent;
	let fixture: ComponentFixture<TransactionPrintReceiptContentComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [PipesMockModule],
			declarations: [TransactionPrintReceiptContentComponent],
			providers: [
				{
					provide: PaymentsOrdersService,
					useValue: paymentsServiceMock,
				},
				{
					provide: TranslateService,
					useValue: TranslateServiceStub,
				},
				{
					provide: POPUP_DATA,
					useValue: { orderId: "12345", transactionId: "838916029301" },
				},
				{
					provide: POPUP_ROOT_HREF,
					useValue: "https://localhost:4200/virtual-terminal-ui/",
				},
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(TransactionPrintReceiptContentComponent);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("should fetch order details", () => {
		fixture.detectChanges();
		expect(component.isLoading).toBe(false);
	});

	it("should handle the API error response", () => {
		fixture.detectChanges();
		const paymentsOrdersService = TestBed.inject(PaymentsOrdersService);
		paymentsOrdersService.getOrder = jest.fn().mockReturnValue(
			throwError(() => ({
				error: {
					error: {
						code: "404",
						message: "Record not found",
					},
				},
			}))
		);
		component.getOrderDetails();
		fixture.detectChanges();
		expect(component.isLoading).toBe(false);
	});

	it("should throw error if transaction is undefined", () => {
		fixture.detectChanges();
		const paymentsOrdersService = TestBed.inject(PaymentsOrdersService);
		paymentsOrdersService.getOrder = jest.fn().mockReturnValue(
			of({
				orderId: "123456",
			})
		);
		component.getOrderDetails();
		fixture.detectChanges();
		expect(component.isLoading).toBe(false);
	});

	it("should throw error if transaction is undefined", () => {
		fixture.detectChanges();
		const paymentsOrdersService = TestBed.inject(PaymentsOrdersService);
		paymentsOrdersService.getOrder = jest.fn().mockReturnValue(
			of({
				orderId: "123456",
			})
		);
		component.getOrderDetails();
		fixture.detectChanges();
		expect(component.isLoading).toBe(false);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"cds-result"
		);
	});

	it("should execute printReceipt", () => {
		const print = jest.fn();
		Object.defineProperty(component, "documentRef", {
			value: {
				defaultView: {
					print,
				},
			},
		});
		component.printReceipt();

		expect(print).toHaveBeenCalled();
	});
});
