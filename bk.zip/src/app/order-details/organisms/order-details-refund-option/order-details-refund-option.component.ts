import {
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	OnInit,
	Output,
	ViewChild,
} from "@angular/core";
import { NgForm } from "@angular/forms";
import { OrderDetailsAlertService } from "../../services/show-alert.service";
import { delay, of, ReplaySubject, Subscription, takeUntil } from "rxjs";
import { PaymentsOrdersService } from "../../../services/payments/payments-orders.service";
import { throwErrorMessage } from "../../../utils/common.utils";
import { TranslateService } from "@tolgee/ngx";
import { CurrencyEnum, OrderReportResponse, RequestType } from "bff-client";

@Component({
	selector: "app-order-details-refund-option",
	templateUrl: "./order-details-refund-option.component.html",
	styleUrls: ["./order-details-refund-option.component.scss"],
})
export class OrderDetailsRefundOptionComponent implements OnInit, OnDestroy {
	@Input() order!: OrderReportResponse;
	@Input() orderBalance!: number;
	@Output()
	readonly secondaryTransactionPerformed: EventEmitter<void> = new EventEmitter<void>();

	@ViewChild("refundAmountForm") refundAmountForm!: NgForm;
	currency!: CurrencyEnum;
	orderBalanceAmount!: number;
	isRefundable = false;
	refundAmount!: number;
	isInvalidRefundAmount = false;
	isProcessing = false;
	hideError = true;
	hideErrorSub!: Subscription;
	private readonly destroyed$ = new ReplaySubject<void>(1);

	constructor(
		private orderDetailsAlertService: OrderDetailsAlertService,
		private paymentOrderService: PaymentsOrdersService,
		private translateService: TranslateService
	) {}

	ngOnInit(): void {
		if (this.order && this.orderCurrency) {
			this.orderBalanceAmount = this.orderBalance;
			this.currency = this.orderCurrency;
		}
		if (this.orderBalanceAmount > 0) {
			this.isRefundable = true;
		}
	}

	get orderCurrency(): CurrencyEnum | undefined {
		if (!this.order?.currency) {
			throwErrorMessage(
				this.translateService.instantSafe("shared.message_currency_info")
			);
		}
		return this.order?.currency;
	}

	get refundDisable(): boolean {
		if (!this.refundAmount || this.refundAmount === 0) {
			return true;
		}
		return !this.refundAmountForm.valid;
	}

	validateOrderBalance(value: string | number): void {
		this.refundAmount = typeof value === "string" ? parseFloat(value) : value;
		this.hideError = false;
		this.isInvalidRefundAmount = false;
		if (this.orderBalanceAmount < this.refundAmount) {
			this.isInvalidRefundAmount = true;
			const key = "refundAmount";
			this.refundAmountForm.form.controls[key].setErrors({
				incorrect: true,
			});
		}

		if (this.hideErrorSub) {
			this.hideErrorSub.unsubscribe();
		}
		this.hideErrorSub = of(null)
			.pipe(delay(3000))
			.subscribe(() => (this.hideError = true));
	}

	performRefund(): void {
		if (this.isProcessing || this.isInvalidRefundAmount) {
			return;
		}

		this.isProcessing = true;
		const total = parseFloat(this.refundAmountForm?.value?.refundAmount);
		this.paymentOrderService
			.postReturnOrPostAuthSecondaryTransaction(
				this.order?.orderId,
				RequestType.ReturnTransaction,
				{
					transactionAmount: {
						total,
						currency: this.currency as any,
					},
				}
			)
			.pipe(takeUntil(this.destroyed$))
			.subscribe({
				next: (res) => {
					this.isProcessing = false;
					if (res.error) {
						this.orderDetailsAlertService.showErrorMessage(
							this.translateService.instantSafe(
								"shared.message_refund_declined"
							)
						);
					} else {
						this.orderDetailsAlertService.showSuccessMessage(
							this.translateService.instantSafe(
								"shared.message_refund_processed"
							)
						);
					}
					this.secondaryTransactionPerformed.emit();
				},
				error: () => {
					this.isProcessing = false;
					this.orderDetailsAlertService.showErrorMessage(
						this.translateService.instantSafe("shared.message_refund_declined")
					);
					this.secondaryTransactionPerformed.emit();
				},
			});
	}

	ngOnDestroy(): void {
		this.destroyed$.next();
		this.destroyed$.complete();
	}
}
