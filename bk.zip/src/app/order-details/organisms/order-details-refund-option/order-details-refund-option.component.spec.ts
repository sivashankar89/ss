import { OverlayModule } from "@angular/cdk/overlay";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormControl, FormsModule } from "@angular/forms";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { of } from "rxjs";
import { PipesMockModule } from "../../../../mocks/pipes/pipes.module.mock";
import { REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE } from "../../../../mocks/reporting_api/orders.mock";
import { PaymentsOrdersService } from "../../../services/payments/payments-orders.service";
import { OrderDetailsAlertService } from "../../services/show-alert.service";
import { OrderDetailsRefundOptionComponent } from "./order-details-refund-option.component";
import { TelemetryService } from "services/telemetry.service";

describe("OrderDetailsRefundOptionComponent", () => {
	let component: OrderDetailsRefundOptionComponent;
	let fixture: ComponentFixture<OrderDetailsRefundOptionComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			schemas: [NO_ERRORS_SCHEMA],
			declarations: [OrderDetailsRefundOptionComponent],
			imports: [FormsModule, PipesMockModule, OverlayModule, HttpClientModule],
			providers: [
				OrderDetailsAlertService,
				PaymentsOrdersService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});
		fixture = TestBed.createComponent(OrderDetailsRefundOptionComponent);
		component = fixture.componentInstance;
	});

	describe("constructor", () => {
		it("should create instance", () => {
			expect(component).toBeDefined();
		});
	});

	it("can load instance", () => {
		expect(component).toBeTruthy();
	});

	it(`isRefundable has default value`, () => {
		expect(component.isRefundable).toEqual(false);
	});

	it(`isInvalidRefundAmount has default value`, () => {
		expect(component.isInvalidRefundAmount).toEqual(false);
	});

	it(`isProcessing has default value`, () => {
		expect(component.isProcessing).toEqual(false);
	});

	it("should render details", () => {
		component.order = REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE;
		component.isRefundable = true;
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();

		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"cdsform"
		);
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app.title_refund"
		);
	});

	describe("validateOrderBalance", () => {
		it("should not set an error", () => {
			component.refundAmountForm = { value: { refundAmount: "100" } } as any;
			component.orderBalanceAmount = 200;
			component.validateOrderBalance(100);

			expect(component.isInvalidRefundAmount).toBeFalsy();
		});
		it("should set an error", () => {
			component.refundAmountForm = {
				value: { refundAmount: "100" },
				form: {
					controls: {
						refundAmount: new FormControl(),
					},
				},
			} as any;

			component.orderBalanceAmount = 50;
			component.validateOrderBalance(100);

			expect(component.isInvalidRefundAmount).toBeTruthy();
		});
	});

	describe("performRefund", () => {
		it("should not perform refund process", () => {
			component.isProcessing = true;
			const paymentsOrdersServiceStub: PaymentsOrdersService =
				fixture.debugElement.injector.get(PaymentsOrdersService);
			paymentsOrdersServiceStub.postReturnOrPostAuthSecondaryTransaction = jest
				.fn()
				.mockReturnValue(of(null as any));

			component.performRefund();

			expect(
				paymentsOrdersServiceStub.postReturnOrPostAuthSecondaryTransaction
			).not.toHaveBeenCalled();
		});
	});
});
