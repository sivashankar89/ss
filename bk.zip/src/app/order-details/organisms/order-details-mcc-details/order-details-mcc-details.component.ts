import { DatePipe } from "@angular/common";
import { Component, Input } from "@angular/core";
import { TranslateService } from "@tolgee/ngx";
import { OrderReportResponse } from "../../../../bff-client";
import { throwErrorMessage } from "../../../utils/common.utils";

@Component({
	selector: "app-order-details-mcc-details",
	templateUrl: "./order-details-mcc-details.component.html",
	styleUrls: ["./order-details-mcc-details.component.scss"],
})
export class OrderDetailsMccDetailsComponent {
	@Input() order!: OrderReportResponse;

	constructor(
		private translateService: TranslateService,
		private datepipe: DatePipe
	) {}

	get dateOfBirth(): string {
		if (!this.order.industrySpecificExtensions?.mcc6012) {
			throwErrorMessage(
				this.translateService.instantSafe("general.message_went_wrong")
			);
		}
		const dateString =
			this.order.industrySpecificExtensions?.mcc6012?.dateOfBirth!;
		const year = +dateString.substring(0, 4);
		const month = +dateString.substring(4, 6);
		const day = +dateString.substring(6, 8);

		const date = new Date(year, month - 1, day);
		const dateOfBirth = this.datepipe.transform(date, "yyyy-MM-dd");

		return dateOfBirth!;
	}
}
