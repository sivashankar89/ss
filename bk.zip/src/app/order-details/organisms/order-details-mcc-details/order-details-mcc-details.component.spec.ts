import { DatePipe } from "@angular/common";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "../../../../mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "../../../../mocks/services/services.mock";
import { OrderDetailsMccDetailsComponent } from "./order-details-mcc-details.component";
import { TelemetryService } from "services/telemetry.service";

describe("OrderDetailsMccDetailsComponent", () => {
	let component: OrderDetailsMccDetailsComponent;
	let fixture: ComponentFixture<OrderDetailsMccDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [OrderDetailsMccDetailsComponent],
			imports: [PipesMockModule],
			providers: [
				DatePipe,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsMccDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
