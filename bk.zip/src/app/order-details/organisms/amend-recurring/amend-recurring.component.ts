import {
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	OnInit,
	Output,
	ViewChild,
} from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import {
	OrderReportResponse,
	PaymentBffService,
	PaymentCard,
	RequestType,
	ScheduledPaymentRequest,
	TransactionAmount,
} from "bff-client";
import { SessionStorageService } from "utils/session-storage.service";
import { TranslateService } from "@tolgee/ngx";
import { OrderDetailsAlertService } from "order-details/services/show-alert.service";
import { SaleInfoService } from "services/sale-info.service";
import { AmendRecurringDetailsFormComponent } from "order-details/molecules/amend-recurring-details-form/amend-recurring-details-form.component";
import { AmendRecurringBillingAddressFormComponent } from "order-details/molecules/amend-recurring-billing-address-form/amend-recurring-billing-address-form.component";
import { AmendRecurringCardFormComponent } from "order-details/molecules/amend-recurring-card-form/amend-recurring-card-form.component";
import { AmendRecurringAmountFormComponent } from "order-details/molecules/amend-recurring-amount-form/amend-recurring-amount-form.component";

@Component({
	selector: "app-amend-recurring",
	templateUrl: "./amend-recurring.component.html",
	styleUrls: ["./amend-recurring.component.scss"],
})
export class AmendRecurringComponent implements OnInit, OnDestroy {
	@Input() order!: OrderReportResponse;
	@Input() todayDueMsg!: string;
	@Output() readonly amendRecurringDone: EventEmitter<void> =
		new EventEmitter<void>();
	@ViewChild(AmendRecurringDetailsFormComponent)
	recurringForm!: AmendRecurringDetailsFormComponent;
	@ViewChild(AmendRecurringBillingAddressFormComponent)
	billingForm!: AmendRecurringBillingAddressFormComponent;
	@ViewChild(AmendRecurringCardFormComponent)
	cardForm!: AmendRecurringCardFormComponent;
	@ViewChild(AmendRecurringAmountFormComponent)
	amountForm!: AmendRecurringAmountFormComponent;
	isProcessingAmend = false;
	isSubmitted = false;

	recurringAmount!: TransactionAmount;
	paymentCard!: PaymentCard;
	loading = true;

	constructor(
		private modalService: CdsModalService,
		private paymentBff: PaymentBffService,
		private storageService: SessionStorageService,
		private translateService: TranslateService,
		private orderDetailsAlertService: OrderDetailsAlertService,
		private saleInfo: SaleInfoService
	) {}

	ngOnInit(): void {
		this.paymentBff
			.viewSchedulePayment({
				authorizerId: this.storageService.getStoreId(),
				selectedGatewayServiceEnvironment:
					this.storageService.getGatewayEnvironment(),
				orderId: this.order?.orderId || "",
			})
			.subscribe({
				next: (order) => {
					this.paymentCard = order?.recurringPaymentDetails
						?.paymentMethodDetails?.paymentCard || {
						bin: "000000",
						last4: "0000",
					};
					this.paymentCard.bin = this.paymentCard.bin || "000000";

					this.recurringAmount = order?.recurringPaymentDetails
						?.transactionAmount || {
						total: this.order?.recurringPaymentsInfo?.amount || 0,
						currency: this.order?.currency as any,
						components: {
							subtotal: this.order?.recurringPaymentsInfo?.amount || 0,
						},
					};
					this.loading = false;
				},
				error: () => {
					this.loading = false;
				},
			});
	}

	doAmendRecurring(): void {
		this.isSubmitted = false;
		setTimeout(() => {
			this.isSubmitted = true;
		}, 300);
		if (this.isProcessingAmend || !this.order?.orderId) {
			return;
		}

		if (this.recurringForm.form.valid === false) {
			return;
		}

		const recurring = this.recurringForm.recurring;

		const scheduledPaymentRequest: ScheduledPaymentRequest = {
			requestType: RequestType.ReferencedOrderPaymentSchedulesRequest,
			startDate: recurring.startDate,
			frequency: recurring.frequency,
			numberOfPayments: recurring.numberOfPayments,
			transactionAmount: this.recurringAmount,
		};

		if (this.order?.industrySpecificExtensions?.mcc6012) {
			scheduledPaymentRequest.industrySpecificExtensions = {
				mcc6012: this.order?.industrySpecificExtensions?.mcc6012,
			};
		}

		if (this.billingForm.expandedAddress.billing === true) {
			if (
				this.billingForm.billingComponent?.addressDetails?.addressForm
					?.valid === false
			) {
				return;
			}
			const billingDetails = this.billingForm.modifiedBilling;
			if (
				billingDetails?.address &&
				Object.values(billingDetails?.address).every(
					(o) => o === "" || o === " "
				)
			) {
				delete billingDetails?.address;
			}
			if (
				billingDetails?.contact &&
				Object.values(billingDetails?.contact).every(
					(o) => o === "" || o === " "
				)
			) {
				delete billingDetails?.contact;
			}

			scheduledPaymentRequest.billing = billingDetails;
		}

		if (this.cardForm.canUpdate === true) {
			if (this.cardForm.form.valid === false) {
				return;
			}

			scheduledPaymentRequest.paymentMethod = {
				paymentCard: this.cardForm.paymentCard,
			};

			scheduledPaymentRequest.requestType =
				RequestType.PaymentMethodPaymentSchedulesRequest;
		} else {
			scheduledPaymentRequest.referencedOrderId = this.order?.orderId;
		}

		if (this.amountForm.canUpdate === true) {
			if (this.amountForm.form.valid === false) {
				return;
			}

			scheduledPaymentRequest.transactionAmount = this.amountForm.amount;
		}

		this.isProcessingAmend = true;

		this.paymentBff
			.updateSchedulePayment({
				authorizerId: this.storageService.getStoreId(),
				selectedGatewayServiceEnvironment:
					this.storageService.getGatewayEnvironment(),
				orderId: this.order?.orderId,
				scheduledPaymentRequest: scheduledPaymentRequest,
			})
			.subscribe({
				next: (res) => {
					if (res.error) {
						this.orderDetailsAlertService.showErrorMessage(
							this.translateService.instantSafe(
								"order_details.message_declined_amend_recurring"
							)
						);
					} else {
						this.orderDetailsAlertService.showSuccessMessage(
							this.translateService.instantSafe(
								"order_details.message_requested_amend_recurring"
							)
						);
						this.amendRecurringDone.emit();
					}
					this.isProcessingAmend = false;
					this.closeModal();
				},
				error: () => {
					this.orderDetailsAlertService.showErrorMessage(
						this.translateService.instantSafe(
							"order_details.message_declined_amend_recurring"
						)
					);
					this.isProcessingAmend = false;
					this.closeModal();
				},
			});
	}

	closeModal(): void {
		this.amendRecurringDone.emit();
		this.saleInfo.isBillingAvailable = false;
		this.modalService.closeModal();
	}

	ngOnDestroy(): void {
		this.amendRecurringDone.emit();
		this.saleInfo.isBillingAvailable = false;
	}
}
