import { DatePipe } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, fakeAsync, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import {
	CdsDatepickerModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";
import { OrderDetailsAlertService } from "order-details/services/show-alert.service";
import { AmendRecurringComponent } from "./amend-recurring.component";
import { PipesMockModule } from "../../../../mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "../../../../mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

describe("AmendRecurringComponent", () => {
	let component: AmendRecurringComponent;
	let fixture: ComponentFixture<AmendRecurringComponent>;
	let modalService: CdsModalService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [AmendRecurringComponent],
			imports: [
				FormsModule,
				HttpClientModule,
				CdsDatepickerModule,
				PipesMockModule,
			],
			providers: [
				DatePipe,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{ provide: NgForm, useValue: new NgForm([], []) },
				{ provide: OrderDetailsAlertService, useValue: {} },
				{
					provide: CdsModalService,
					useValue: {
						openModal: jest.fn(),
						closeModal: jest.fn(),
					},
				},
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(AmendRecurringComponent);
		component = fixture.componentInstance;
		modalService = TestBed.inject(CdsModalService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should close modal on destroy", fakeAsync(() => {
		jest.spyOn(modalService, "closeModal");
		component.closeModal();
		fixture.detectChanges();
		expect(modalService.closeModal).toHaveBeenCalled();
	}));
});
