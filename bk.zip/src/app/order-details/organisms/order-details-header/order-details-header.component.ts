import { Component, Input } from "@angular/core";
import { Observable } from "rxjs";
import { OrderReportResponse } from "bff-client";
import { OrderDetailsAlertMessage } from "../../model/alert-message.model";
import { OrderDetailsAlertService } from "../../services/show-alert.service";

@Component({
	selector: "app-order-details-header",
	templateUrl: "./order-details-header.component.html",
	styleUrls: ["./order-details-header.component.scss"],
})
export class OrderDetailsHeaderComponent {
	@Input() public order!: OrderReportResponse;
	@Input() orderBalance!: number;
	readonly alertInfo$: Observable<OrderDetailsAlertMessage | undefined>;

	constructor(orderDetailsAlertService: OrderDetailsAlertService) {
		this.alertInfo$ = orderDetailsAlertService.alertMessageInfo$;
	}
}
