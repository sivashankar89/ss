import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE } from "mocks/reporting_api/orders.mock";
import { OrderDetailsHeaderComponent } from "./order-details-header.component";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { OrderDetailsAlertService } from "../../services/show-alert.service";

describe("OrderDetailsHeaderComponent", () => {
	let component: OrderDetailsHeaderComponent;
	let fixture: ComponentFixture<OrderDetailsHeaderComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [PipesMockModule],
			declarations: [OrderDetailsHeaderComponent],
			providers: [OrderDetailsAlertService],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(OrderDetailsHeaderComponent);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("Should display the order id", () => {
		component.order = REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE;
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();

		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"A-395fad2e9c34-24357-45761-12345"
		);
	});

	it(`Should have class 'id'`, () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect(fixture.debugElement.query(By.css(".id"))).toBeTruthy();
	});

	it(`Should have class 'balance'`, () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect(fixture.debugElement.query(By.css(".balance"))).toBeTruthy();
	});
});
