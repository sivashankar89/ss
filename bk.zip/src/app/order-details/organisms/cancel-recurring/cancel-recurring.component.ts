import {
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	Output,
} from "@angular/core";
import { ReplaySubject, takeUntil } from "rxjs";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";
import { OrderReportResponse, PaymentBffService } from "bff-client";
import { OrderDetailsAlertService } from "order-details/services/show-alert.service";
import { SessionStorageService } from "utils/session-storage.service";

@Component({
	selector: "app-cancel-recurring",
	templateUrl: "./cancel-recurring.component.html",
})
export class CancelRecurringComponent implements OnDestroy {
	@Input() order!: OrderReportResponse;
	@Input() todayDueMsg!: string;
	@Output() readonly cancelRecurringDone: EventEmitter<void> =
		new EventEmitter<void>();
	isProcessingCancel = false;
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private modalService: CdsModalService,
		private paymentBff: PaymentBffService,
		private orderDetailsAlertService: OrderDetailsAlertService,
		private translateService: TranslateService,
		private storageService: SessionStorageService
	) {}

	confirmCancel(): void {
		if (this.isProcessingCancel || !this.order?.orderId) {
			return;
		}

		this.isProcessingCancel = true;

		this.paymentBff
			.cancelSchedulePayment({
				orderId: this.order.orderId,
				authorizerId: this.storageService.getStoreId(),
				selectedGatewayServiceEnvironment:
					this.storageService.getGatewayEnvironment(),
			})
			.pipe(takeUntil(this.destroyed$))
			.subscribe({
				next: (res) => {
					if (res.error) {
						this.orderDetailsAlertService.showErrorMessage(
							this.translateService.instantSafe(
								"order_details.message_declined_cancel_recurring"
							)
						);
					} else {
						this.orderDetailsAlertService.showSuccessMessage(
							this.translateService.instantSafe(
								"order_details.message_requested_cancel_recurring"
							)
						);
						this.cancelRecurringDone.emit();
					}
					this.isProcessingCancel = false;
					this.closeModal();
				},
				error: () => {
					this.orderDetailsAlertService.showErrorMessage(
						this.translateService.instantSafe(
							"order_details.message_declined_cancel_recurring"
						)
					);
					this.isProcessingCancel = false;
					this.closeModal();
				},
			});
	}

	closeModal(): void {
		this.modalService.closeModal();
	}

	ngOnDestroy(): void {
		this.destroyed$.next();
		this.destroyed$.complete();
	}
}
