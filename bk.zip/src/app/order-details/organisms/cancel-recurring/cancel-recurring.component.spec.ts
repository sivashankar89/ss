import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";
import { CancelRecurringComponent } from "..";
import { PipesMockModule } from "../../../../mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "../../../../mocks/services/services.mock";
import { OrderDetailsAlertService } from "../../services/show-alert.service";
import { TelemetryService } from "services/telemetry.service";

describe("CancelRecurringComponent", () => {
	let component: CancelRecurringComponent;
	let fixture: ComponentFixture<CancelRecurringComponent>;
	let modalService: CdsModalService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [CancelRecurringComponent],
			imports: [PipesMockModule, HttpClientTestingModule],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{ provide: OrderDetailsAlertService, useValue: {} },
				{
					provide: CdsModalService,
					useValue: {
						openModal: jest.fn(),
						closeModal: jest.fn(),
					},
				},
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(CancelRecurringComponent);
		component = fixture.componentInstance;
		modalService = TestBed.inject(CdsModalService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should close modal on destroy", fakeAsync(() => {
		jest.spyOn(modalService, "closeModal");
		component.closeModal();
		fixture.detectChanges();
		expect(modalService.closeModal).toHaveBeenCalled();
	}));
});
