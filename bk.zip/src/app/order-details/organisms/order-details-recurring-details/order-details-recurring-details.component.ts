import {
	Component,
	EventEmitter,
	Input,
	Output,
	SimpleChanges,
	TemplateRef,
	ViewChild,
} from "@angular/core";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { VTPaymentPermissions } from "enum/permissions.enum";
import {
	OrderReportResponse,
	RecurringPaymentState,
	TransactionResult,
} from "bff-client";
import { DecimalPlacesPipe } from "pipes/decimal-places/decimal-places.pipe";
import { TranslateService } from "@tolgee/ngx";
@Component({
	selector: "app-order-details-recurring-details",
	templateUrl: "./order-details-recurring-details.component.html",
	styleUrls: ["./order-details-recurring-details.component.scss"],
	providers: [DecimalPlacesPipe],
})
export class OrderDetailsRecurringDetailsComponent {
	@Input() order!: OrderReportResponse;
	@Output() readonly recurringActionPerformed: EventEmitter<void> =
		new EventEmitter<void>();
	@ViewChild("amendScheduleTpl", { read: TemplateRef })
	amentScheduleTpl!: TemplateRef<any>;
	@ViewChild("cancelScheduleTpl", { read: TemplateRef })
	cancelScheduleTpl!: TemplateRef<any>;
	paymentPermissions = VTPaymentPermissions;
	todayDueMsg = "";
	numberofPayLabel: string = "";

	constructor(
		private modalService: CdsModalService,
		private translateService: TranslateService,
		private decimalPlacesPipe: DecimalPlacesPipe
	) {}

	get isCancelled(): boolean {
		return (
			this.order.recurringPaymentsInfo?.state ===
			RecurringPaymentState.Cancelled
		);
	}

	get isCompleted(): boolean {
		if (
			this.order.recurringPaymentsInfo?.state !==
			RecurringPaymentState.Inactivated
		) {
			return false;
		}

		const successCount = this.order.transactions?.reduce((a, c) => {
			return c.transactionResult === TransactionResult.Approved ? a + 1 : a;
		}, 0);

		return this.order.recurringPaymentsInfo.numberOfPayments === successCount;
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes.order) {
			const orderValue: OrderReportResponse = changes.order.currentValue;
			const recurring = orderValue.recurringPaymentsInfo;
			if (recurring?.numberOfPayments && recurring?.numberOfPayments != 999) {
				this.numberofPayLabel = this.translateService.instantSafe(
					"shared.after_n_payments",
					{ n: recurring?.numberOfPayments }
				);
			} else {
				this.numberofPayLabel = this.translateService.instantSafe(
					"shared.until_cancelled"
				);
			}
			const todayDue = [recurring?.startDate, recurring?.nextAttemptDate].some(
				(dateString) => {
					if (!dateString) {
						return false;
					}
					return this.isToday(new Date(dateString));
				}
			);
			if (todayDue) {
				this.decimalPlacesPipe
					.transform(
						orderValue.recurringPaymentsInfo?.amount,
						orderValue.currency
					)
					.subscribe((amount) => {
						this.todayDueMsg = this.translateService.instantSafe(
							"order_details.recurring_today_warning_msg",
							{ amount: amount, currency: orderValue.currency }
						);
					});
			} else {
				this.todayDueMsg = "";
			}
		}
	}

	isToday(date: Date): boolean {
		const today = new Date();
		return (
			date.getDate() === today.getDate() &&
			date.getMonth() === today.getMonth() &&
			date.getFullYear() === today.getFullYear()
		);
	}

	amendSchedule(): void {
		this.modalService.openModalTemplate(this.amentScheduleTpl);
	}

	cancelSchedule(): void {
		this.modalService.openModalTemplate(this.cancelScheduleTpl);
	}

	cancelSchedulePerformed(): void {
		if (this.order.recurringPaymentsInfo) {
			this.order.recurringPaymentsInfo.state = RecurringPaymentState.Cancelled;
		}
		this.recurringActionPerformed.emit();
	}

	amendSchedulePerformed(): void {
		this.recurringActionPerformed.emit();
	}
}
