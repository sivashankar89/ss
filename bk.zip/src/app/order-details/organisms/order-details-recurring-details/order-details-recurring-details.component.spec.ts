import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { TranslateService } from "@tolgee/ngx";
import { PipesMockModule } from "../../../../mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "../../../../mocks/services/services.mock";
import { OrderDetailsRecurringDetailsComponent } from "./order-details-recurring-details.component";
import { TelemetryService } from "services/telemetry.service";

describe("OrderDetailsRecurringDetailsComponent", () => {
	let component: OrderDetailsRecurringDetailsComponent;
	let fixture: ComponentFixture<OrderDetailsRecurringDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [OrderDetailsRecurringDetailsComponent],
			imports: [PipesMockModule],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
				{
					provide: CdsModalService,
					useValue: {
						openModal: jest.fn(),
						closeModal: jest.fn(),
					},
				},
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsRecurringDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
