import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { AuthenticationService } from "@international-payment-platform/portal-core";
import {
	REPORTING_API_ORDER_DETAILS_COMPLETION_MOCK_RESPONSE,
	REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE,
	REPORTING_API_ORDER_DETAILS_PREAUTH_DECLINED_MOCK_RESPONSE,
	REPORTING_API_ORDER_DETAILS_PREAUTH_MOCK_RESPONSE,
} from "mocks/reporting_api/orders.mock";
import { AuthenticationServiceStub } from "mocks/services/services.mock";
import { CurrencyEnum } from "../../../../bff-client";
import { OrderDetailsTransactionsListComponent } from "./order-details-transactions-list.component";

describe("OrderDetailsTransactionsListComponent", () => {
	let component: OrderDetailsTransactionsListComponent;
	let fixture: ComponentFixture<OrderDetailsTransactionsListComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			schemas: [NO_ERRORS_SCHEMA],
			declarations: [OrderDetailsTransactionsListComponent],
			providers: [
				{ provide: AuthenticationService, useValue: AuthenticationServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsTransactionsListComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should display transactions", () => {
		component.order = REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE;
		fixture.detectChanges();

		expect(fixture).toMatchSnapshot();
	});

	it("should sort transaction in a proper way", () => {
		const transactionA = {
			orderId: "test-order",
			ipgTransactionId: "test-a",
			transactionTime: 10,
		};
		const transactionB = {
			orderId: "test-order",
			ipgTransactionId: "test-b",
			transactionTime: 10,
		};
		const transactionC = {
			orderId: "test-order",
			ipgTransactionId: "test-c",
			transactionTime: 5,
		};
		const transactionD = {
			orderId: "test-order",
			ipgTransactionId: "test-d",
			transactionTime: 20,
		};

		component.order = {
			orderId: "test-order",
			amount: 10,
			currency: CurrencyEnum.Aed,
			transactions: [transactionA, transactionB, transactionC, transactionD],
		};

		fixture.detectChanges();

		expect(component.voidableInfoList).toEqual([
			{
				canBeVoided: false,
				enabledToBeVoided: false,
				transaction: transactionD,
			},
			{
				canBeVoided: false,
				enabledToBeVoided: false,
				transaction: transactionA,
			},
			{
				canBeVoided: false,
				enabledToBeVoided: false,
				transaction: transactionB,
			},
			{
				canBeVoided: false,
				enabledToBeVoided: false,
				transaction: transactionC,
			},
		]);
	});

	describe("completion", () => {
		it("it should return undefined for SALE transaction", () => {
			component.order = REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE;
			fixture.detectChanges();
			expect(fixture).toMatchSnapshot();
			expect(component.validPreAuthInfo).toBeUndefined();
		});
		it("it should return undefined for POST AUTH captured/settled transaction", () => {
			component.order = REPORTING_API_ORDER_DETAILS_COMPLETION_MOCK_RESPONSE;
			fixture.detectChanges();
			expect(fixture).toMatchSnapshot();
			expect(component.validPreAuthInfo).toBeUndefined();
		});

		it("it should return undefined for PREAUTH DECLINED transaction", () => {
			component.order =
				REPORTING_API_ORDER_DETAILS_PREAUTH_DECLINED_MOCK_RESPONSE;
			fixture.detectChanges();
			expect(fixture).toMatchSnapshot();
			expect(component.validPreAuthInfo).toBeUndefined();
		});

		it("it should return valid PREAUTH transaction", () => {
			component.order = REPORTING_API_ORDER_DETAILS_PREAUTH_MOCK_RESPONSE;
			fixture.detectChanges();
			expect(fixture).toMatchSnapshot();
			expect(component.validPreAuthInfo).toBeDefined();
		});
	});
});
