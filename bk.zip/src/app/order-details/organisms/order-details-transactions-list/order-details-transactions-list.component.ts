import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	Input,
	Output,
} from "@angular/core";
import { VoidableInfo } from "services/void/void-ability-checking.model";
import { VoidAbilityCheckingService } from "services/void/void-ability-checking.service";
import {
	OrderReportResponse,
	TransactionInfo,
	TransactionState,
	TransactionType,
} from "bff-client";
import { AuthenticationService } from "@international-payment-platform/portal-core";
import { VTPaymentPermissions } from "enum/permissions.enum";

@Component({
	selector: "app-order-details-transactions-list",
	templateUrl: "./order-details-transactions-list.component.html",
	styleUrls: ["./order-details-transactions-list.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsTransactionsListComponent {
	@Input() set order(order: OrderReportResponse) {
		this.voidableInfoList =
			this.voidAbilityCheckingService.getTransactionsWithVoidAbilityInfo([
				...(order.transactions || []),
			]);

		if (
			!this.authenticationService
				.getPermissions()
				.includes(VTPaymentPermissions.EcomVTOrderDetailsActionVoid)
		) {
			this.voidableInfoList = this.voidableInfoList.map((transaction) => {
				transaction.enabledToBeVoided = false;
				return transaction;
			});
		}

		this.validPreAuthInfo = this.getValidPreAuthTransaction();
	}
	@Output()
	readonly refreshRequested: EventEmitter<void> = new EventEmitter<void>();

	voidableInfoList!: VoidableInfo<TransactionInfo>[];
	validPreAuthInfo?: VoidableInfo<TransactionInfo>;
	readonly userCanComplete = this.authenticationService
		.getPermissions()
		.includes(VTPaymentPermissions.EcomVTOrderDetailsActionCompletion);

	constructor(
		private voidAbilityCheckingService: VoidAbilityCheckingService,
		private authenticationService: AuthenticationService
	) {}

	voidableInfoTrackBy(
		index: number,
		item: VoidableInfo<TransactionInfo>
	): string {
		return `${index}_${item.transaction.ipgTransactionId}`;
	}

	getValidPreAuthTransaction(): VoidableInfo<TransactionInfo> | undefined {
		if (!this.voidableInfoList || !this.voidableInfoList.length) {
			return;
		}

		const hasValidPostAuthTransaction = this.voidableInfoList.some(
			({ transaction }) =>
				transaction.transactionType === TransactionType.Postauth &&
				(transaction.transactionState === TransactionState.Settled ||
					transaction.transactionState === TransactionState.Captured)
		);

		if (hasValidPostAuthTransaction) {
			return;
		}

		return this.voidableInfoList.find(
			({ transaction }) =>
				transaction.transactionType === TransactionType.Preauth &&
				transaction.transactionState === TransactionState.Authorized
		);
	}
}
