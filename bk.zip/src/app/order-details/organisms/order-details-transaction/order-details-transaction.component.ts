import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	Input,
	Output,
} from "@angular/core";
import { SHRINK_ANIMATION } from "animations/shrink.animation";
import { VoidableInfo } from "services/void/void-ability-checking.model";
import { TransactionInfo, TransactionResult } from "bff-client";

@Component({
	selector: "app-order-details-transaction",
	templateUrl: "./order-details-transaction.component.html",
	styleUrls: ["./order-details-transaction.component.scss"],
	animations: [SHRINK_ANIMATION],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsTransactionComponent {
	@Input() voidableInfo!: VoidableInfo<TransactionInfo>;
	@Input() isLatestTransaction!: boolean;
	@Input() isValidToComplete!: boolean;

	@Output() readonly refreshRequested: EventEmitter<void> =
		new EventEmitter<void>();
	opened = false;

	get stateColor(): "green" | "red" | "gray" {
		switch (this.voidableInfo?.transaction?.transactionResult) {
			case TransactionResult.Approved:
			case TransactionResult.Created:
				return "green";
			case TransactionResult.Declined:
			case TransactionResult.Failed:
			case TransactionResult.Fraud:
				return "red";
			case TransactionResult.Waiting:
			case TransactionResult.Partial:
			default:
				return "gray";
		}
	}
}
