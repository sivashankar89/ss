import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { REPORTING_API_TRANSACTION_APPROVED_MOCK } from "mocks/reporting_api/orders.mock";
import { TransactionResult } from "../../../../bff-client/model/transactionResult";
import { PipesMockModule } from "../../../../mocks/pipes/pipes.module.mock";

import { OrderDetailsTransactionComponent } from "./order-details-transaction.component";

describe("OrderDetailsTransactionComponent", () => {
	let component: OrderDetailsTransactionComponent;
	let fixture: ComponentFixture<OrderDetailsTransactionComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [NoopAnimationsModule, PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
			declarations: [OrderDetailsTransactionComponent],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsTransactionComponent);
		component = fixture.componentInstance;
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should render template", () => {
		component.voidableInfo = {
			transaction: REPORTING_API_TRANSACTION_APPROVED_MOCK,
			canBeVoided: true,
			enabledToBeVoided: true,
		};
		component.opened = true;

		fixture.detectChanges();

		expect(fixture).toMatchSnapshot();
	});

	describe("stateColor", () => {
		beforeEach(() => {
			component.voidableInfo = {
				transaction: REPORTING_API_TRANSACTION_APPROVED_MOCK,
				canBeVoided: true,
				enabledToBeVoided: true,
			};
		});

		[TransactionResult.Approved].forEach((state) => {
			it(`should have green color for state ${state}`, () => {
				component.voidableInfo.transaction.transactionResult = state;
				fixture.detectChanges();

				expect(component.stateColor).toBe("green");
			});
		});

		[
			TransactionResult.Declined,
			TransactionResult.Fraud,
			TransactionResult.Failed,
		].forEach((state) => {
			it(`should have red color for state ${state}`, () => {
				component.voidableInfo.transaction.transactionResult = state;
				fixture.detectChanges();

				expect(component.stateColor).toBe("red");
			});
		});

		[TransactionResult.Partial, TransactionResult.Waiting].forEach((state) => {
			it(`should have gray color for state ${state}`, () => {
				component.voidableInfo.transaction.transactionResult = state;
				fixture.detectChanges();

				expect(component.stateColor).toBe("gray");
			});
		});
	});
});
