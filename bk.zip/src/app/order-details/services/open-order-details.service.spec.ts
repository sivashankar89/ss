import { fakeAsync, TestBed } from "@angular/core/testing";
import {
	CdsModalModule,
	CdsModalFullscreenModule,
	CdsModalService,
} from "@international-payment-platform/design-system-angular";
import { OpenOrderDetailsService } from "./open-order-details.service";
import { TitleService } from "@international-payment-platform/portal-core";
import { RouterTestingModule } from "@angular/router/testing";
import { Router } from "@angular/router";
import { SearchOrderComponent } from "../pages/search-order/search-order.component";
import { TranslateService } from "@tolgee/ngx";
import { TranslateServiceStub } from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { OrderDetailsModalComponent } from "order-details/pages";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";

describe("OpenOrderDetailsService", () => {
	let service: OpenOrderDetailsService;
	let cdsModalService: CdsModalService;
	let titleservice: TitleService;
	let router: Router;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [SearchOrderComponent, OrderDetailsModalComponent],
			imports: [
				CdsModalModule,
				CdsModalFullscreenModule,
				PipesMockModule,
				RouterTestingModule.withRoutes([
					{ path: "order-details/:id", component: SearchOrderComponent },
				]),
			],
			providers: [
				OpenOrderDetailsService,
				{
					provide: CdsModalService,
					useValue: {
						openModal: jest.fn(),
						closeModal: jest.fn(),
					},
				},
				{
					provide: TitleService,
					useValue: {
						setTitle: jest.fn(),
					},
				},
				{
					provide: TranslateService,
					useValue: TranslateServiceStub,
				},
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [OrderDetailsModalComponent],
			},
		});

		service = TestBed.inject(OpenOrderDetailsService);
		cdsModalService = TestBed.inject(CdsModalService);
		titleservice = TestBed.inject(TitleService);
		router = TestBed.inject(Router);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it(`should set 'orderId' and open the modal`, fakeAsync((done: any) => {
		jest.spyOn(router, "navigate");
		service.openOrderDetailsModal("1");
		expect(router.navigate).toHaveBeenCalled();
	}));

	it(`should not set 'orderId' and also not open the modal if 'orderId' is empty`, fakeAsync(() => {
		jest.spyOn(router, "navigate");
		service.openOrderDetailsModal("");
		expect(router.navigate).not.toHaveBeenCalled();
	}));

	it(`should deselect 'orderId'`, (done) => {
		service.closeOrderDetailsModal();
		service.orderId$.subscribe((response) => {
			expect(response).toEqual("");
			done();
		});
	});

	it(`should open Order Details`, (done) => {
		service.openOrderDetailsOnRouter("12345");
		service.orderId$.subscribe((response) => {
			expect(response).toEqual("12345");
			done();
		});
		expect(cdsModalService.openModal).toHaveBeenCalled();
	});

	it(`should not open Order Details on empty order id`, (done) => {
		service.openOrderDetailsOnRouter("");
		expect(cdsModalService.openModal).not.toHaveBeenCalled();
		done();
	});
});
