import { Injectable } from "@angular/core";
import { debounceTime, Observable, ReplaySubject } from "rxjs";
import { OrderDetailsAlertMessage } from "../model/alert-message.model";

@Injectable()
export class OrderDetailsAlertService {
	readonly alertMessageInfo$: Observable<OrderDetailsAlertMessage | undefined>;
	private readonly autoHide = new ReplaySubject<void>(1);
	private readonly alertMessageInfo = new ReplaySubject<
		OrderDetailsAlertMessage | undefined
	>(1);

	constructor() {
		this.autoHide
			.pipe(debounceTime(5000)) // 5 sec timeout
			.subscribe(() => this.showAlertMessage());
		this.alertMessageInfo$ = this.alertMessageInfo.asObservable();
	}

	showAlertMessage(alertInfo?: OrderDetailsAlertMessage): void {
		if (!alertInfo) {
			return this.alertMessageInfo.next(undefined);
		}
		this.autoHide.next();
		return this.alertMessageInfo.next(alertInfo);
	}

	showSuccessMessage(message: string): void {
		this.showAlertMessage({
			icon: "check-round",
			type: "success",
			content: message,
		});
	}

	showErrorMessage(message: string): void {
		this.showAlertMessage({
			icon: "error",
			type: "danger",
			content: message,
		});
	}
}
