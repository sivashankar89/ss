import { ComponentRef, Injectable } from "@angular/core";
import { BehaviorSubject, Observable, Subject } from "rxjs";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { OrderDetailsModalComponent } from "../pages/order-details-modal/order-details-modal.component";
import { TitleService } from "@international-payment-platform/portal-core";
import { Router } from "@angular/router";
import { TranslateService } from "@tolgee/ngx";

@Injectable()
export class OpenOrderDetailsService {
	readonly modalOpenState$: Observable<boolean>;
	private readonly orderIdSubject = new BehaviorSubject<string>("");
	private readonly modalOpenStateSubject = new Subject<boolean>();
	readonly orderId$: Observable<string> = this.orderIdSubject.asObservable();

	constructor(
		private modalService: CdsModalService,
		private titleService: TitleService,
		private router: Router,
		private translateService: TranslateService
	) {
		this.modalOpenState$ = this.modalOpenStateSubject.asObservable();
		this.orderId$.subscribe((value) => {
			this.modalOpenStateSubject.next(!!value);
		});
	}

	closeOrderDetailsModal(): void {
		this.orderIdSubject.next("");
		this.modalService.closeModal();
	}

	openOrderDetailsModal(orderId: string): void {
		this.titleService.setTitle(
			this.translateService.instantSafe("orders.order_details") +
				" | " +
				this.translateService.instantSafe("orders.manage_order")
		);
		if (orderId) {
			this.orderIdSubject.next(orderId);
			this.router.navigate(["/order-details/" + orderId]);
		}
	}

	// Open order details popup on deeplink
	openOrderDetailsOnRouter(
		orderId: string
	): ComponentRef<OrderDetailsModalComponent> | undefined {
		this.titleService.setTitle(
			this.translateService.instantSafe("orders.order_details") +
				" | " +
				this.translateService.instantSafe("orders.manage_order")
		);
		if (!!orderId) {
			this.orderIdSubject.next(orderId);
			return this.modalService.openModal(OrderDetailsModalComponent);
		}
		return;
	}
}
