import { TestBed } from "@angular/core/testing";
import { REPORTING_ORDER_DETAILS_ALERT_MOCK } from "../../../mocks/reporting_api/orders.mock";
import { OrderDetailsAlertService } from "./show-alert.service";

describe("OrderDetailsAlertService", () => {
	let service: OrderDetailsAlertService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [OrderDetailsAlertService],
		});

		service = TestBed.inject(OrderDetailsAlertService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it("should handle undefined alert message", () => {
		const spy = jest.fn();
		(service as any).alertMessageInfo.next = spy;
		service.showAlertMessage();

		expect(spy).toHaveBeenCalled();
	});

	it("should show the alert message with alert info provided", () => {
		const alertInfo = REPORTING_ORDER_DETAILS_ALERT_MOCK;

		const spy = jest.fn();
		(service as any).alertMessageInfo.next = spy;
		service.showAlertMessage(alertInfo);

		expect(spy).toHaveBeenCalled();
	});
});
