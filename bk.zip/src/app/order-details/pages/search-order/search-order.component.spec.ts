import { Location } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { of, throwError } from "rxjs";
import { ReportingOrdersService } from "../../../services/reporting/orders.service";
import {
	AuthenticationService,
	InstanceConfigService,
	TitleService,
} from "@international-payment-platform/portal-core";
import { SearchOrderComponent } from "./search-order.component";
import { TranslateService } from "@tolgee/ngx";
import {
	AuthenticationServiceStub,
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { OverlayModule } from "@angular/cdk/overlay";
import { TelemetryService } from "services/telemetry.service";

const TitleServiceStub: Partial<TitleService> = {
	setTitle: (titleLabel: string) => {},
};

describe("SearchOrderComponent", () => {
	let component: SearchOrderComponent;
	let fixture: ComponentFixture<SearchOrderComponent>;
	let orderDetailsService: ReportingOrdersService;
	let location: Location;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SearchOrderComponent],
			imports: [
				RouterTestingModule.withRoutes([
					{ path: "order-details/:id", component: SearchOrderComponent },
				]),
				HttpClientModule,
				OverlayModule,
				PipesMockModule,
			],
			providers: [
				ReportingOrdersService,
				{ provide: TitleService, useValue: TitleServiceStub },
				{
					provide: TranslateService,
					useValue: TranslateServiceStub,
				},
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SearchOrderComponent);
		location = TestBed.inject(Location);
		orderDetailsService = TestBed.inject(ReportingOrdersService);
		jest.spyOn(TitleServiceStub, "setTitle");
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("THEN should set title", () => {
		expect(TitleServiceStub.setTitle).toHaveBeenCalled();
	});

	it("should show invalid error", fakeAsync(() => {
		orderDetailsService.getOrderDetailsAndTransactions = jest
			.fn()
			.mockReturnValue(throwError(() => "Error"));
		component.getOrderDetailsAndTransactions("123");
		tick();
		expect(
			orderDetailsService.getOrderDetailsAndTransactions
		).toHaveBeenCalledWith("123");
		expect(component.error).toBeTruthy();
	}));

	it("should not show error on valid order", fakeAsync(() => {
		jest
			.spyOn(orderDetailsService, "getOrderDetailsAndTransactions")
			.mockReturnValue(of<any>({ orderId: "123" }));
		component.getOrderDetailsAndTransactions("123");
		tick();
		expect(
			orderDetailsService.getOrderDetailsAndTransactions
		).toHaveBeenCalledWith("123");
		expect(component.error).toBeFalsy();
	}));

	it("should not search on empty orderId", fakeAsync(() => {
		jest.spyOn(orderDetailsService, "getOrderDetailsAndTransactions");
		component.getOrderDetailsAndTransactions("");
		expect(
			orderDetailsService.getOrderDetailsAndTransactions
		).not.toHaveBeenCalled();
	}));

	it("should clear error if value changes to empty string", () => {
		component.error = { message: "test" };
		component.valueChange("");
		expect(component.error).toBeUndefined();
	});

	it("should call closeModal", () => {
		const modalService = fixture.debugElement.injector.get(CdsModalService);
		jest.spyOn(modalService, "closeModal");
		component.onClose();
		expect(modalService.closeModal).toHaveBeenCalled();
	});
});
