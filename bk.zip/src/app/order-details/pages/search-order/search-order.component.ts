import {
	ChangeDetectorRef,
	Component,
	EventEmitter,
	OnDestroy,
	Output,
} from "@angular/core";
import { Router } from "@angular/router";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { ReplaySubject, takeUntil } from "rxjs";
import { ApiErrorMessage } from "../../../model/error.model";
import { ReportingOrdersService } from "../../../services/reporting/orders.service";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";

@Component({
	selector: "app-search-order",
	templateUrl: "./search-order.component.html",
	styleUrls: ["./search-order.component.scss"],
})
export class SearchOrderComponent implements OnDestroy {
	@Output() destroy = new EventEmitter();
	error?: ApiErrorMessage;
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private router: Router,
		private modalService: CdsModalService,
		private reportingOrdersService: ReportingOrdersService,
		private titleService: TitleService,
		private cd: ChangeDetectorRef,
		private translateService: TranslateService
	) {
		this.titleService.setTitle(
			this.translateService.instantSafe("app.title_search") +
				" | " +
				this.translateService.instantSafe("shared.find_order")
		);
	}

	getOrderDetailsAndTransactions(orderId: string): void {
		orderId = orderId.trim();
		if (!!orderId) {
			this.reportingOrdersService
				.getOrderDetailsAndTransactions(orderId)
				.pipe(takeUntil(this.destroyed$))
				.subscribe({
					next: () => {
						this.router.navigate(["/order-details/" + orderId]);
					},
					error: () => {
						this.error = {
							message:
								this.translateService.instantSafe(
									"shared.message_invalid_oid"
								) +
								" " +
								this.translateService.instantSafe("shared.enter_valid_oid"),
						};
					},
				});
		}
	}

	valueChange(value: string): void {
		if (!value) {
			this.error = undefined;
		}
	}

	onClose(): void {
		this.modalService.closeModal();
	}

	ngOnDestroy(): void {
		this.destroy.emit();
		this.titleService.setTitle(
			this.translateService.instantSafe("app.title_transaction")
		);
	}
}
