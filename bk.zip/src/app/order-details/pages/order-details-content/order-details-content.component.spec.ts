import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE } from "mocks/reporting_api/orders.mock";
import { of } from "rxjs";
import { ReportingOrdersService } from "../../../services/reporting/orders.service";
import { OrderDetailsContentComponent } from "./order-details-content.component";

const reportingOrderServiceStub: Partial<ReportingOrdersService> = {
	getOrderDetailsAndTransactions: jest
		.fn()
		.mockReturnValue(of(REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE)),
};

describe("OrderDetailsContentComponent", () => {
	let component: OrderDetailsContentComponent;
	let fixture: ComponentFixture<OrderDetailsContentComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [OrderDetailsContentComponent],
			imports: [RouterTestingModule, PipesMockModule],
			providers: [
				{
					provide: ReportingOrdersService,
					useValue: reportingOrderServiceStub,
				},
			],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(OrderDetailsContentComponent);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it(`'isLoading' should be false initially`, () => {
		fixture.detectChanges();
		component.orderId = "A-395fad2e9c34-24357-45761-12345";
		expect(component.isLoading).toEqual(false);
		expect(fixture).toMatchSnapshot();
	});

	it("should display order details header", () => {
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"app-order-details-header"
		);
	});
});
