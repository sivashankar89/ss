import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { ReplaySubject, takeUntil } from "rxjs";
import { ReportingOrdersService } from "services/reporting/orders.service";
import { OrderDetailsAlertService } from "order-details/services/show-alert.service";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { AuthenticationService } from "@international-payment-platform/portal-core";
import {
	RecurringPaymentsInfo,
	TransactionResult,
	OrderReportResponse,
	Mcc6012,
	TransactionType,
	TransactionState,
} from "bff-client";

@Component({
	selector: "app-order-details-content",
	templateUrl: "./order-details-content.component.html",
	styleUrls: ["./order-details-content.component.scss"],
	providers: [OrderDetailsAlertService],
})
export class OrderDetailsContentComponent implements OnInit, OnDestroy {
	@Input() public orderId!: string;
	order!: OrderReportResponse;
	isLoading!: boolean;

	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private reportingOrdersService: ReportingOrdersService,
		private orderDetailsAlertService: OrderDetailsAlertService,
		private authenticationService: AuthenticationService
	) {}

	ngOnInit(): void {
		this.getOrderDetailsAndTransactions();
	}

	get hasRefundOption(): boolean {
		if (
			!this.authenticationService
				.getPermissions()
				.includes(VTPaymentPermissions.EcomVTOrderDetailsActionRefund)
		) {
			return false;
		}
		return this.order && this.order.amount && this.order.amount > 0
			? true
			: false;
	}

	get hasMcc6012Data(): boolean {
		return this.isNotEmptyObject(
			this.order.industrySpecificExtensions?.mcc6012
		);
	}

	get hasRecurringPayment(): boolean {
		return this.isNotEmptyObject(this.order?.recurringPaymentsInfo);
	}

	get cashback(): number {
		return (
			this.order.transactions?.reduce((cashback, transaction) => {
				if (
					!transaction.cashback ||
					transaction.cashback <= 0 ||
					transaction.transactionType !== TransactionType.Sale ||
					transaction.transactionResult !== TransactionResult.Approved ||
					[TransactionState.Captured, TransactionState.Settled].includes(
						transaction.transactionState as any
					) === false
				) {
					return cashback;
				}
				return cashback + transaction.cashback;
			}, 0) || 0
		);
	}

	get orderBalance(): number {
		return this.order.amount || 0;
	}

	private isNotEmptyObject(obj?: Mcc6012 | RecurringPaymentsInfo): boolean {
		return !!obj && !!Object.keys(obj).length;
	}

	getOrderDetailsAndTransactions(loading = true): void {
		this.isLoading = loading;
		this.reportingOrdersService
			.getOrderDetailsAndTransactions(this.orderId)
			.pipe(takeUntil(this.destroyed$))
			.subscribe({
				next: (order) => {
					this.isLoading = false;
					this.order = order;
				},
				error: () => {
					this.isLoading = false;
				},
			});
	}

	ngOnDestroy(): void {
		this.orderDetailsAlertService.showAlertMessage(); // Alert has been set undefined here.
		this.destroyed$.next();
		this.destroyed$.complete();
	}
}
