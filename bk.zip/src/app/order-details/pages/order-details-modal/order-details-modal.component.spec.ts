import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";
import { OrderDetailsModalComponent } from "./order-details-modal.component";

describe("OrderDetailsModalComponent", () => {
	let component: OrderDetailsModalComponent;
	let fixture: ComponentFixture<OrderDetailsModalComponent>;
	let orderOpenDetails: OpenOrderDetailsService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [OrderDetailsModalComponent],
			providers: [
				{
					provide: OpenOrderDetailsService,
					useValue: {
						orderId$: jest.fn(),
						closeOrderDetailsModal: jest.fn(),
					},
				},
			],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(OrderDetailsModalComponent);
		component = fixture.componentInstance;
		orderOpenDetails = TestBed.inject(OpenOrderDetailsService);
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("should close modal on destroy", () => {
		component.ngOnDestroy();
		expect(orderOpenDetails.closeOrderDetailsModal).toHaveBeenCalled();
	});
});
