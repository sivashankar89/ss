import { Component, EventEmitter, OnDestroy, Output } from "@angular/core";
import { Observable } from "rxjs";
import { OpenOrderDetailsService } from "../../services/open-order-details.service";

@Component({
	selector: "app-order-details-modal",
	templateUrl: "./order-details-modal.component.html",
})
export class OrderDetailsModalComponent implements OnDestroy {
	readonly orderId$: Observable<string>;
	@Output() destroy = new EventEmitter();

	constructor(private openOrderDetailsService: OpenOrderDetailsService) {
		this.orderId$ = openOrderDetailsService.orderId$;
	}

	ngOnDestroy(): void {
		this.openOrderDetailsService.closeOrderDetailsModal();
		this.destroy.emit();
	}
}
