import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { ReplaySubject, takeUntil } from "rxjs";
import { RedirectCallbackService } from "services/redirect/redirect-callback.service";
import { OpenOrderDetailsService } from "../../services/open-order-details.service";
import { SearchOrderComponent } from "../search-order/search-order.component";

@Component({
	selector: "app-search-order-layout",
	template: "",
})
export class SearchOrderLayoutComponent implements OnInit, OnDestroy {
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private router: Router,
		private route: ActivatedRoute,
		private openOrderDetailsService: OpenOrderDetailsService,
		private modalService: CdsModalService,
		private redirectService: RedirectCallbackService
	) {}

	ngOnInit(): void {
		this.redirectService.init();

		this.route.params.pipe(takeUntil(this.destroyed$)).subscribe((params) => {
			let modalRef;
			if (params.id) {
				modalRef = this.openOrderDetailsService.openOrderDetailsOnRouter(
					params.id
				);
			} else {
				modalRef = this.modalService.openModal(SearchOrderComponent);
			}
			if (!!modalRef) {
				modalRef.instance.destroy
					.pipe(takeUntil(this.destroyed$))
					.subscribe(() => this.redirectService.return());
			}
		});
	}

	ngOnDestroy(): void {
		this.redirectService.destroy();
		this.destroyed$.next();
		this.destroyed$.complete();
		this.modalService.closeModal();
	}
}
