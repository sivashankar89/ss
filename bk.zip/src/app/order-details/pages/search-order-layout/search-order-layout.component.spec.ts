import {
	ComponentFixture,
	fakeAsync,
	TestBed,
	tick,
} from "@angular/core/testing";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { ActivatedRoute } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { CdsModalService } from "@international-payment-platform/design-system-angular";
import { of } from "rxjs";
import { OpenOrderDetailsService } from "../../services/open-order-details.service";
import { SearchOrderComponent } from "../search-order/search-order.component";
import { SearchOrderLayoutComponent } from "./search-order-layout.component";
import { TitleService } from "@international-payment-platform/portal-core";
import { TranslateService } from "@tolgee/ngx";
import { TranslateServiceStub } from "mocks/services/services.mock";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { OverlayModule } from "@angular/cdk/overlay";

describe("SearchOrderLayoutComponent", () => {
	let component: SearchOrderLayoutComponent;
	let fixture: ComponentFixture<SearchOrderLayoutComponent>;
	let modalService: CdsModalService;
	let route: ActivatedRoute;
	let openOrderDetailsService: OpenOrderDetailsService;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [SearchOrderLayoutComponent, SearchOrderComponent],
			imports: [RouterTestingModule, OverlayModule, PipesMockModule],
			providers: [
				OpenOrderDetailsService,
				{
					provide: TitleService,
					useValue: {
						setTitle: jest.fn(),
					},
				},
				{
					provide: TranslateService,
					useValue: TranslateServiceStub,
				},
			],
			schemas: [NO_ERRORS_SCHEMA],
		})
			.overrideModule(BrowserDynamicTestingModule, {
				set: {
					entryComponents: [SearchOrderComponent],
				},
			})
			.compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(SearchOrderLayoutComponent);
		component = fixture.componentInstance;
		modalService = TestBed.inject(CdsModalService);
		route = TestBed.inject(ActivatedRoute);
		openOrderDetailsService = TestBed.inject(OpenOrderDetailsService);
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should get params", fakeAsync(() => {
		route.params = of({});
		jest.spyOn(modalService, "openModal");
		jest.spyOn(openOrderDetailsService, "openOrderDetailsOnRouter");
		component.ngOnInit();
		tick();
		expect(
			openOrderDetailsService.openOrderDetailsOnRouter
		).not.toHaveBeenCalled();
		expect(modalService.openModal).toHaveBeenCalledWith(SearchOrderComponent);
	}));

	it("should close modal on destroy", () => {
		jest.spyOn(modalService, "closeModal");
		component.ngOnDestroy();
		expect(modalService.closeModal).toHaveBeenCalled();
	});
});
