import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { OrderDetailsTransactionDetailComponent } from "./order-details-transaction-detail.component";

describe("OrderDetailsTransactionDetailComponent", () => {
	let component: OrderDetailsTransactionDetailComponent;
	let fixture: ComponentFixture<OrderDetailsTransactionDetailComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [OrderDetailsTransactionDetailComponent],
			imports: [PipesMockModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsTransactionDetailComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
