import { ChangeDetectionStrategy, Component, Input } from "@angular/core";

@Component({
	selector: "app-order-details-transaction-detail",
	templateUrl: "./order-details-transaction-detail.component.html",
	styleUrls: ["./order-details-transaction-detail.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsTransactionDetailComponent {
	@Input() label!: string;
	@Input() value!: string | null | undefined;
	@Input() mainRow: "label" | "value" = "value";
	@Input() includesCopyToClipboard = false;
	@Input() hasHintInfo = false;
	@Input() hintLabel!: string;
	@Input() hintValue!: string | null | undefined;
	@Input() isCard = false;

	copyToClipboard(): void {
		if (!this.value) {
			return;
		}

		navigator.clipboard.writeText(this.value);
	}
}
