export * from "./order-details-transaction-detail/order-details-transaction-detail.component";
export * from "./order-details-general-detail/order-details-general-detail.component";
