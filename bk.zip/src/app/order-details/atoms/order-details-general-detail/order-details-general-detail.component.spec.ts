import { ComponentFixture, TestBed } from "@angular/core/testing";
import { OrderDetailsGeneralDetailComponent } from "./order-details-general-detail.component";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { TComponent, TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

describe("DetailsEntryAtomComponent", () => {
	let component: OrderDetailsGeneralDetailComponent;
	let fixture: ComponentFixture<OrderDetailsGeneralDetailComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [OrderDetailsGeneralDetailComponent, TComponent],
			imports: [PipesMockModule],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(OrderDetailsGeneralDetailComponent);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("should render component", () => {
		component.key = "test key";
		component.value = "test value";

		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"test key"
		); // key
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"test value"
		); // value
	});
});
