import { ChangeDetectionStrategy, Component, Input } from "@angular/core";

@Component({
	selector: "app-order-details-general-detail",
	templateUrl: "order-details-general-detail.component.html",
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsGeneralDetailComponent {
	@Input() key!: string;
	@Input() value?: string | null;
	@Input() rawValue?: boolean;
	@Input() isPreTag = false;
}
