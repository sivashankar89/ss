import { Component, Input } from "@angular/core";

@Component({
	selector: "app-order-details-mcc-detail",
	templateUrl: "./order-details-mcc-detail.component.html",
	styleUrls: ["./order-details-mcc-detail.component.scss"],
})
export class OrderDetailsMccDetailComponent {
	@Input() label!: string;
	@Input() value!: string | null | undefined;
	@Input() isPAN = false;
	@Input() isDate = false;
}
