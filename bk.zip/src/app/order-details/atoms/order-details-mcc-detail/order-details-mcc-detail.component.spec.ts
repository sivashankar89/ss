import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { CdsDataPresenterModule } from "@international-payment-platform/design-system-angular";
import { PipesMockModule } from "../../../../mocks/pipes/pipes.module.mock";
import { OrderDetailsMccDetailComponent } from "./order-details-mcc-detail.component";

describe("OrderDetailsMccDetailComponent", () => {
	let component: OrderDetailsMccDetailComponent;
	let fixture: ComponentFixture<OrderDetailsMccDetailComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [OrderDetailsMccDetailComponent],
			imports: [PipesMockModule, CdsDataPresenterModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsMccDetailComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
