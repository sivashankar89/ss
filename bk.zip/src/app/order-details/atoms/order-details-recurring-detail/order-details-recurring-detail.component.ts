import { Component, Input } from "@angular/core";

@Component({
	selector: "app-order-details-recurring-detail",
	templateUrl: "./order-details-recurring-detail.component.html",
	styleUrls: ["./order-details-recurring-detail.component.scss"],
})
export class OrderDetailsRecurringDetailComponent {
	@Input() label!: string;
	@Input() value!: string | number | null | undefined;
}
