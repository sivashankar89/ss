import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { CdsDataPresenterModule } from "@international-payment-platform/design-system-angular";
import { PipesMockModule } from "../../../../mocks/pipes/pipes.module.mock";
import { OrderDetailsRecurringDetailComponent } from "./order-details-recurring-detail.component";

describe("OrderDetailsRecurringDetailComponent", () => {
	let component: OrderDetailsRecurringDetailComponent;
	let fixture: ComponentFixture<OrderDetailsRecurringDetailComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			declarations: [OrderDetailsRecurringDetailComponent],
			imports: [PipesMockModule, CdsDataPresenterModule],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsRecurringDetailComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
