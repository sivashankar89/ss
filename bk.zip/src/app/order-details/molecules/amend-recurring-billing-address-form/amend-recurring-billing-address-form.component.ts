import {
	Component,
	EventEmitter,
	Input,
	OnChanges,
	Output,
	SimpleChanges,
	ViewChild,
} from "@angular/core";
import { BillingAddress } from "bff-client";
import { PrimaryBillingDetailsComponent } from "shared/components/molecules/primary-billing-details/primary-billing-details.component";

@Component({
	selector: "app-amend-recurring-billing-address-form",
	templateUrl: "./amend-recurring-billing-address-form.component.html",
})
export class AmendRecurringBillingAddressFormComponent implements OnChanges {
	@Input() billing!: BillingAddress;
	@Output() onChangeAddress = new EventEmitter();
	@ViewChild(PrimaryBillingDetailsComponent)
	billingComponent!: PrimaryBillingDetailsComponent;
	isValid = true;
	expandedAddress = {
		billing: false,
		delivery: false,
	};
	modifiedBilling!: BillingAddress;

	ngOnChanges(changes: SimpleChanges): void {
		if (changes.billing && changes.billing.currentValue) {
			this.modifiedBilling = this.convertBillingForForm(
				changes.billing.currentValue
			);
		}
	}

	convertBillingForForm(billing: BillingAddress): BillingAddress {
		return {
			name: billing.name,
			address: {
				address1: billing.addressLine1,
				address2: billing.addressLine2,
				city: billing.city,
				region: billing.state,
				postalCode: billing.zip,
				country: billing.country,
				company: billing.company,
			},
			contact: {
				email: billing.email,
				fax: billing.fax,
				phone: billing.phone,
			},
		};
	}

	toggleOpenAddress(address: "billing" | "delivery"): void {
		this.modifiedBilling = this.convertBillingForForm(this.billing);
		this.expandedAddress[address] = !this.expandedAddress[address];
	}

	onChangeFormEvent(billing: BillingAddress): void {
		this.modifiedBilling = billing;
		this.onChangeAddress.emit(billing);
	}
}
