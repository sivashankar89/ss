import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { FormsModule, NgForm } from "@angular/forms";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { AmendRecurringBillingAddressFormComponent } from "./amend-recurring-billing-address-form.component";
import { PrimaryBillingDetailsComponent } from "shared/components/molecules/primary-billing-details/primary-billing-details.component";

describe("AmendRecurringBillingAddressFormComponent", () => {
	let component: AmendRecurringBillingAddressFormComponent;
	let fixture: ComponentFixture<AmendRecurringBillingAddressFormComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [FormsModule, PipesMockModule],
			declarations: [
				AmendRecurringBillingAddressFormComponent,
				PrimaryBillingDetailsComponent,
			],
			providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(
			AmendRecurringBillingAddressFormComponent
		);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
