import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PAYMENTS_ORDER_DETAILS_MOCK_RESPONSE } from "mocks/payment_api/order-details.mock";
import { TransactionPrintReceiptBillingDetailsComponent } from "./transaction-print-receipt-billing-details.component";

describe("TransactionPrintReceiptBillingDetailsComponent", () => {
	let component: TransactionPrintReceiptBillingDetailsComponent;
	let fixture: ComponentFixture<TransactionPrintReceiptBillingDetailsComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [TransactionPrintReceiptBillingDetailsComponent],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(
			TransactionPrintReceiptBillingDetailsComponent
		);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("should render component with billing details", () => {
		component.key = "Test address";
		component.billing = {
			...PAYMENTS_ORDER_DETAILS_MOCK_RESPONSE.billing,
			contact: {
				phone: "123",
				email: "test@test.com",
			},
		};

		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"Sandy Springs"
		); // city
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"John Doe"
		); // name
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"123 Main St."
		); // address 1
	});
});
