import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { BillingAddress } from "bff-client";

@Component({
	selector: "app-transaction-print-receipt-billing-details",
	templateUrl: "transaction-print-receipt-billing-details.component.html",
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TransactionPrintReceiptBillingDetailsComponent {
	@Input() key!: string;
	@Input() billing!: BillingAddress | undefined;
}
