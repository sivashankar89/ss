import { DatePipe } from "@angular/common";
import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Frequency, RecurringPaymentsInfo } from "bff-client";
import { RecurringOrderService } from "services/recurring-order.service";
import { SelectOption } from "shared/models/select-options";
import { isDatePast, isDateToday } from "utils/common.utils";

@Component({
	selector: "app-amend-recurring-details-form",
	templateUrl: "./amend-recurring-details-form.component.html",
})
export class AmendRecurringDetailsFormComponent implements OnInit {
	@Input() recurring!: RecurringPaymentsInfo;
	@ViewChild("amendRecurringForm") form!: NgForm;
	recurringOpions!: Array<SelectOption<string>>;
	delayOptions!: Array<SelectOption<string>>;
	minDate = new Date();

	constructor(
		private recurringService: RecurringOrderService,
		private datePipe: DatePipe
	) {}

	get disableStartDate(): boolean {
		if (!this.recurring) {
			return false;
		}
		const { startDate, nextAttemptDate } = this.recurring;
		if (startDate && isDateToday(new Date(startDate))) {
			return true;
		}
		if (startDate && isDatePast(new Date(startDate))) {
			return true;
		}
		if (nextAttemptDate && isDateToday(new Date(nextAttemptDate))) {
			return true;
		}
		return false;
	}

	get repeatDelay(): "Never" | "afterDelay" {
		return this.recurring?.numberOfPayments === 999 ? "Never" : "afterDelay";
	}

	ngOnInit(): void {
		this.minDate.setDate(this.minDate.getDate() - 1);
		this.recurringOpions = this.recurringService.getRecurringOptionLists();
		this.delayOptions = this.recurringService.getDelayOptionList();
	}

	onDelayChange(delayOption: string): void {
		this.updateRecurringInfo(
			"numberOfPayments",
			delayOption === "Never" ? 999 : 1
		);
	}

	updateRecurringInfo(key: keyof RecurringPaymentsInfo, value: any) {
		if (!this.recurring) {
			this.recurring = {};
		}
		if (key === "startDate") {
			value = this.datePipe.transform(value, "yyyy-MM-dd")?.toString();
		}
		this.recurring[key] = value;
	}

	updateRecurringFrequency(key: keyof Frequency, value: any) {
		const frequency: Frequency = this.recurring?.frequency || {};
		frequency[key] = value;
		this.updateRecurringInfo("frequency", frequency);
	}
}
