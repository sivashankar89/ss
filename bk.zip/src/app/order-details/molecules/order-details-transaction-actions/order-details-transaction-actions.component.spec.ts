import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { Router } from "@angular/router";
import { TComponent, TranslateService } from "@tolgee/ngx";
import { ReportingPaymentType, TransactionInfo } from "bff-client";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { PopupService } from "popup/popup.service";
import { VoidableInfo } from "services/void/void-ability-checking.model";
import { VoidTransactionService } from "services/void/void-transaction.service";
import { SendEmailNotificationService } from "../../../services/reporting/send-email-notification.service";
import { OrderDetailsAlertService } from "../../services/show-alert.service";
import { OrderDetailsTransactionActionsComponent } from "./order-details-transaction-actions.component";
import { TelemetryService } from "services/telemetry.service";

const VALID_VOIDABLE_INFO = {
	transaction: {
		transactionTime: 0,
		orderId: "12345",
		ipgTransactionId: "838916029301",
	},
	canBeVoided: true,
	enabledToBeVoided: true,
};

describe("OrderDetailsTransactionActionsComponent", () => {
	let component: OrderDetailsTransactionActionsComponent;
	let fixture: ComponentFixture<OrderDetailsTransactionActionsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			schemas: [NO_ERRORS_SCHEMA],
			declarations: [OrderDetailsTransactionActionsComponent, TComponent],
			imports: [PipesMockModule, HttpClientTestingModule],
			providers: [
				{ provide: PopupService, useValue: {} },
				{ provide: VoidTransactionService, useValue: {} },
				{ provide: OrderDetailsAlertService, useValue: {} },
				{ provide: Router, useValue: {} },
				{ provide: SendEmailNotificationService, useValue: {} },
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsTransactionActionsComponent);
		component = fixture.componentInstance;
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	describe("void", () => {
		it("should display void button", () => {
			component.voidableInfo = VALID_VOIDABLE_INFO;
			fixture.detectChanges();

			expect(fixture).toMatchSnapshot();
		});

		it("should not display void button", () => {
			component.voidableInfo = {
				...VALID_VOIDABLE_INFO,
				enabledToBeVoided: false,
			};
			fixture.detectChanges();

			expect(fixture).toMatchSnapshot();
		});
	});
	describe("voidTransaction", () => {
		it("should handle lack of voidableInfo", () => {
			try {
				component.voidTransaction();
			} catch (error) {
				expect(error).toEqual(new Error(`'voidableInfo' needs to be provided`));
			}
		});

		it("should handle request while processing", () => {
			const voidTransactionService = fixture.debugElement.injector.get(
				VoidTransactionService
			);
			voidTransactionService.voidTransaction = jest.fn();

			component.voidableInfo = VALID_VOIDABLE_INFO;
			component.isProcessingVoid = true;
			component.voidTransaction();

			expect(voidTransactionService.voidTransaction).not.toHaveBeenCalled();
		});
	});

	describe("openPrintReceiptPopup", () => {
		it("should handle lack of voidableInfo", () => {
			try {
				component.openPrintReceiptPopup();
			} catch (error) {
				expect(error).toEqual(new Error(`'voidableInfo' needs to be provided`));
			}
		});

		it("should allow to print transaction", () => {
			component.voidableInfo = {
				transaction: {
					paymentType: ReportingPaymentType.Creditcard,
				},
			} as VoidableInfo<TransactionInfo>;
			component.ngOnChanges();
			fixture.detectChanges();

			expect(component.isPrintReceiptAvailable).toBeTruthy();
			expect(fixture).toMatchSnapshot();
		});

		it("should not allow to print transaction (no payment type)", () => {
			component.voidableInfo = {
				transaction: {},
			} as VoidableInfo<TransactionInfo>;
			component.ngOnChanges();
			fixture.detectChanges();

			expect(component.isPrintReceiptAvailable).toBeFalsy();
			expect(fixture).toMatchSnapshot();
		});

		it("should not allow to print transaction (payment link)", () => {
			component.voidableInfo = {
				transaction: {
					paymentType: ReportingPaymentType.Paymentlink,
				},
			} as VoidableInfo<TransactionInfo>;
			component.ngOnChanges();
			fixture.detectChanges();

			expect(component.isPrintReceiptAvailable).toBeFalsy();
			expect(fixture).toMatchSnapshot();
		});

		it("should handle not available print receipt", () => {
			component.voidableInfo = VALID_VOIDABLE_INFO;
			component.isPrintReceiptAvailable = false;

			try {
				component.openPrintReceiptPopup();
			} catch (error) {
				expect(error).toEqual(
					new Error(`Print is not supported for this transaction`)
				);
			}
		});

		it("should handle lack of order id and transaction id in voidableInfo", () => {
			component.voidableInfo = {
				canBeVoided: true,
				enabledToBeVoided: true,
				transaction: {
					transactionTime: 0,
					orderId: "",
					ipgTransactionId: "",
				},
			};

			try {
				component.openPrintReceiptPopup();
			} catch (error) {
				expect(error).toEqual(
					new Error(`'orderId' or 'transactionId' was not found`)
				);
			}
		});

		it("should focus on existing reference", () => {
			const popupService = fixture.debugElement.injector.get(PopupService);
			const focusSpy = jest.fn();
			popupService.getById = jest.fn().mockReturnValue({
				focus: focusSpy,
			});
			component.voidableInfo = VALID_VOIDABLE_INFO;
			component.openPrintReceiptPopup();

			expect(focusSpy).toHaveBeenCalled();
		});

		it(`should execute 'openPrintReceiptPopup' function on click print receipt button`, () => {
			const popupService = fixture.debugElement.injector.get(PopupService);
			popupService.open = jest.fn();
			popupService.getById = jest.fn();

			component.voidableInfo = VALID_VOIDABLE_INFO;
			component.openPrintReceiptPopup();
			expect(popupService.open).toHaveBeenCalled();
		});
	});

	describe("send notification", () => {
		it("should handle lack of voidableInfo", () => {
			try {
				component.sendEmailNotification();
			} catch (error) {
				expect(error).toEqual(new Error(`'voidableInfo' needs to be provided`));
			}
		});
	});

	describe("opened", () => {
		it('should trigger "opened" change - open', () => {
			jest.spyOn(component.openedChange, "emit");

			(fixture.debugElement.nativeElement as HTMLElement)
				.querySelector(".expand")
				?.dispatchEvent(new MouseEvent("click"));

			expect(component.openedChange.emit).toHaveBeenCalledWith(true);
		});

		it('should trigger "opened" change - close', () => {
			jest.spyOn(component.openedChange, "emit");
			component.opened = true;

			(fixture.debugElement.nativeElement as HTMLElement)
				.querySelector(".expand")
				?.dispatchEvent(new MouseEvent("click"));

			expect(component.openedChange.emit).toHaveBeenCalledWith(false);
		});
	});

	describe("completion", () => {
		it("should perform completion", () => {
			const router = fixture.debugElement.injector.get(Router);
			router.navigate = jest.fn().mockReturnValue(new Promise(jest.fn()));

			component.completionTransaction();
			fixture.detectChanges();

			expect(router.navigate).toHaveBeenCalled();
		});
	});
});
