import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	Input,
	OnChanges,
	OnDestroy,
	Output,
} from "@angular/core";
import { Router } from "@angular/router";
import { TranslateService } from "@tolgee/ngx";
import { PopupRef } from "popup/popup-ref";
import { PopupService } from "popup/popup.service";
import { ReplaySubject, takeUntil } from "rxjs";
import { VoidableInfo } from "services/void/void-ability-checking.model";
import { VoidTransactionService } from "services/void/void-transaction.service";
import { SendEmailNotificationService } from "../../../services/reporting/send-email-notification.service";
import { PrintPopupInputData } from "../../model/order-details.model";
import { TransactionPrintReceiptContentComponent } from "../../organisms";
import { OrderDetailsAlertService } from "../../services/show-alert.service";
import { ReportingPaymentType, TransactionInfo } from "bff-client";
import { PlatformLocation } from "@angular/common";
import { VTPaymentPermissions } from "enum/permissions.enum";
import { CompletionService } from "completion/services/completion.service";
@Component({
	selector: "app-order-details-transaction-actions",
	templateUrl: "./order-details-transaction-actions.component.html",
	styleUrls: ["./order-details-transaction-actions.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsTransactionActionsComponent
	implements OnChanges, OnDestroy
{
	@Input() voidableInfo?: VoidableInfo<TransactionInfo>;
	@Input() isLatestTransaction!: boolean;
	@Input() isValidToComplete!: boolean;
	@Input() opened!: boolean | undefined;

	@Output() readonly openedChange = new EventEmitter<boolean>();
	@Output() readonly transactionActionPerformed: EventEmitter<void> =
		new EventEmitter<void>();
	isProcessingVoid!: boolean;
	isProcessingSendNotification!: boolean;
	isProcessingCompletion!: boolean;
	isPrintReceiptAvailable = true;
	paymentPermissions = VTPaymentPermissions;
	private popupRef!: PopupRef<TransactionPrintReceiptContentComponent>;
	private readonly destroyed$: ReplaySubject<void> = new ReplaySubject<void>(1);

	constructor(
		private readonly platformLocation: PlatformLocation,
		private orderDetailsAlertService: OrderDetailsAlertService,
		private popupService: PopupService,
		private voidTransactionService: VoidTransactionService,
		private sendNotificationService: SendEmailNotificationService,
		private router: Router,
		private translateService: TranslateService,
		private completionService: CompletionService
	) {}

	ngOnChanges(): void {
		this.isPrintReceiptAvailable =
			!!this.voidableInfo?.transaction.paymentType &&
			this.voidableInfo?.transaction.paymentType !==
				ReportingPaymentType.Paymentlink;
	}

	sendEmailNotification(): void {
		if (!this.voidableInfo) {
			throw new Error(`'voidableInfo' needs to be provided`);
		}

		if (this.isProcessingSendNotification) {
			return;
		}

		this.isProcessingSendNotification = true;

		this.sendNotificationService
			.sendEmailNotification(this.voidableInfo.transaction)
			.pipe(takeUntil(this.destroyed$))
			.subscribe({
				next: () => {
					this.orderDetailsAlertService.showSuccessMessage(
						this.translateService.instantSafe("shared.message_notify")
					);
					this.transactionActionPerformed.emit();
					this.isProcessingSendNotification = false;
				},
				error: () => {
					this.orderDetailsAlertService.showErrorMessage(
						this.translateService.instantSafe("shared.message_request_declined")
					);
					this.transactionActionPerformed.emit();
					this.isProcessingSendNotification = false;
				},
			});
	}

	voidTransaction(): void {
		if (!this.voidableInfo) {
			throw new Error(`'voidableInfo' needs to be provided`);
		}

		if (this.isProcessingVoid) {
			return;
		}

		this.isProcessingVoid = true;

		const successMsg = this.translateService.instantSafe(
			"shared.message_requested_void"
		);
		const errorMsg = this.translateService.instantSafe(
			"shared.message_declined_void"
		);

		this.voidTransactionService
			.voidTransaction(this.voidableInfo.transaction)
			.pipe(takeUntil(this.destroyed$))
			.subscribe({
				next: (res) => {
					if (res.error) {
						this.orderDetailsAlertService.showErrorMessage(errorMsg);
					} else {
						this.orderDetailsAlertService.showSuccessMessage(successMsg);
					}
					this.transactionActionPerformed.emit();
					this.isProcessingVoid = false;
				},
				error: () => {
					this.orderDetailsAlertService.showErrorMessage(errorMsg);
					this.transactionActionPerformed.emit();
					this.isProcessingVoid = false;
				},
			});
	}

	openPrintReceiptPopup(): void {
		if (!this.voidableInfo) {
			throw new Error(`'voidableInfo' needs to be provided`);
		}

		if (!this.isPrintReceiptAvailable) {
			throw new Error(`Print is not supported for this transaction`);
		}

		const orderId = this.voidableInfo.transaction.orderId;
		const transactionId = this.voidableInfo.transaction.ipgTransactionId;

		if (!orderId || !transactionId) {
			throw new Error(`'orderId' or 'transactionId' was not found`);
		}

		const existingRef = this.popupService.getById(transactionId);
		if (existingRef) {
			existingRef.focus();
			return;
		}

		this.popupRef = this.popupService.open<
			TransactionPrintReceiptContentComponent,
			PrintPopupInputData
		>(TransactionPrintReceiptContentComponent, {
			data: { orderId, transactionId },
			title: "Print receipt",
			id: transactionId,
			windowFeatures: `popup=true,screenX=0,screenY=0,width=${window.innerWidth},height=${window.innerHeight}`,
		});
	}

	completionTransaction(): void {
		this.isProcessingCompletion = true;
		this.completionService.isAmountPrePopulated = false;
		const orderId = this.voidableInfo?.transaction.orderId;
		this.router
			.navigate(["/virtual-terminal/completion/" + orderId], {
				queryParams: { callback: orderId ? this.getCallbackUrl() : "" },
			})
			.then(() => (this.isProcessingCompletion = false))
			.catch(() => (this.isProcessingCompletion = false));
	}

	getCallbackUrl(): string {
		return (this.platformLocation as any).hash;
	}

	ngOnDestroy(): void {
		this.destroyed$.next();
		this.destroyed$.complete();

		if (this.popupRef) {
			this.popupRef.close();
		}
	}
}
