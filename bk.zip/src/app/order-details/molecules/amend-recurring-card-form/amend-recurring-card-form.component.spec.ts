import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule, NgForm } from "@angular/forms";
import { TranslateService } from "@tolgee/ngx";
import { DatePipe } from "@angular/common";
import { CdsDatepickerModule } from "@international-payment-platform/design-system-angular";
import { RecurringOrderService } from "services/recurring-order.service";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { TranslateServiceStub } from "mocks/services/services.mock";

import { AmendRecurringCardFormComponent } from "./amend-recurring-card-form.component";

describe("AmendRecurringCardFormComponent", () => {
	let component: AmendRecurringCardFormComponent;
	let fixture: ComponentFixture<AmendRecurringCardFormComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [
				FormsModule,
				HttpClientModule,
				CdsDatepickerModule,
				PipesMockModule,
			],
			declarations: [AmendRecurringCardFormComponent],
			providers: [
				DatePipe,
				RecurringOrderService,
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: NgForm, useValue: new NgForm([], []) },
			],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(AmendRecurringCardFormComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
