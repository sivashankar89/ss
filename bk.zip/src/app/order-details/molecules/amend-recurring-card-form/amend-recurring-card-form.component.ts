import {
	Component,
	Input,
	OnChanges,
	SimpleChanges,
	ViewChild,
} from "@angular/core";
import { NgForm } from "@angular/forms";
import {
	CdsCardInputNumberComponent,
	CdsModalService,
	CdsPaymentBrand,
} from "@international-payment-platform/design-system-angular";
import { PaymentCard, TransactionAmount } from "bff-client";
import { StoreCardBrandsComponent } from "shared/components/molecules/store-card-brands/store-card-brands.component";

@Component({
	selector: "app-amend-recurring-card-form",
	templateUrl: "./amend-recurring-card-form.component.html",
	styleUrls: ["./amend-recurring-card-form.component.scss"],
})
export class AmendRecurringCardFormComponent implements OnChanges {
	@Input() displayPaymentCard!: PaymentCard;
	@Input() amount!: TransactionAmount;
	@Input() isSubmitted = false;
	@ViewChild("cardForm") form!: NgForm;
	@ViewChild(CdsCardInputNumberComponent)
	cardBrandNumber!: CdsCardInputNumberComponent;
	brandType: CdsPaymentBrand | undefined;
	canUpdate = false;
	paymentCard!: PaymentCard;
	displayAmount!: TransactionAmount;

	constructor(private modalService: CdsModalService) {}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes.amount && changes.amount.currentValue) {
			this.displayAmount = { ...changes.amount.currentValue };
		}

		if (changes.isSubmitted && changes.isSubmitted.currentValue) {
			const controls = this.form.form.controls;
			Object.keys(controls).forEach((key) => {
				if (key !== "customerName") {
					const control = controls[key];
					if (!control.value || control.value === "") {
						control.setValue("@");
					}
				}
			});
		}
	}

	get expiryDateString(): string {
		const ed = this.paymentCard.expiryDate;
		return (ed?.month || "") + (ed?.year || "");
	}

	openBrands(): void {
		this.modalService.openModal(StoreCardBrandsComponent);
	}

	updatePaymentCard(key: keyof PaymentCard, value: any) {
		if (!this.paymentCard) {
			this.paymentCard = {};
		}

		if (key === "number") {
			this.brandType = this.cardBrandNumber?.brand;
		}

		if (key === "expiryDate") {
			value = {
				month: value.slice(0, 2),
				year: value.slice(2, 4),
			};
		}
		this.paymentCard[key] = value;
	}
}
