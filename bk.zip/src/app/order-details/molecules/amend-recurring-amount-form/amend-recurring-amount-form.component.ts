import {
	Component,
	Input,
	OnInit,
	OnChanges,
	SimpleChanges,
	ViewChild,
} from "@angular/core";
import { NgForm } from "@angular/forms";
import {
	CurrencyEnum,
	TransactionAmount,
	TransactionAmountComponents,
	OrderReportResponse,
	TransactionResult,
	TransactionType,
} from "bff-client";
import { CurrenciesService } from "services/currencies.service";
import { SelectOption } from "shared/models/select-options";
import { getTotalAmount } from "utils/common.utils";

@Component({
	selector: "app-amend-recurring-amount-form",
	templateUrl: "./amend-recurring-amount-form.component.html",
	styleUrls: ["./amend-recurring-amount-form.component.scss"],
})
export class AmendRecurringAmountFormComponent implements OnInit, OnChanges {
	@Input() order!: OrderReportResponse;
	@Input() amount!: TransactionAmount;
	@ViewChild("amountForm") form!: NgForm;
	public currencyOptions: Array<SelectOption<CurrencyEnum>> = [];
	disableCurrency = true;
	canUpdate = false;
	displayAmount!: TransactionAmount;

	constructor(private currencyService: CurrenciesService) {}

	ngOnInit(): void {
		this.currencyService.getCurrencies().subscribe({
			next: (currency: any) => {
				if (currency.length > 0) {
					this.currencyOptions = currency
						.sort((a: any, b: any) => {
							const fa = a.literalCurrencyCode.toLowerCase();
							const fb = b.literalCurrencyCode.toLowerCase();
							if (fa < fb) {
								return -1;
							}
							if (fa > fb) {
								return 1;
							}
							return 0;
						})
						.map((val: any) => {
							return {
								name: val.literalCurrencyCode,
								value: val.literalCurrencyCode,
							};
						});
				}
			},
			error: (error) => {
				this.currencyOptions = [];
				return error;
			},
		});
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes.amount && changes.amount.currentValue) {
			this.displayAmount = { ...changes.amount.currentValue };
		}

		if (changes.order && changes.order.currentValue) {
			this.disableCurrency = this.canDisableCurrency(
				changes.order.currentValue
			);
		}
	}

	canDisableCurrency(order: OrderReportResponse): boolean {
		if (!order || !order.recurringPaymentsInfo) {
			return true;
		}

		const transactions = order.transactions;
		if (
			transactions &&
			transactions.length > 0 &&
			transactions?.some(
				(t) =>
					t.transactionResult === TransactionResult.Approved &&
					t.transactionType === TransactionType.Sale
			)
		) {
			return true;
		}

		return false;
	}

	updateCurrency(currency: string): void {
		this.amount = {
			...this.amount,
			currency: currency as any,
		};
	}

	updateAmount(key: string, value: string | number): void {
		const numValue: number =
			typeof value === "number" ? value : parseFloat(value);
		const components = {
			...(this.amount && this.amount.components ? this.amount.components : {}),
			[key]: isNaN(numValue) ? 0 : numValue,
		};
		const total = components ? getTotalAmount(components) : 0;
		this.amount = {
			...this.amount,
			total,
			components,
		};
	}
}
