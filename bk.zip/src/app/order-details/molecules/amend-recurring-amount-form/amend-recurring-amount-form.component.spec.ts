import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { FormsModule, NgForm } from "@angular/forms";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";

import { AmendRecurringAmountFormComponent } from "./amend-recurring-amount-form.component";

describe("AmendRecurringAmountFormComponent", () => {
	let component: AmendRecurringAmountFormComponent;
	let fixture: ComponentFixture<AmendRecurringAmountFormComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [FormsModule, PipesMockModule],
			declarations: [AmendRecurringAmountFormComponent],
			providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
			schemas: [NO_ERRORS_SCHEMA],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(AmendRecurringAmountFormComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
