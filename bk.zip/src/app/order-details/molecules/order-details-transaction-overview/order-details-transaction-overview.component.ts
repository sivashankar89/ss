import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { TransactionInfo } from "bff-client";

@Component({
	selector: "app-order-details-transaction-overview",
	templateUrl: "./order-details-transaction-overview.component.html",
	styleUrls: ["./order-details-transaction-overview.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsTransactionOverviewComponent {
	@Input() transaction!: TransactionInfo;
	@Input() color: "green" | "red" | "gray" = "gray";
}
