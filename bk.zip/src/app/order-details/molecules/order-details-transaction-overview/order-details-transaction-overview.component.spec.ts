import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";

import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import { REPORTING_API_TRANSACTION_APPROVED_MOCK } from "mocks/reporting_api/orders.mock";
import { TransactionResultPipeModule } from "../../../pipes";

import { OrderDetailsTransactionOverviewComponent } from "./order-details-transaction-overview.component";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

describe("OrderDetailsTransactionOverviewComponent", () => {
	let component: OrderDetailsTransactionOverviewComponent;
	let fixture: ComponentFixture<OrderDetailsTransactionOverviewComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [PipesMockModule, TransactionResultPipeModule],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
			declarations: [OrderDetailsTransactionOverviewComponent],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsTransactionOverviewComponent);
		component = fixture.componentInstance;
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});

	it("should render template", () => {
		component.transaction = REPORTING_API_TRANSACTION_APPROVED_MOCK;

		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector(".header")).toMatchSnapshot();
	});
});
