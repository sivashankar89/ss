import { NO_ERRORS_SCHEMA, SimpleChange } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE } from "mocks/reporting_api/orders.mock";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { OrderDetailsGeneralAddressComponent } from "./order-details-general-address.component";
import { TelemetryService } from "services/telemetry.service";
import { TranslateService } from "@tolgee/ngx";

describe("OrderDetailsGeneralAddressComponent", () => {
	let component: OrderDetailsGeneralAddressComponent;
	let fixture: ComponentFixture<OrderDetailsGeneralAddressComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [OrderDetailsGeneralAddressComponent],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
		});

		fixture = TestBed.createComponent(OrderDetailsGeneralAddressComponent);
		component = fixture.componentInstance;
	});

	it("should create instance", () => {
		expect(component).toBeDefined();
		expect(fixture).toMatchSnapshot();
	});

	it("should render component with shipping data", () => {
		component.labelKey = "Test address";
		component.address = REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE.shipping;

		component.ngOnChanges({
			address: new SimpleChange(null, component.address, true),
		});
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"24 Sandy Lane"
		); // key
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"john.smith@shipping.com"
		); // email
	});

	it("should render component with billing data", () => {
		component.labelKey = "Test address";
		component.address = REPORTING_API_ORDER_DETAILS_MOCK_RESPONSE.billing;

		component.ngOnChanges({
			address: new SimpleChange(null, component.address, true),
		});
		fixture.detectChanges();
		expect(fixture).toMatchSnapshot();
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"24 Sandy Lane"
		); // key
		expect((fixture.nativeElement as HTMLDivElement).innerHTML).toContain(
			"john.smith@billing.com"
		); // email
	});
});
