import {
	ChangeDetectionStrategy,
	Component,
	Input,
	OnChanges,
	SimpleChanges,
} from "@angular/core";
import { BillingAddress, ShippingAddress } from "bff-client";
import { TranslateService } from "@tolgee/ngx";

@Component({
	selector: "app-order-details-general-address",
	templateUrl: "order-details-general-address.component.html",
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsGeneralAddressComponent implements OnChanges {
	@Input() labelKey!: string;
	@Input() address!: BillingAddress | ShippingAddress | undefined;
	countryIsoTranslated = "";
	addressLineText = "";

	constructor(private translateService: TranslateService) {}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes.address && changes.address.currentValue) {
			const { country, addressLine1, addressLine2 } =
				changes.address.currentValue;
			this.countryIsoTranslated = "";
			if (country) {
				this.countryIsoTranslated = this.translateService.instantSafe(
					"countryISO." + country
				);
			}

			this.addressLineText = "";
			if (addressLine1) {
				this.addressLineText += addressLine1.trim();
				if (!addressLine1.trim().endsWith(",") && addressLine2) {
					this.addressLineText += ",";
				}
			}
			if (addressLine2) {
				this.addressLineText += " " + addressLine2.trim();
			}
		}
	}
}
