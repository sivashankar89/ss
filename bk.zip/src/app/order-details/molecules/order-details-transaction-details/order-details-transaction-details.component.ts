import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { ReportingPaymentType, TransactionInfo } from "bff-client";

@Component({
	selector: "app-order-details-transaction-details",
	templateUrl: "./order-details-transaction-details.component.html",
	styleUrls: ["./order-details-transaction-details.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsTransactionDetailsComponent {
	@Input() transaction!: TransactionInfo;

	readonly PAYMENT_TYPE = ReportingPaymentType;

	get fieldsToDisplay():
		| ReportingPaymentType.Creditcard
		| ReportingPaymentType.Sepa
		| ReportingPaymentType.Paymentlink {
		switch (this.transaction.paymentType) {
			case ReportingPaymentType.Creditcard:
				return ReportingPaymentType.Creditcard;

			case ReportingPaymentType.Sepa:
			case ReportingPaymentType.Debitde:
				return ReportingPaymentType.Sepa;

			case ReportingPaymentType.Paymentlink:
			default:
				return ReportingPaymentType.Paymentlink;
		}
	}
}
