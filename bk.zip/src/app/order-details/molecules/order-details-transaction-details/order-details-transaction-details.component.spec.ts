import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ReportingPaymentType } from "bff-client";
import { PipesMockModule } from "mocks/pipes/pipes.module.mock";
import {
	REPORTING_API_TRANSACTION_APPROVED_MOCK,
	REPORTING_API_TRANSACTION_AUTHORIZED_MOCK,
	REPORTING_API_TRANSACTION_DECLINED_MOCK,
} from "mocks/reporting_api/orders.mock";
import { MandateTypePipeModule } from "../../../pipes/mandate-type/mandate-type.module";
import { OrderDetailsTransactionDetailsComponent } from "./order-details-transaction-details.component";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "mocks/services/services.mock";
import { TelemetryService } from "services/telemetry.service";

describe("OrderDetailsTransactionDetailsComponent", () => {
	let component: OrderDetailsTransactionDetailsComponent;
	let fixture: ComponentFixture<OrderDetailsTransactionDetailsComponent>;

	beforeEach(async () => {
		await TestBed.configureTestingModule({
			imports: [PipesMockModule, MandateTypePipeModule],
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
			schemas: [NO_ERRORS_SCHEMA],
			declarations: [OrderDetailsTransactionDetailsComponent],
		}).compileComponents();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(OrderDetailsTransactionDetailsComponent);
		component = fixture.componentInstance;
	});

	it("should create", () => {
		fixture.detectChanges();
		expect(component).toBeTruthy();
	});

	describe("fieldsToDisplay", () => {
		it("should display credit card fields", () => {
			component.transaction = REPORTING_API_TRANSACTION_APPROVED_MOCK;
			fixture.detectChanges();

			expect(component.fieldsToDisplay).toBe(ReportingPaymentType.Creditcard);
			expect(fixture).toMatchSnapshot();
		});

		it("should display sepa fields", () => {
			component.transaction = REPORTING_API_TRANSACTION_DECLINED_MOCK;
			fixture.detectChanges();

			expect(component.fieldsToDisplay).toBe(ReportingPaymentType.Sepa);
			expect(fixture).toMatchSnapshot();
		});

		it("should display payment link fields", () => {
			component.transaction = REPORTING_API_TRANSACTION_AUTHORIZED_MOCK;
			fixture.detectChanges();

			expect(component.fieldsToDisplay).toBe(ReportingPaymentType.Paymentlink);
			expect(fixture).toMatchSnapshot();
		});
	});
});
