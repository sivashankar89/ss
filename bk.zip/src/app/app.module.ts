import { APP_INITIALIZER, ErrorHandler, NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AppComponent } from "app.component";
import {
	LoginModule,
	PortalCoreLibModule,
} from "@international-payment-platform/portal-core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import {
	TRANSLOCO_CONFIG,
	TRANSLOCO_LOADER,
	translocoConfig,
	TranslocoModule,
} from "@ngneat/transloco";
import { environment } from "environments/environment";
import { TranslationHttpLoader } from "translation-loader";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SharedModule } from "shared/shared.module";
import { NgxTolgeeModule } from "@tolgee/ngx";
import { HttpHeadersInterceptor } from "http-header.interceptor";
import { AppRoutingModule } from "app-routing.module";
import { OpenOrderDetailsService } from "order-details/services/open-order-details.service";
import { OrderDetailsService } from "services/order-details.service";
import UI from "@tolgee/ui";
import {
	CdsSelectModule,
	CdsCheckboxModule,
	CdsSlidingPanelModule,
	CdsTooltipModule,
	CdsDropdownModule,
	CdsListModule,
	CdsCardInputsI18nService,
	CdsCounterI18nService,
	CdsIbanInputI18nService,
} from "@international-payment-platform/design-system-angular";
import { BASE_PATH } from "bff-client";
import { LoggerModule, NGXLogger } from "ngx-logger";
import { LocalStorageRefService } from "utils/local-storage-ref.service";
import { DevPanelSettingsModule } from "dev-panel-settings/dev-panel-settings.module";
import { DevPanelSettingsComponent } from "dev-panel-settings/dev-panel-settings.component";
import { SessionStorageRefService } from "utils/session-storage-ref.service";
import { TranslationService } from "utils/translation.service";
import { PopupModule } from "popup/popup.module";
import { CardInputI18nService } from "services/card-input-i18n-service";
import { IbanInputI18nService } from "services/iban-input-i18n-service";
import { CounterI18nService } from "services/counter-i18n-service";
import { registerLocaleData } from "@angular/common";

import {
	OTEL_LOGGER,
	W3CTraceContextPropagatorModule,
	OtelColExporterModule,
	OTEL_CONFIG,
} from "@jufab/opentelemetry-angular-interceptor";
import { Builds } from "environments/enums";
import { GlobalErrorHandler } from "error.handler";
import { SsoService } from "services/sso.service";
const key = navigator.languages
	? navigator.languages[0].replace(/^(.+?)(-.*)?$/, "$1")
	: "en";
import(
	/* webpackInclude: /(en|de|pl|it)\.js$/ */
	/* webpackMode: "lazy-once" */
	/* webpackChunkName: "i18n-base" */
	`@angular/common/locales/${key}.js`
).then(async (module) => {
	registerLocaleData(module.default);
});

@NgModule({
	declarations: [AppComponent, DevPanelSettingsComponent],
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		HttpClientModule,
		LoginModule,
		PortalCoreLibModule,
		TranslocoModule,
		FormsModule,
		ReactiveFormsModule,
		SharedModule,
		AppRoutingModule,
		PopupModule,
		DevPanelSettingsModule,
		CdsSlidingPanelModule,
		CdsCheckboxModule,
		CdsSelectModule,
		CdsListModule,
		CdsDropdownModule,
		CdsTooltipModule,
		OtelColExporterModule,
		W3CTraceContextPropagatorModule,
		NgxTolgeeModule.forRoot({
			preloadFallback: true,
			filesUrlPrefix: environment.tolgeeFilesUrlPrefix(),
			apiUrl: environment.tolgeeApiUrl,
			apiKey: environment.tolgeeApiKey,
			ui: environment.tolgeeApiKey ? UI : undefined,
			// forceLanguage: 'en-GB'
		}),
		LoggerModule.forRoot(environment.loggerConfig),
	],
	providers: [
		OpenOrderDetailsService,
		OrderDetailsService,
		LocalStorageRefService,
		SessionStorageRefService,
		SsoService,
		{
			provide: APP_INITIALIZER,
			useFactory: (ssoService: SsoService) => () => ssoService.init(),
			deps: [SsoService],
			multi: true,
		},
		TranslationService,
		{
			provide: CdsCardInputsI18nService,
			useClass: CardInputI18nService,
		},
		{
			provide: CdsIbanInputI18nService,
			useClass: IbanInputI18nService,
		},
		{
			provide: CdsCounterI18nService,
			useClass: CounterI18nService,
		},
		{
			provide: TRANSLOCO_CONFIG,
			useValue: translocoConfig({
				defaultLang: "en",
				fallbackLang: "en",
				availableLangs: ["en", "de"],
				// Remove this option if your application doesn't support changing language in runtime.
				reRenderOnLangChange: true,
				prodMode: environment.build == Builds.PROD,
			}),
		},
		{ provide: TRANSLOCO_LOADER, useClass: TranslationHttpLoader },
		{
			provide: HTTP_INTERCEPTORS,
			multi: true,
			useClass: HttpHeadersInterceptor,
		},
		{ provide: BASE_PATH, useValue: environment.bffApiURl },
		{ provide: OTEL_CONFIG, useValue: environment.opentelemetryConfig },
		{ provide: OTEL_LOGGER, useExisting: NGXLogger },
		{
			// processes all errors
			provide: ErrorHandler,
			useClass: GlobalErrorHandler,
		},
	],
	bootstrap: [AppComponent],
})
export class AppModule {}
