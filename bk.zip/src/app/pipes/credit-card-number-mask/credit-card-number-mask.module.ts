import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { CreditCardNumberMaskPipe } from "./credit-card-number-mask.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [CreditCardNumberMaskPipe],
	exports: [CreditCardNumberMaskPipe],
})
export class CreditCardNumberMaskPipeModule {}
