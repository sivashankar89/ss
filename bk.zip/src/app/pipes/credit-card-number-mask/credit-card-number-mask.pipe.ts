import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
	name: "creditCardNumberMask",
})
export class CreditCardNumberMaskPipe implements PipeTransform {
	transform(
		value?: string,
		maskType: "dots" | "stars" = "stars",
		cardNumberLength: number = 16
	): string {
		if (typeof value !== "string") {
			return "";
		}
		return maskType === "dots"
			? this.getDotsMask(value)
			: this.getStarsMask(value, cardNumberLength);
	}

	private getDotsMask(value: string): string {
		const cleaned = value.replace(/\D/g, "");
		const match = value.match(/^(\d{4})(\d{2})(\d{4})$/);
		if (match) {
			return `${match[1]} ${match[2]}... ${match[3]}`;
		}
		return "";
	}

	private getStarsMask(value: string, cardNumberLength: number): string {
		const [bin, last] = value.split("...");
		if (bin && last) {
			const numberOfStars = cardNumberLength - bin.length - last.length;
			const combinedValue = bin + this.getNMaskElements(numberOfStars) + last;
			const results = [];
			for (let i = 0; i < combinedValue.length; i += 4) {
				results.push(combinedValue.substr(i, 4));
			}
			return results.join(" ");
		} else {
			return value;
		}
	}

	private getNMaskElements(elements: number = 0): string {
		if (
			typeof elements !== "number" ||
			elements >= Number.MAX_SAFE_INTEGER ||
			elements < 0
		) {
			return "";
		}
		return "*".repeat(elements);
	}
}
