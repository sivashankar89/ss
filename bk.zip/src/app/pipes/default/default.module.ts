import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DefaultValuePipe } from "pipes/default/default.pipe";

@NgModule({
	declarations: [DefaultValuePipe],
	imports: [CommonModule],
	exports: [DefaultValuePipe],
})
export class DefaultValuePipeModule {}
