import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
	name: "default",
})
export class DefaultValuePipe implements PipeTransform {
	constructor() {}

	transform<T>(value: T | null | undefined, defaultValue: T): T {
		return value ?? defaultValue;
	}
}
