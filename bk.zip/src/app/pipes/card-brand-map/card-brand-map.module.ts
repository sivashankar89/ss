import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CardBrandMapPipe } from "./card-brand-map.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [CardBrandMapPipe],
	exports: [CardBrandMapPipe],
})
export class CardBrandMapPipeModule {}
