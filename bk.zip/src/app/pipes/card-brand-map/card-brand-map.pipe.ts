import { Pipe, PipeTransform } from "@angular/core";
import { CdsPaymentBrand } from "@international-payment-platform/design-system-angular";
@Pipe({
	name: "cardBrandMap",
})
export class CardBrandMapPipe implements PipeTransform {
	transform(value?: string): CdsPaymentBrand | undefined {
		switch (value) {
			case "AMEX":
				return CdsPaymentBrand.AmericanExpress;
			case "DINERSCLUB":
				return CdsPaymentBrand.DinersClub;
			case "DINERSCLUB14":
				return CdsPaymentBrand.DinersClub;
			case "DISCOVER":
				return CdsPaymentBrand.Discover;
			case "JCB":
				return CdsPaymentBrand.JCB;
			case "MAESTRO":
				return CdsPaymentBrand.Maestro;
			case "MASTERCARD":
				return CdsPaymentBrand.Mastercard;
			case "RuPay":
				return CdsPaymentBrand.RuPay;
			case "UNIONPAY":
				return CdsPaymentBrand.UnionPay;
			case "VISA":
				return CdsPaymentBrand.Visa;
			case "IKEA":
				return CdsPaymentBrand.UnionPay;
			default:
				return undefined;
		}
	}
}
