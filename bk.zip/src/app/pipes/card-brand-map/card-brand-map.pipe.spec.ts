import { CdsPaymentBrand } from "@international-payment-platform/design-system-angular";
import { CardBrandMapPipe } from "./card-brand-map.pipe";

describe("CardBrandMapPipe", () => {
	const pipe = new CardBrandMapPipe();
	it("create an instance", () => {
		expect(pipe).toBeTruthy();
	});

	describe("Check Return Types", () => {
		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("AMEX")).toBe(CdsPaymentBrand.AmericanExpress);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("DINERSCLUB")).toBe(CdsPaymentBrand.DinersClub);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("DINERSCLUB14")).toBe(CdsPaymentBrand.DinersClub);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("DISCOVER")).toBe(CdsPaymentBrand.Discover);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("JCB")).toBe(CdsPaymentBrand.JCB);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("MAESTRO")).toBe(CdsPaymentBrand.Maestro);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("MASTERCARD")).toBe(CdsPaymentBrand.Mastercard);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("RuPay")).toBe(CdsPaymentBrand.RuPay);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("UNIONPAY")).toBe(CdsPaymentBrand.UnionPay);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("VISA")).toBe(CdsPaymentBrand.Visa);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform("")).toBeUndefined();
		});
	});
});
