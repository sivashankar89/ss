import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { InternationalBankAccountNumberMaskPipe } from "./international-bank-account-number-mask.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [InternationalBankAccountNumberMaskPipe],
	exports: [InternationalBankAccountNumberMaskPipe],
})
export class InternationalBankAccountNumberMaskPipeModule {}
