import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
	name: "IBANMask",
})
export class InternationalBankAccountNumberMaskPipe implements PipeTransform {
	transform(value?: string): string {
		if (typeof value !== "string") {
			return "";
		}

		const cleaned = value.replace(/\W/g, "");
		const match = cleaned.match(/^(.*?).{3}(.{4})$/); // TODO:: need to check for multiple values, will change based on outcome

		if (match) {
			return `${match[1]}...${match[2]}`;
		}
		return "";
	}
}
