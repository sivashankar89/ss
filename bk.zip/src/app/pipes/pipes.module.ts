import { NgModule } from "@angular/core";
import {
	CardBrandMapPipeModule,
	CardBrandPipeModule,
	CreditCardNumberMaskPipeModule,
	CurrencyFormatPipeModule,
	DecimalPlacesPipeModule,
	DefaultValuePipeModule,
	ExpiryDatePipeModule,
	InternationalBankAccountNumberMaskPipeModule,
	MandateTypePipeModule,
	PaymentTypePipeModule,
	ReportingOnlineOfflinePipeModule,
	ReportingPaymentTypePipeModule,
	TimeStampFormatPipeModule,
	TransactionResultPipeModule,
	TransactionStatePipeModule,
	TransactionStatusPipeModule,
	TransactionTypePipeModule,
	UserPermissionsPipeModule,
} from "pipes";

const PIPE_MODULES = [
	CardBrandPipeModule,
	CardBrandMapPipeModule,
	CreditCardNumberMaskPipeModule,
	CurrencyFormatPipeModule,
	DecimalPlacesPipeModule,
	ExpiryDatePipeModule,
	InternationalBankAccountNumberMaskPipeModule,
	TimeStampFormatPipeModule,
	PaymentTypePipeModule,
	ReportingOnlineOfflinePipeModule,
	ReportingPaymentTypePipeModule,
	TransactionStatePipeModule,
	TransactionTypePipeModule,
	TransactionStatusPipeModule,
	UserPermissionsPipeModule,
	TransactionResultPipeModule,
	MandateTypePipeModule,
	DefaultValuePipeModule,
];

@NgModule({
	imports: PIPE_MODULES,
	exports: PIPE_MODULES,
})
export class PipesModule {}
