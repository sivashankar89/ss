import { Pipe, PipeTransform } from "@angular/core";
import { TransactionOnlineOffline } from "bff-client";

@Pipe({
	name: "onlineOffline",
})
export class ReportingOnlineOfflinePipe implements PipeTransform {
	transform(value: TransactionOnlineOffline): string {
		return value === TransactionOnlineOffline.Online ? "Yes" : "No";
	}
}
