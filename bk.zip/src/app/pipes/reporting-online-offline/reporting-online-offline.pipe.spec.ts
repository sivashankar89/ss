import { ReportingOnlineOfflinePipe } from "./reporting-online-offline.pipe";

describe("ReportingOnlineOfflinePipe", () => {
	it("create an instance", () => {
		const pipe = new ReportingOnlineOfflinePipe();
		expect(pipe).toBeTruthy();
	});
});
