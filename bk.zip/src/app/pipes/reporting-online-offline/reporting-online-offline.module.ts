import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReportingOnlineOfflinePipe } from "./reporting-online-offline.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [ReportingOnlineOfflinePipe],
	exports: [ReportingOnlineOfflinePipe],
})
export class ReportingOnlineOfflinePipeModule {}
