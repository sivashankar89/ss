import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { PaymentTypePipe } from "./payment-type.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [PaymentTypePipe],
	exports: [PaymentTypePipe],
})
export class PaymentTypePipeModule {}
