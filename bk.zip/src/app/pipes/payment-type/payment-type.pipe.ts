import { Pipe, PipeTransform } from "@angular/core";
import { PaymentMethodType } from "bff-client";

const PAYMENT_TYPE_MAP: Map<PaymentMethodType, string> = new Map<
	PaymentMethodType,
	string
>([
	[PaymentMethodType.Debitde, "Direct debit"],
	[PaymentMethodType.PaymentCard, "Payment card"],
	[PaymentMethodType.Paypal, "Paypal"],
]);

@Pipe({
	name: "paymentType",
})
export class PaymentTypePipe implements PipeTransform {
	transform(value?: PaymentMethodType): string {
		if (typeof value !== "string") {
			return "";
		}

		return PAYMENT_TYPE_MAP.get(value) || `${value}`;
	}
}
