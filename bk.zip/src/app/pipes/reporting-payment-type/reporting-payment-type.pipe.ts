import { Pipe, PipeTransform } from "@angular/core";
import { ReportingPaymentType } from "bff-client";

const REPORTING_PAYMENT_TYPE_MAP: Map<ReportingPaymentType, string> = new Map<
	ReportingPaymentType,
	string
>([
	[ReportingPaymentType.Sepa, "SEPA"],
	[ReportingPaymentType.Debitde, "Direct debit"],
	[ReportingPaymentType.Creditcard, "Credit card"],
	[ReportingPaymentType.Paymentlink, "Payment link"],
]);

@Pipe({
	name: "reportingPaymentType",
})
export class ReportingPaymentTypePipe implements PipeTransform {
	transform(value?: ReportingPaymentType): string {
		if (typeof value !== "string") {
			return "";
		}

		return REPORTING_PAYMENT_TYPE_MAP.get(value) || `${value}`;
	}
}
