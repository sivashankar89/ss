import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReportingPaymentTypePipe } from "./reporting-payment-type.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [ReportingPaymentTypePipe],
	exports: [ReportingPaymentTypePipe],
})
export class ReportingPaymentTypePipeModule {}
