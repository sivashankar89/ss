import { ReportingPaymentType } from "bff-client";
import { ReportingPaymentTypePipe } from "./reporting-payment-type.pipe";

describe("ReportingPaymentTypePipe", () => {
	it("create an instance", () => {
		const pipe = new ReportingPaymentTypePipe();
		expect(pipe).toBeTruthy();
	});

	it("should transform SEPA payment type", () => {
		const pipe = new ReportingPaymentTypePipe();
		expect(pipe.transform(ReportingPaymentType.Sepa)).toBe("SEPA");
	});

	it("should transform DEBITDE payment type", () => {
		const pipe = new ReportingPaymentTypePipe();
		expect(pipe.transform(ReportingPaymentType.Debitde)).toBe("Direct debit");
	});

	it("should transform CREDITCARD payment type", () => {
		const pipe = new ReportingPaymentTypePipe();
		expect(pipe.transform(ReportingPaymentType.Creditcard)).toBe("Credit card");
	});

	it("should transform PAYMENTLINK payment type", () => {
		const pipe = new ReportingPaymentTypePipe();
		expect(pipe.transform(ReportingPaymentType.Paymentlink)).toBe(
			"Payment link"
		);
	});

	it("should transform random payment type", () => {
		const pipe = new ReportingPaymentTypePipe();
		expect(pipe.transform("test" as ReportingPaymentType)).toBe("test");
	});

	it("should transform non-string input", () => {
		const pipe = new ReportingPaymentTypePipe();
		expect(pipe.transform(undefined)).toBe("");
	});
});
