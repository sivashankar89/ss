import { Pipe, PipeTransform } from "@angular/core";
import { TransactionState } from "bff-client";

const TRANSACTION_STATE_MAP: Map<TransactionState, string> = new Map<
	TransactionState,
	string
>([
	[TransactionState.Authorized, "Authorized"],
	[TransactionState.Captured, "Captured"],
	[TransactionState.Declined, "Declined"],
	[TransactionState.Checked, "Checked"],
	[TransactionState.CompletedGet, "Completed get"],
	[TransactionState.Initialized, "Initialized"],
	[TransactionState.Pending, "Pending"],
	[TransactionState.Ready, "Ready"],
	[TransactionState.Template, "Template"],
	[TransactionState.Settled, "Settled"],
	[TransactionState.Voided, "Voided"],
	[TransactionState.Waiting, "Waiting"],
	[TransactionState.PendingCapture, "Pending capture"],
]);

@Pipe({
	name: "transactionState",
})
export class TransactionStatePipe implements PipeTransform {
	transform(value?: TransactionState): string {
		if (typeof value !== "string") {
			return "";
		}

		return TRANSACTION_STATE_MAP.get(value) || `${value}`;
	}
}
