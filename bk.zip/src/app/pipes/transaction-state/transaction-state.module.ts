import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TransactionStatePipe } from "./transaction-state.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [TransactionStatePipe],
	exports: [TransactionStatePipe],
})
export class TransactionStatePipeModule {}
