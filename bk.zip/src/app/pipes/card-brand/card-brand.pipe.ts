import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
	name: "cardBrand",
})
export class CardBrandPipe implements PipeTransform {
	transform(value?: string): string {
		if (typeof value !== "string") {
			return "";
		}

		if (value === "MASTERCARD") {
			return "Mastercard";
		}

		return value;
	}
}
