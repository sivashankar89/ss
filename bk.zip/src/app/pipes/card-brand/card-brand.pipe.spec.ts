import { CardBrandPipe } from "./card-brand.pipe";

describe("CardBrandPipe", () => {
	it("create an instance", () => {
		const pipe = new CardBrandPipe();
		expect(pipe).toBeTruthy();
	});
});
