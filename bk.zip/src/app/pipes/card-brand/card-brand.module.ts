import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CardBrandPipe } from "./card-brand.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [CardBrandPipe],
	exports: [CardBrandPipe],
})
export class CardBrandPipeModule {}
