import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { MandateTypePipe } from "./mandate-type.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [MandateTypePipe],
	exports: [MandateTypePipe],
})
export class MandateTypePipeModule {}
