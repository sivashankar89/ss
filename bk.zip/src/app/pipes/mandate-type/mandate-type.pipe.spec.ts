import { TestBed } from "@angular/core/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "../../../mocks/services/services.mock";
import { MandateTypePipe } from "./mandate-type.pipe";
import { TelemetryService } from "services/telemetry.service";

describe("MandateTypePipe", () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});
	});
	it("create an instance", () => {
		const translateService: TranslateService = TestBed.get(TranslateService);
		const pipe = new MandateTypePipe(translateService);
		expect(pipe).toBeTruthy();
	});
});
