import { Pipe, PipeTransform } from "@angular/core";
import { TranslateService } from "@tolgee/ngx";
import { MandateType } from "../../../bff-client/model/mandateType";

const MANDATE_TYPE_MAP: Map<MandateType, string> = new Map<MandateType, string>(
	[
		[MandateType.Single, "shared.single"],
		[MandateType.FirstCollection, "shared.first"],
		[MandateType.RecurringCollection, "shared.recurring"],
		[MandateType.FinalCollection, "shared.final"],
	]
);

@Pipe({
	name: "mandateType",
})
export class MandateTypePipe implements PipeTransform {
	constructor(private translateService: TranslateService) {}

	transform(value?: MandateType): string {
		if (typeof value !== "string") {
			return "";
		}

		return this.translateService.instantSafe(
			MANDATE_TYPE_MAP.get(value) || `${value}`
		);
	}
}
