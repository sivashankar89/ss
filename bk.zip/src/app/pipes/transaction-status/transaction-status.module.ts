import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { TransactionStatusPipe } from "./transaction-status.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [TransactionStatusPipe],
	exports: [TransactionStatusPipe],
})
export class TransactionStatusPipeModule {}
