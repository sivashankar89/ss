import { Pipe, PipeTransform } from "@angular/core";
import { TransactionStatus } from "bff-client";

const TRANSACTION_STATUS_MAP: Map<TransactionStatus, string> = new Map<
	TransactionStatus,
	string
>([
	[TransactionStatus.Approved, "Approved"],
	[TransactionStatus.Declined, "Declined"],
	[TransactionStatus.ProcessingFailed, "Processing failed"],
	[TransactionStatus.ValidationFailed, "Validation failed"],
	[TransactionStatus.Waiting, "Waiting"],
]);

@Pipe({
	name: "transactionStatus",
})
export class TransactionStatusPipe implements PipeTransform {
	transform(value?: TransactionStatus): string {
		if (typeof value !== "string") {
			return "";
		}

		return TRANSACTION_STATUS_MAP.get(value) || `${value}`;
	}
}
