import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TimeStampFormatPipe } from "./time-stamp-format.pipe";

@NgModule({
	declarations: [TimeStampFormatPipe],
	imports: [CommonModule],
	exports: [TimeStampFormatPipe],
})
export class TimeStampFormatPipeModule {}
