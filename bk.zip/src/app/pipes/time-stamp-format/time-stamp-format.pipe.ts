import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: "timeStampFormat" })
export class TimeStampFormatPipe implements PipeTransform {
	transform(value: number): number {
		if (!value) {
			return 0;
		}
		return value.toString().length < 13 ? value * 1000 : value;
	}
}
