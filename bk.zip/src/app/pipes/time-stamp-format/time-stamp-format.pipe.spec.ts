import { TimeStampFormatPipe } from "./time-stamp-format.pipe";

describe("TimeStampFormatPipe", () => {
	const pipe = new TimeStampFormatPipe();
	it("create an instance", () => {
		expect(pipe).toBeTruthy();
	});

	describe("Check Return value", () => {
		it('should transforms zero input"', () => {
			expect(pipe.transform(0)).toBe(0);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform(5263417896)).toBe(5263417896000);
		});

		it('should transforms "input" to "output"', () => {
			expect(pipe.transform(5263417896321)).toBe(5263417896321);
		});
	});
});
