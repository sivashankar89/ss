import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TransactionResultPipe } from "./transaction-result-code.pipe";

@NgModule({
	imports: [CommonModule],
	declarations: [TransactionResultPipe],
	exports: [TransactionResultPipe],
})
export class TransactionResultPipeModule {}
