import { Pipe, PipeTransform } from "@angular/core";
import { TranslateService } from "@tolgee/ngx";
import { TransactionResult } from "bff-client";

const TRANSACTION_RESULT_CODE_MAP: Map<TransactionResult, string> = new Map<
	TransactionResult,
	string
>([
	[TransactionResult.Approved, "shared.approved"],
	[TransactionResult.Created, "shared.created"],
	[TransactionResult.Declined, "shared.declined"],
	[TransactionResult.Failed, "shared.failed"],
	[TransactionResult.Waiting, "shared.waiting"],
	[TransactionResult.Partial, "shared.partial"],
	[TransactionResult.Fraud, "shared.fraud"],
]);

@Pipe({
	name: "transactionResult",
})
export class TransactionResultPipe implements PipeTransform {
	constructor(private translateService: TranslateService) {}

	transform(value?: TransactionResult): string {
		if (typeof value !== "string") {
			return "";
		}

		return this.translateService.instantSafe(
			TRANSACTION_RESULT_CODE_MAP.get(value) || `${value}`
		);
	}
}
