import { TestBed } from "@angular/core/testing";
import { TranslateService } from "@tolgee/ngx";
import {
	TelemetryServiceStub,
	TranslateServiceStub,
} from "../../../mocks/services/services.mock";
import { TransactionResultPipe } from "./transaction-result-code.pipe";
import { TelemetryService } from "services/telemetry.service";

describe("TransactionResultPipe", () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				{ provide: TranslateService, useValue: TranslateServiceStub },
				{ provide: TelemetryService, useValue: TelemetryServiceStub },
			],
		});
	});
	it("create an instance", () => {
		const translateService: TranslateService = TestBed.get(TranslateService);
		const pipe = new TransactionResultPipe(translateService);
		expect(pipe).toBeTruthy();
	});
});
