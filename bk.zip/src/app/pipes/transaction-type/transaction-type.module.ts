import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TransactionTypePipe } from "./transaction-type.pipe";

@NgModule({
	declarations: [TransactionTypePipe],
	imports: [CommonModule],
	exports: [TransactionTypePipe],
})
export class TransactionTypePipeModule {}
