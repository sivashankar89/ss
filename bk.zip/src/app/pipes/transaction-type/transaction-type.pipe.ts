import { Pipe, PipeTransform } from "@angular/core";
import { TransactionType } from "bff-client";

const TRANSACTION_TYPE_MAP: Map<TransactionType, string> = new Map<
	TransactionType,
	string
>([
	[TransactionType.Sale, "Sale"],
	[TransactionType.Preauth, "Pre-authorisation"],
	[TransactionType.Credit, "Credit"],
	[TransactionType.ForcedTicket, "Forced ticket"],
	[TransactionType.Void, "Void"],
	[TransactionType.VoidReturn, "Void Refund"],
	[TransactionType.Return, "Refund"],
	[TransactionType.Postauth, "Completion"],
	[TransactionType.PayerAuth, "Payer auth"],
	[TransactionType.Disbursement, "Disbursement"],
	[TransactionType.VoidPreauth, "Void Pre-authorisation"],
	[TransactionType.VoidPostauth, "Void Completion"],
]);

@Pipe({
	name: "transactionType",
})
export class TransactionTypePipe implements PipeTransform {
	transform(value?: TransactionType): string {
		if (typeof value !== "string") {
			return "";
		}

		return TRANSACTION_TYPE_MAP.get(value) || `${value}`;
	}
}
