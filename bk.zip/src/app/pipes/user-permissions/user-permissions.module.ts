import { NgModule } from "@angular/core";
import { UserPermissionsPipe } from "./user-permissions.pipe";

@NgModule({
	declarations: [UserPermissionsPipe],
	exports: [UserPermissionsPipe],
})
export class UserPermissionsPipeModule {}
