import { Pipe, PipeTransform } from "@angular/core";
import { AuthenticationService } from "@international-payment-platform/portal-core";

@Pipe({
	name: "userPermission",
})
export class UserPermissionsPipe implements PipeTransform {
	constructor(private authenticationService: AuthenticationService) {}

	transform(permissions: string | Array<string>, some?: boolean): boolean {
		const userPermissions: string[] =
			this.authenticationService.getPermissions();
		if (typeof permissions === "string") {
			permissions = [permissions];
		}
		if (permissions instanceof Array) {
			if (!some) {
				return permissions.every((permission) =>
					userPermissions.includes(permission)
				);
			}
			return permissions.some((permission) =>
				userPermissions.includes(permission)
			);
		}
		return false;
	}
}
