import { TestBed } from "@angular/core/testing";
import { AuthenticationService } from "@international-payment-platform/portal-core";
import { AuthenticationServiceStub } from "mocks/services/services.mock";
import { UserPermissionsPipe } from "./user-permissions.pipe";

describe("UserPermissionsPipe", () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				{ provide: AuthenticationService, AuthenticationServiceStub },
			],
		});
	});

	it("create an instance", () => {
		const authenticationService: AuthenticationService = TestBed.get(
			AuthenticationService
		);
		const pipe = new UserPermissionsPipe(authenticationService);
		expect(pipe).toBeTruthy();
	});
});
