import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ExpiryDatePipe } from "./expiry-date.pipe";

@NgModule({
	declarations: [ExpiryDatePipe],
	imports: [CommonModule],
	exports: [ExpiryDatePipe],
})
export class ExpiryDatePipeModule {}
