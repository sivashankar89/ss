import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
	name: "expiryDate",
})
export class ExpiryDatePipe implements PipeTransform {
	transform(month: any, year: any): string {
		if (month && year) {
			year = year.toString();
			const shortYear = year.length > 2 ? year.substring(2, 4) : year;
			const expiryDate = `${month}/${shortYear}`;
			return expiryDate;
		}
		return "";
	}
}
