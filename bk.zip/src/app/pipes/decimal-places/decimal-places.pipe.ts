import { formatNumber } from "@angular/common";
import { Inject, LOCALE_ID, Pipe, PipeTransform } from "@angular/core";
import { map, Observable } from "rxjs";
import { Currency } from "bff-client";
import { CurrenciesService } from "../../services/currencies.service";

@Pipe({ name: "decimalPlaces" })
export class DecimalPlacesPipe implements PipeTransform {
	constructor(
		private cs: CurrenciesService,
		@Inject(LOCALE_ID) private locale: string
	) {}

	transform(
		amount: string | number | undefined | null,
		currencyCode: string | undefined
	): Observable<string> {
		return this.cs.getCurrency(currencyCode).pipe(
			map((currency: Currency) => {
				if (!amount) {
					return "";
				}
				if (typeof amount === "string") {
					amount = parseFloat(amount);
				}
				const decimalDigits = `1.${currency.decimalPlaces}`;
				return formatNumber(amount, this.locale, decimalDigits)
					.replace(/,/g, "")
					.replace(/ /g, "");
			})
		);
	}
}
