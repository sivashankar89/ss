import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DecimalPlacesPipe } from "./decimal-places.pipe";

@NgModule({
	declarations: [DecimalPlacesPipe],
	imports: [CommonModule],
	exports: [DecimalPlacesPipe],
})
export class DecimalPlacesPipeModule {}
