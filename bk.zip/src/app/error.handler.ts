import { ErrorHandler, Injectable, NgZone } from "@angular/core";
import { TelemetryService } from "services/telemetry.service";
import { HttpErrorResponse } from "@angular/common/http";

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
	constructor(
		private telemetryService: TelemetryService,
		private zone: NgZone
	) {}

	handleError(error: any) {
		// Check if it's an error from an HTTP response
		if (!(error instanceof HttpErrorResponse)) {
			error = error.rejection; // get the error object
		}
		if (this.zone) {
			this.zone.run(() =>
				this.telemetryService.withSpanName("GlobalErrorHandler", (span) => {
					span.recordException(error);
					span.end();
				})
			);
		} else {
			this.telemetryService.withSpanName("GlobalErrorHandler", (span) => {
				span.recordException(error);
				span.end();
			});
		}
	}
}
