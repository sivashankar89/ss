export class PopupConfig<D = any> {
	/**
	 * Used to be passed to {@link Window.open} method
	 * ### Default:
	 * `'popup=true,screenX=100,screenY=100,width=540,height=540'`
	 */
	windowFeatures?: string;

	/**
	 * Unique id for popup.
	 * Can be used to get reference to already opened popup.
	 *
	 * It's not allowed to open multiple popups with the same id.
	 */
	id?: string;

	/**
	 * Used to pass data to the component opened in a popup.
	 *
	 * ### Example:
	 * ```
	 * // open
	 * popupService.open<ComponentName, DataType>(ComponentName, { data: 'example' })
	 *
	 * // use in component
	 * export class ComponentName {
	 *    constructor(private @Inject(POPUP_DATA) data: DataType) {
	 *      ...
	 *    }
	 * }
	 * ```
	 */
	data?: D;

	/** Used to modify popup's document title */
	title?: string;

	constructor() {
		this.windowFeatures =
			"popup=true,screenX=100,screenY=100,width=540,height=540";
	}
}
