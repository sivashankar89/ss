import { Observable, Subject } from "rxjs";

let uniqueId = 0;

export class PopupRef<T> {
	componentInstance!: T;

	private readonly onCloseSubject = new Subject<void>();

	constructor(
		private readonly windowInstance: Window,
		readonly id: string = `popup-${uniqueId++}`
	) {
		this.windowInstance.onbeforeunload = () => {
			this.onClose();
		};
	}

	get isClosed(): boolean {
		return this.windowInstance.closed;
	}

	get closed$(): Observable<void> {
		return this.onCloseSubject.asObservable();
	}

	focus(): void {
		this.windowInstance.focus();
	}

	close(): void {
		this.windowInstance.close();
	}

	private onClose(): void {
		this.onCloseSubject.next();
		this.onCloseSubject.complete();
	}
}
