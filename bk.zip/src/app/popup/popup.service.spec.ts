import { DOCUMENT, APP_BASE_HREF, PlatformLocation } from "@angular/common";
import { Component, Inject } from "@angular/core";
import { TestBed } from "@angular/core/testing";
import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";
import { POPUP_DATA, POPUP_ROOT_HREF } from "./popup-token";

import { PopupService } from "./popup.service";

const NEW_WINDOW_INSTANCE_MOCK = {
	close: jest.fn(),
	document: global.document,
};

describe("PopupService", () => {
	let service: PopupService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [TestComponent, TestInjectorsComponent],
			providers: [
				PopupService,
				{
					provide: PlatformLocation,
					useValue: {
						getBaseHrefFromDOM: jest.fn().mockReturnValue("/test-base-href/"),
					},
				},
			],
		}).overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [TestComponent, TestInjectorsComponent],
			},
		});

		service = TestBed.inject(PopupService);
	});

	it("should be created", () => {
		expect(service).toBeTruthy();
	});

	it("should throw an error if window was not created", () => {
		global.open = jest.fn();

		try {
			service.open(TestComponent);
		} catch (error) {
			expect(error).toEqual(new Error("Window instance creation failed."));
		}
	});

	it("should open new popup", () => {
		global.open = jest.fn().mockReturnValue(NEW_WINDOW_INSTANCE_MOCK);

		const popupRef = service.open(TestComponent, { data: "test" });
		expect(popupRef).toBeDefined();
		expect(service.getById(popupRef.id)).toEqual(popupRef);
	});

	it("should prevent opening popup with the same id twice", () => {
		global.open = jest.fn().mockReturnValue(NEW_WINDOW_INSTANCE_MOCK);

		service.open(TestComponent, { id: "test " });

		try {
			service.open(TestComponent, { id: "test " });
		} catch (error) {
			expect(error).toEqual(new Error('Popup with id "test " already exists.'));
		}
	});

	it("should handle close event from popup", () => {
		global.open = jest.fn().mockReturnValue(NEW_WINDOW_INSTANCE_MOCK);

		const popupRef = service.open(TestComponent);
		expect(service.getById(popupRef.id)).toBeDefined();
		(popupRef as any).windowInstance.onbeforeunload();

		expect(service.getById(popupRef.id)).toBeUndefined();
	});

	it("should close all", () => {
		const windowClose = jest.fn();
		global.open = jest.fn().mockReturnValue({
			...NEW_WINDOW_INSTANCE_MOCK,
			close: windowClose,
		});

		service.open(TestComponent, { title: "popup 1" });
		service.open(TestComponent, { title: "popup 2" });

		service.closeAll();
		expect(windowClose).toHaveBeenCalledTimes(2);
	});

	it("handle on destroy", () => {
		service.closeAll = jest.fn();
		service.ngOnDestroy();

		expect(service.closeAll).toHaveBeenCalled();
	});

	describe("injectors", () => {
		it("should inject proper values", () => {
			const popupRef = service.open(TestInjectorsComponent, { data: "test" });
			const appDocument = TestBed.inject(DOCUMENT);

			expect(popupRef.componentInstance.data).toBe("test");
			expect(popupRef.componentInstance.documentRef).toEqual(appDocument);
			expect(popupRef.componentInstance.rootHref).toBe(
				"http://localhost/test-base-href/"
			);
			expect(popupRef.componentInstance.baseHref).toBe("/test-base-href/");
		});
	});
});

@Component({ template: "" })
class TestComponent {}

@Component({ template: "" })
class TestInjectorsComponent {
	constructor(
		@Inject(POPUP_DATA) public data: number,
		@Inject(DOCUMENT) public documentRef: Document,
		@Inject(POPUP_ROOT_HREF) public rootHref: string,
		@Inject(APP_BASE_HREF) public baseHref: string
	) {}
}
