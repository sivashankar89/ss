import {
	ComponentPortal,
	ComponentType,
	DomPortalOutlet,
} from "@angular/cdk/portal";
import {
	ApplicationRef,
	ComponentFactoryResolver,
	Inject,
	Injectable,
	Injector,
	OnDestroy,
	StaticProvider,
} from "@angular/core";
import { APP_BASE_HREF, DOCUMENT, PlatformLocation } from "@angular/common";
import { ReplaySubject, take, takeUntil } from "rxjs";

import { PopupRef } from "./popup-ref";
import { PopupConfig } from "./popup-config";
import { POPUP_DATA, POPUP_ROOT_HREF } from "./popup-token";

@Injectable()
export class PopupService implements OnDestroy {
	private readonly popups: Map<string, PopupRef<any>> = new Map();
	private readonly destroyed$ = new ReplaySubject<void>(1);
	private readonly window: Window;

	constructor(
		private readonly injector: Injector,
		private readonly componentFactoryResolver: ComponentFactoryResolver,
		private readonly applicationRef: ApplicationRef,
		@Inject(DOCUMENT) private readonly documentRef: Document
	) {
		this.window = documentRef.defaultView as Window;
		// close all opened popups on root window close
		this.window.onbeforeunload = () => {
			this.ngOnDestroy();
		};
	}

	open<T, D = any>(
		component: ComponentType<T>,
		popupConfig?: PopupConfig<D>
	): PopupRef<T> {
		const config = { ...new PopupConfig(), ...popupConfig };

		if (config.id && this.getById(config.id)) {
			throw new Error(`Popup with id "${config.id}" already exists.`);
		}

		const windowInstance = this.createWindow(config.id, config.windowFeatures);

		if (!windowInstance) {
			throw new Error("Window instance creation failed.");
		}

		return this.createPopupWithComponent(windowInstance, component, config);
	}

	getById(id: string): PopupRef<any> | undefined {
		return this.popups.get(id);
	}

	closeAll(): void {
		this.popups.forEach((ref) => ref.close());
	}

	ngOnDestroy(): void {
		this.closeAll();
		this.destroyed$.next();
		this.destroyed$.complete();
	}

	private createWindow(
		windowName?: string,
		windowFeatures?: string
	): Window | null {
		return this.window.open(undefined, windowName, windowFeatures);
	}

	private createPopupWithComponent<T, D = any>(
		windowInstance: Window,
		component: ComponentType<T>,
		config: PopupConfig<D>
	): PopupRef<T> {
		const portalOutlet = this.createPortal(windowInstance);
		const injector = this.createInjector(windowInstance, config);

		// Clean  window
		windowInstance.document.body.innerText = "";

		// Attach component the portal
		const componentRef = portalOutlet.attach(
			new ComponentPortal(component, null, injector)
		);

		// Copy styles
		this.copyStyles(windowInstance);

		if (typeof config.title === "string") {
			windowInstance.document.title = config.title;
		}

		const popupRef = new PopupRef<T>(windowInstance, config.id);
		popupRef.componentInstance = componentRef.instance;
		this.registerNewPopupRef(popupRef);

		return popupRef;
	}

	private createPortal(targetWindowInstance: Window): DomPortalOutlet {
		return new DomPortalOutlet(
			targetWindowInstance.document.body,
			this.componentFactoryResolver,
			this.applicationRef,
			this.injector
		);
	}

	private createInjector(
		windowInstance: Window,
		config?: PopupConfig
	): Injector {
		const providers: StaticProvider[] = [
			{ provide: DOCUMENT, useValue: windowInstance.document },
			{
				provide: APP_BASE_HREF,
				useFactory: (platformLocation: PlatformLocation) =>
					platformLocation.getBaseHrefFromDOM(),
				deps: [PlatformLocation],
			},
			{
				provide: POPUP_ROOT_HREF,
				useFactory: (platformLocation: PlatformLocation) => {
					const origin = this.window.location.origin;
					let baseHref = platformLocation.getBaseHrefFromDOM();
					if (origin[origin.length - 1] === "/" && baseHref[0] === "/") {
						baseHref = baseHref.substring(1);
					}

					return `${origin}${baseHref}`;
				},
				deps: [PlatformLocation],
			},
			{ provide: POPUP_DATA, useValue: config?.data },
		];

		return Injector.create({ parent: this.injector, providers });
	}

	private copyStyles(targetWindowInstance: Window): void {
		// copy stylesheets
		targetWindowInstance.document.head.appendChild(this.getStyleSheetElement());

		// copy styles
		this.documentRef.querySelectorAll("style").forEach((htmlElement) => {
			targetWindowInstance.document.head.appendChild(
				htmlElement.cloneNode(true)
			);
		});

		// copy :root CSS variables
		const rootStyles = this.documentRef.documentElement.style;
		const targetStyles = targetWindowInstance.document.documentElement.style;
		const rootCssVariablesNames = Object.values(rootStyles).filter(
			(value) => typeof value === "string" && value.startsWith("--")
		);
		rootCssVariablesNames.forEach((variableName) => {
			targetStyles.setProperty(
				variableName,
				rootStyles.getPropertyValue(variableName)
			);
		});
	}

	private getStyleSheetElement(): HTMLLinkElement {
		const styleSheetElement = this.documentRef.createElement("link");

		this.documentRef.querySelectorAll("link").forEach((htmlElement) => {
			if (htmlElement.rel === "stylesheet") {
				const absoluteUrl = new URL(htmlElement.href).href;
				styleSheetElement.rel = "stylesheet";
				styleSheetElement.href = absoluteUrl;
			}
		});

		return styleSheetElement;
	}

	private registerNewPopupRef<T>(popupRef: PopupRef<T>): void {
		this.popups.set(popupRef.id, popupRef);

		popupRef.closed$.pipe(take(1), takeUntil(this.destroyed$)).subscribe(() => {
			if (this.popups.has(popupRef.id)) {
				this.popups.delete(popupRef.id);
			}
		});
	}
}
