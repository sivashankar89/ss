import { take } from "rxjs";
import { PopupConfig } from "./popup-config";

describe("PopupConfig", () => {
	it("should be created with default values", () => {
		const popupConfig = new PopupConfig();
		expect(popupConfig).toEqual({
			windowFeatures: "popup=true,screenX=100,screenY=100,width=540,height=540",
		});
	});

	it("should be created and allow to modify values", () => {
		const popupConfig = new PopupConfig();
		popupConfig.data = "test-data";
		popupConfig.id = "test-id";
		popupConfig.title = "test-title";
		popupConfig.windowFeatures = "";

		expect(popupConfig).toEqual({
			data: "test-data",
			id: "test-id",
			title: "test-title",
			windowFeatures: "",
		});
	});
});
