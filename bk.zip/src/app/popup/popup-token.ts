import { InjectionToken } from "@angular/core";

export const POPUP_DATA = new InjectionToken<any>("POPUP_DATA");
export const POPUP_ROOT_HREF = new InjectionToken<any>("POPUP_ROOT_HREF");
