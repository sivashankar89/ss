import { animate, style, transition, trigger } from "@angular/animations";

export const FADE_ANIMATION = trigger("fade", [
	transition(":enter", [
		style({
			opacity: 0,
			overflow: "hidden",
		}),
		animate(`300ms ease-in-out`, style({ opacity: 1 })),
	]),
	transition(":leave", [
		style({
			opacity: 1,
			overflow: "hidden",
		}),
		animate(`300ms ease-in-out`, style({ opacity: 0 })),
	]),
]);
