import { animate, style, transition, trigger } from "@angular/animations";

// copied from design-system-angular animations
export const SHRINK_ANIMATION = trigger("shrink", [
	transition(":enter", [
		style({
			height: "0",
			opacity: 0,
			overflow: "hidden",
		}),
		animate(
			`300ms ease-in-out`,
			style({
				height: "*",
				opacity: 1,
			})
		),
	]),
	transition(":leave", [
		style({
			height: "*",
			opacity: 1,
			overflow: "hidden",
		}),
		animate(
			`300ms ease-in-out`,
			style({
				height: "0",
				opacity: 0,
			})
		),
	]),
]);
