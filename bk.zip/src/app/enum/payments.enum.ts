export enum PaymentsApiCardFunctionEnum {
	CREDIT = "CREDIT",
	DEBIT = "DEBIT",
	PREPAID = "PREPAID",
	VOUCHER = "VOUCHER",
	UNDEFINED = "UNDEFINED",
}

export enum PaymentsApiSecurityCodeResponseEnum {
	MATCHED = "MATCHED",
	NOT_MATCHED = "NOT_MATCHED",
	NOT_PROCESSED = "NOT_PROCESSED",
	NOT_PRESENT = "NOT_PRESENT",
	NOT_CERTIFIED = "NOT_CERTIFIED",
	NOT_CHECKED = "NOT_CHECKED",
}

export enum PaymentsApiAVSResponseMatchEnum {
	Y = "Y",
	N = "N",
	NO_INPUT_DATA = "NO_INPUT_DATA",
	NOT_CHECKED = "NOT_CHECKED",
}

export enum PaymentLinkCreationStateEnum {
	INIT = "INIT",
	LOADING = "LOADING",
	SUCCESS = "SUCCESS",
	FAILED = "FAILED",
}
